<div class="sidebar">
  <h1>Admin panel</h1>
  <a href="admin_users.php" class="sidebar-link">👤 Manage Users</a>
  <a href="index.php" class="sidebar-link">📚 Manage Ebooks</a>
  <a href="Story_view.php" class="sidebar-link">✍️ Stories</a>
  <a href="Story_Upload.php" class="sidebar-link">🚀 Launch a Story Competition</a>
  <a href="upload.php" class="sidebar-link">➕ Upload New Ebook</a>
  <a href="Submitted_stories.php" class="sidebar-link">⭐ Submitted Stories</a>
  <a href="notifications.php" class="sidebar-link">➕send notification</a>
</div>

<style>
    h1{
        text-align: center;
        font-family: Arial, sans-serif;
    }
  .sidebar {
    width: 220px;
    height: 100vh;
    background:  #282c30ff;
    padding: 20px 15px;
    box-shadow: 2px 0 10px rgba(0,0,0,0.15);
    position: fixed;
    top: 0;
    left: 0;
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .sidebar-link {
    display: block;
    background: rgba(255, 255, 255, 0.1);
    color: white;
    text-decoration: none;
    padding: 12px 18px;
    border-radius: 10px;
    font-weight: 500;
    transition: all 0.3s ease;
  }

  .sidebar-link:hover {
    background: rgba(255, 255, 255, 0.25);
    transform: translateX(5px);
  }

  body {
    margin-left: 240px;
    font-family: Arial, sans-serif;
  }
</style>
