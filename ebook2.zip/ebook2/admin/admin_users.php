<?php
include '../config.php';
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$sql = "SELECT * FROM Verified_users";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Manage Users</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #121212;
            color: #e0e0e0;
            line-height: 1.6;
            padding: 20px;
        }
      
        h2 {
            color: #ffffff;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
            font-weight: 300;
            letter-spacing: 1px;
            text-shadow: 0 0 10px rgba(0, 150, 255, 0.3);
        }
        
        
        .add-user-btn {
            display: inline-block;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 30px;
            font-weight: 600;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 100, 200, 0.3);
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .add-user-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 100, 200, 0.4);
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
       
        .table-container {
            overflow-x: auto;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #1e1e1e;
            border-radius: 10px;
            overflow: hidden;
        }
        
        th {
            background: linear-gradient(135deg, #2d2d2d, #1a1a1a);
            color: #bb86fc;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 0.9rem;
            border-bottom: 2px solid #333;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #333;
            transition: background-color 0.2s;
        }
        
        tr:hover td {
            background-color: #2a2a2a;
        }
        
        tr:last-child td {
            border-bottom: none;
        }
        
        
        .action-links a {
            color: #bb86fc;
            text-decoration: none;
            margin: 0 5px;
            padding: 5px 10px;
            border-radius: 4px;
            transition: all 0.2s;
            display: inline-block;
        }
        
        .action-links a:nth-child(1) { /
            color: #ffb74d;
        }
        
        .action-links a:nth-child(2) { 
            color: #cf6679;
        }
        
        .action-links a:hover {
            background-color: rgba(255, 255, 255, 0.1);
            transform: translateY(-1px);
        }
        
        
        .password-cell {
            font-family: 'Courier New', monospace;
            color: #03dac6;
            background: rgba(3, 218, 198, 0.1);
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.9rem;
        }
        
       
        .id-cell {
            color: #bb86fc;
            font-weight: 600;
            background: rgba(187, 134, 252, 0.1);
            padding: 5px 10px;
            border-radius: 4px;
            display: inline-block;
        }
        
       
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            h2 {
                font-size: 2rem;
            }
            
            th, td {
                padding: 10px 8px;
                font-size: 0.9rem;
            }
            
            .action-links a {
                display: block;
                margin: 5px 0;
                text-align: center;
            }
        }
        
        
        footer {
            text-align: center;
            margin-top: 40px;
            color: #666;
            font-size: 0.9rem;
        }
        
       
        .status {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-active {
            background-color: rgba(76, 175, 80, 0.2);
            color: #4caf50;
        }
        
        .status-inactive {
            background-color: rgba(255, 152, 0, 0.2);
            color: #ff9800;
        }
         .nav{
      display:flex;
      flex-direction:row;
      justify-content:center;
      gap:10px;
    }
    .nav a{
      border-radius:10px;
      width:300px;
      text-align: center;
    }
    </style>
</head>
<body>
    <h2>👥 User Management Dashboard</h2>
  
    <?php include 'sidebar.php';?>
   
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><span class="id-cell">#<?php echo $row['id']; ?></span></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><span class="password-cell"><?php echo htmlspecialchars($row['pass']); ?></span></td>
                    <td class="action-links">
                        <a href="edit_user.php?id=<?php echo $row['id']; ?>">✏ Edit</a>
                        <a href="delete_user.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?')">❌ Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    
    <footer>
        <p>User Admin Panel &copy; <?php echo date('Y'); ?></p>
    </footer>
</body>
</html>