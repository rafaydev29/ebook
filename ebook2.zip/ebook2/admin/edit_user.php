<?php
include '../config.php';

$id = $_GET['id'] ?? 0;


$sql = "SELECT * FROM Verified_users WHERE id=$id";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $pass  = $_POST['pass'];

    $update = "UPDATE Verified_users SET name='$name', email='$email', pass='$pass' WHERE id=$id";
    if ($conn->query($update)) {
        header("Location: admin_users.php");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
</head>
<body>
    <h2>Edit User</h2>
    <form method="POST">
        <label>Name:</label><br>
        <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>"><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>"><br><br>

        <label>Password:</label><br>
        <input type="text" name="pass" value="<?php echo htmlspecialchars($user['pass']); ?>"><br><br>

        <button type="submit">Update</button>
    </form>
    <a href="admin_users.php">Back</a>
</body>
</html>
