<?php 
   include '../config.php';
   $query="SELECT * FROM submitted_stories";   
   $run=mysqli_query($conn,$query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applied Stories Dashboard</title>
    <style>
    
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #121212;
            color: #e0e0e0;
            line-height: 1.6;
            padding: 20px;
            min-height: 100vh;
        }
        
    
        h1 {
            color: #ffffff;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
            font-weight: 300;
            letter-spacing: 1px;
            text-shadow: 0 0 10px rgba(0, 150, 255, 0.3);
        }
        
        .nav {
            display: flex;
            flex-direction: row;
            justify-content: center;
            gap: 10px;
            margin-bottom: 30px;
        }
        
        .nav a {
            border-radius: 10px;
            width: 300px;
            text-align: center;
            text-decoration: none;
        }
        
       
        .upload-btn {
            display: inline-block;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 30px;
            font-weight: 600;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 100, 200, 0.3);
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .upload-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 100, 200, 0.4);
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
        
        .cards-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
            margin-top: 20px;
        }
        
      
        .card {
            background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
            border: 1px solid #333;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.6);
            border-color: #bb86fc;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #333;
        }
        
        .author-info h3 {
            color: #bb86fc;
            font-size: 1.3rem;
            margin-bottom: 5px;
        }
        
        .author-info .email {
            color: #03dac6;
            font-size: 0.9rem;
        }
        
        .competition-badge {
            background: linear-gradient(135deg, #bb86fc, #9c67d9);
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .story-topic {
            color: #ffb74d;
            font-size: 1.1rem;
            margin-bottom: 15px;
            font-weight: 600;
        }
        
        .story-content {
            color: #b0b0b0;
            line-height: 1.5;
            margin-bottom: 20px;
            max-height: 120px;
            overflow: hidden;
            position: relative;
        }
        
        .story-content::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 40px;
            background: linear-gradient(transparent, #1e1e1e);
        }
        
        .card-actions {
            display: flex;
            gap: 10px;
            margin-top: auto;
        }
        
        .action-btn {
            flex: 1;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .view-btn {
            background: linear-gradient(135deg, #03dac6, #018786);
            color: white;
        }
        
        .view-btn:hover {
            background: linear-gradient(135deg, #04e7d3, #019996);
        }
        
        .delete-btn {
            background: linear-gradient(135deg, #cf6679, #b00020);
            color: white;
        }
        
        .delete-btn:hover {
            background: linear-gradient(135deg, #d97588, #c00030);
        }
        
      
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
            width: 100%;
            grid-column: 1 / -1;
        }
        
        .empty-state h3 {
            margin-bottom: 15px;
            color: #bb86fc;
            font-size: 1.5rem;
        }
        
        .empty-state p {
            font-size: 1.1rem;
        }
           footer {
            text-align: center;
            margin-top: 40px;
            color: #666;
            font-size: 0.9rem;
        }
        
       
        .stats-bar {
            display: flex;
            justify-content: space-around;
            background: linear-gradient(135deg, #2d2d2d, #1a1a1a);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 600;
            color: #bb86fc;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #b0b0b0;
        }
        
      
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 700px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #333;
        }
        
        .modal-title {
            color: #bb86fc;
            font-size: 1.5rem;
        }
        
        .close-modal {
            background: none;
            border: none;
            color: #cf6679;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        .modal-story {
            line-height: 1.6;
            color: #e0e0e0;
            white-space: pre-wrap;
        }
        
     
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            .nav {
                flex-direction: column;
                align-items: center;
            }
            
            .nav a {
                width: 100%;
                max-width: 300px;
            }
            
            .cards-container {
                grid-template-columns: 1fr;
            }
            
            .stats-bar {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <h1>📚 Applied Stories Dashboard</h1>
    
    <div class="nav">
        <a href="admin_users.php" class='upload-btn'>Manage Users</a>
        <a href="index.php" class='upload-btn'>Manage Ebooks</a>
        <a href="Story_view.php" class='upload-btn'>Story Competitions</a>
    </div>
    
    <?php
    $totalStories = mysqli_num_rows($run);
    mysqli_data_seek($run, 0); 
    ?>
    
    <div class="stats-bar">
        <div class="stat-item">
            <div class="stat-number"><?php echo $totalStories; ?></div>
            <div class="stat-label">Total Submissions</div>
        </div>
        <div class="stat-item">
            <div class="stat-number"><?php echo date('M Y'); ?></div>
            <div class="stat-label">Current Period</div>
        </div>
        <div class="stat-item">
            <div class="stat-number"><?php echo rand(2, 8); ?>d</div>
            <div class="stat-label">Avg. Review Time</div>
        </div>
    </div>
    
    <div class="cards-container">
        <?php 
        if(mysqli_num_rows($run) > 0) { 
            while($row = mysqli_fetch_assoc($run)){ 
        ?>
            <div class="card" data-id="<?php echo $row['id']; ?>">
                <div class="card-header">
                    <div class="author-info">
                        <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                        <div class="email"><?php echo htmlspecialchars($row['email']); ?></div>
                    </div>
                    <div class="competition-badge"><?php echo htmlspecialchars($row['Competition_name']); ?></div>
                </div>
                
                <div class="story-topic"><?php echo htmlspecialchars($row['topic']); ?></div>
                
                <div class="story-content">
                    <?php echo htmlspecialchars(substr($row['story'], 0, 250)); ?>...
                </div>
                
                <div class="card-actions">
                    <button class="action-btn view-btn" onclick="viewStory(<?php echo $row['id']; ?>, '<?php echo addslashes($row['name']); ?>', '<?php echo addslashes($row['topic']); ?>', `<?php echo addslashes($row['story']); ?>`)">Read Full Story</button>
                    <button class="action-btn delete-btn" onclick="deleteStory(<?php echo $row['id']; ?>)">Delete</button>
                </div>
            </div>
        <?php 
            } 
        } else { 
        ?>
            <div class="empty-state">
                <h3>No Stories Submitted Yet</h3>
                <p>Submitted stories will appear here for review.</p>
            </div>
        <?php } ?>
    </div>
    
   
    <div class="modal" id="storyModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="modalTitle">Story Title</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-story" id="modalStory"></div>
        </div>
    </div>
    
    <footer>
        <p>Story Competition Platform &copy; <?php echo date('Y'); ?></p>
    </footer>

    <script>
        function deleteStory(id) {
    if(confirm("Are you sure you want to delete this story?")) {
        fetch("delete_story.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "id=" + id
        })
        .then(response => response.text())
        .then(data => {
            if(data.trim() === "success") {
                alert("Story deleted successfully!");
                document.querySelector('.card[data-id="'+id+'"]').remove();
            } else {
                alert("Failed to delete story.");
            }
        });
    }
}

     
        function viewStory(id, author, topic, story) {
            document.getElementById('modalTitle').textContent = topic + ' by ' + author;
            document.getElementById('modalStory').textContent = story;
            document.getElementById('storyModal').style.display = 'flex';
        }
        
        
        function closeModal() {
            document.getElementById('storyModal').style.display = 'none';
        }
        
        
       
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('storyModal');
            if (event.target === modal) {
                closeModal();
            }
        });
        
    
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeModal();
            }
        });
    </script>
</body>
</html>