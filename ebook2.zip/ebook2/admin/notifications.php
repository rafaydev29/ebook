<?php
include '../config.php';
$query="SELECT * FROM notifications";
$run=mysqli_query($conn,$query);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql = "INSERT INTO notifications (title, description) 
            VALUES ('$title', '$description')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='success-message'>✅ Notification has been sent successfully</div>";
    } else {
        echo "<div class='error-message'>❌ Error: " . $conn->error . "</div>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Notification</title>
  <style>
    body {
      background: #121212;
      font-family: Arial, sans-serif;
      color: #e0e0e0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    .form-container {
      background: #1e1e1e;
      padding: 25px;
      border-radius: 10px;
      width: 100%;
      max-width: 500px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.6);
    }
    h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #bb86fc;
    }
    .form-group {
      margin-bottom: 15px;
    }
    label {
      display: block;
      margin-bottom: 6px;
      color: #bb86fc;
    }
    input, textarea {
      width: 100%;
      padding: 10px;
      border: none;
      border-radius: 6px;
      background: #2d2d2d;
      color: #fff;
    }
    input:focus, textarea:focus {
      outline: none;
      border: 1px solid #bb86fc;
    }
    .submit-btn {
      display: block;
      width: 100%;
      background: linear-gradient(135deg, #1e88e5, #0d47a1);
      border: none;
      padding: 12px;
      color: #fff;
      font-weight: 600;
      border-radius: 30px;
      cursor: pointer;
      transition: 0.3s;
    }
    .submit-btn:hover {
      background: linear-gradient(135deg, #2196f3, #1565c0);
    }
    .success-message, .error-message {
      margin: 15px 0;
      padding: 12px;
      border-radius: 6px;
    }
    .success-message {
      background: rgba(76,175,80,0.2);
      border-left: 4px solid #4caf50;
      color: #4caf50;
    }
    .error-message {
      background: rgba(244,67,54,0.2);
      border-left: 4px solid #f44336;
      color: #f44336;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>📢 Add Notification</h2>
    <form method="POST">
      <div class="form-group">
        <label for="title">Notification Title</label>
        <input type="text" id="title" name="title" required>
      </div>
      <div class="form-group">
        <label for="description">Notification Description</label>
        <textarea id="description" name="description" rows="4" required></textarea>
      </div>
      <button type="submit" class="submit-btn">Send Notification</button>
    </form>
  </div>

  <div>
    <?php while($row=mysqli_fetch_assoc($run)){ ?>
        <div class="card">
            <h3><?php echo $row['title'] ?></h3>
            <p><?php echo $row['description']?></p>
            <h4><?php echo $row['created_at']?></h4>
        </div>
    <?php }?>
  </div>
</body>
</html>
