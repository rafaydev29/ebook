<?php
include '../config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

   
    $query = "SELECT * FROM Launch_Story_Competition WHERE id = $id";
    $result = mysqli_query($conn, $query);
    $competition = mysqli_fetch_assoc($result);

    if (!$competition) {
        die("Competition not found!");
    }
}


if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $duration = mysqli_real_escape_string($conn, $_POST['duration']);
    $previuos_winner = mysqli_real_escape_string($conn, $_POST['previuos_winner']);

    $updateQuery = "UPDATE Launch_Story_Competition 
                    SET name='$name', description='$description', price='$price', duration='$duration', previuos_winner='$previuos_winner' 
                    WHERE id=$id";

    if (mysqli_query($conn, $updateQuery)) {
        echo "<div class='success-message'>Competition updated successfully!</div>";
    } else {
        echo "<div class='error-message'>Error updating record: " . mysqli_error($conn) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Story Competition</title>
    <style>
     
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #121212;
            color: #e0e0e0;
            line-height: 1.6;
            padding: 20px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        
      
        h1 {
            color: #ffffff;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
            font-weight: 300;
            letter-spacing: 1px;
            text-shadow: 0 0 10px rgba(0, 150, 255, 0.3);
        }
        
        
        .nav {
            display: flex;
            flex-direction: row;
            justify-content: center;
            gap: 10px;
            margin-bottom: 30px;
        }
        
        .nav a {
            border-radius: 10px;
            width: 300px;
            text-align: center;
            text-decoration: none;
        }
      
        .form-container {
            background-color: #1e1e1e;
            padding: 30px;
            border-radius: 10px;
            width: 100%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            margin-top: 20px;
        }
        
        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #bb86fc;
            font-weight: 400;
            font-size: 1.8rem;
        }
        
      
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #bb86fc;
            font-weight: 500;
        }
        
        input, textarea, select {
            width: 100%;
            padding: 12px 15px;
            background-color: #2d2d2d;
            border: 1px solid #333;
            border-radius: 6px;
            color: #e0e0e0;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: #bb86fc;
            box-shadow: 0 0 0 2px rgba(187, 134, 252, 0.2);
        }
        
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }
        
        .submit-btn {
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            border: none;
            padding: 14px 20px;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            flex: 1;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 100, 200, 0.3);
        }
        
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 100, 200, 0.4);
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
        .cancel-btn {
            background: linear-gradient(135deg, #666, #444);
            color: white;
            border: none;
            padding: 14px 20px;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            flex: 1;
            transition: all 0.3s ease;
            text-decoration: none;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        }
        
        .cancel-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
            background: linear-gradient(135deg, #777, #555);
        }
        
        .upload-btn {
            display: inline-block;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 30px;
            font-weight: 600;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 100, 200, 0.3);
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .upload-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 100, 200, 0.4);
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
        .success-message {
            background-color: rgba(76, 175, 80, 0.2);
            color: #4caf50;
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #4caf50;
        }
        
        .error-message {
            background-color: rgba(244, 67, 54, 0.2);
            color: #f44336;
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #f44336;
        }
        
        footer {
            text-align: center;
            margin-top: 40px;
            color: #666;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            .nav {
                flex-direction: column;
                align-items: center;
            }
            
            .nav a {
                width: 100%;
                max-width: 300px;
            }
            
            .form-container {
                padding: 20px;
            }
            
            .button-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <h1>✏️ Edit Story Competition</h1>
    
    <div class="nav">
        <a href="admin_users.php" class='upload-btn'>Manage Users</a>
        <a href="index.php" class='upload-btn'>Manage Ebooks</a>
        <a href="Story_view.php" class='upload-btn'>Story Competitions</a>
    </div>
    
    <div class="form-container">
        <h2>Update Competition Details</h2>
        
        <form method="POST">
            <input type="hidden" name="id" value="<?php echo $competition['id']; ?>">

            <div class="form-group">
                <label for="name">Story Name:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($competition['name']); ?>" required>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea id="description" name="description" required><?php echo htmlspecialchars($competition['description']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="price">Price:</label>
                <input type="text" id="price" name="price" value="<?php echo htmlspecialchars($competition['price']); ?>" required>
            </div>

            <div class="form-group">
                <label for="duration">Duration:</label>
                <input type="text" id="duration" name="duration" value="<?php echo htmlspecialchars($competition['duration']); ?>" required>
            </div>

            <div class="form-group">
                <label for="previuos_winner">Previous Winner:</label>
                <input type="text" id="previuos_winner" name="previuos_winner" value="<?php echo htmlspecialchars($competition['previuos_winner']); ?>">
            </div>

            <div class="button-group">
                <button type="submit" name="update" class="submit-btn">Update Competition</button>
                <a href="Story_view.php" class="cancel-btn">Cancel</a>
            </div>
        </form>
    </div>
    
    <footer>
        <p>Story Competition Admin Panel &copy; <?php echo date('Y'); ?></p>
    </footer>
</body>
</html>