<?php
include '../config.php';

$id = intval($_GET['id']);
$query = "SELECT title, file, file_type FROM fiction WHERE id = $id";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

header("Content-type: " . $row['file_type']);
header("Content-Disposition: inline; filename=" . $row['title'] . ".docx");
echo $row['file'];
exit;
