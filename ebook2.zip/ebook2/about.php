<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - eBook Haven</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6C63FF;
            --secondary: #FF6584;
            --accent: #36D1DC;
            --dark: #1E1E2E;
            --darker: #161622;
            --light: #F0F0F5;
            --card-bg: #2A2A3C;
            --text: #E2E2E2;
            --text-light: #A0A0B0;
        }

        body {
            background: linear-gradient(135deg, var(--darker) 0%, var(--dark) 100%);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            background: var(--dark);
            color: white;
            padding: 18px 0;
            height: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 26px;
            font-weight: 700;
            display: flex;
            align-items: center;
            color: var(--light);
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        nav ul {
            display: flex;
            list-style: none;
            flex-wrap: wrap;
        }

        nav ul li {
            margin-left: 20px;
        }

        nav ul li a {
            color: var(--text);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            font-size: 0.95rem;
        }

        nav ul li a:hover {
            color: var(--primary);
        }

        .hero {
            text-align: center;
            padding: 80px 0;
background: linear-gradient(rgba(43, 42, 51, 0.9), rgba(12, 36, 38, 0.9)), 
                        radial-gradient(circle at top left, rgba(139, 128, 249, 0.2) 0%, transparent 50%),
                        radial-gradient(circle at bottom right, rgba(76, 216, 225, 0.2) 0%, transparent 50%),
                        var(--darker);            color: white;
            margin-bottom: 40px;
            border-radius: 0 0 20px 20px;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: var(--light);
            font-weight: 700;
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto 30px;
            color: var(--text-light);
        }

        .btn {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 12px 30px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background: #5a52e0;
            transform: translateY(-2px);
        }

        .section-title {
            text-align: center;
            margin-bottom: 40px;
            color: var(--light);
            font-weight: 600;
            font-size: 2.2rem;
        }

        .section-title:after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: var(--primary);
            margin: 15px auto;
            border-radius: 2px;
        }

        .about-content {
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            margin-bottom: 60px;
            align-items: center;
        }

        .about-text {
            flex: 1;
            min-width: 300px;
        }

        .about-text h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: var(--light);
        }

        .about-text p {
            margin-bottom: 15px;
            color: var(--text-light);
        }

        .about-image {
            flex: 1;
            min-width: 300px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .about-image img {
            width: 100%;
            height: auto;
            display: block;
        }

        .features {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            margin-bottom: 60px;
        }

        .feature-card {
            flex: 1;
            min-width: 250px;
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .feature-icon {
            font-size: 2.2rem;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .feature-card h3 {
            margin-bottom: 15px;
            color: var(--light);
        }

        .feature-card p {
            color: var(--text-light);
        }

        .team {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            margin-bottom: 60px;
            justify-content: center;
        }

        .team-member {
            flex: 1;
            min-width: 250px;
            max-width: 300px;
            background: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        .team-img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin: 0 auto 20px;
            overflow: hidden;
            border: 4px solid var(--card-bg);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .team-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .team-member h3 {
            margin-bottom: 5px;
            color: var(--light);
        }

        .team-member p {
            color: var(--text-light);
        }

        .stats {
            background: var(--card-bg);
            padding: 50px 0;
            border-radius: 12px;
            margin-bottom: 60px;
        }

        .stats-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            text-align: center;
        }

        .stat {
            padding: 15px;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
            color: var(--light);
        }

        .stat-title {
            color: var(--text-light);
        }

        footer {
            background: var(--darker);
            color: white;
            padding: 40px 0 20px;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }

        .footer-content {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            justify-content: space-around;
            margin-bottom: 30px;
        }

        .footer-section {
            flex: 1;
            min-width: 250px;
        }

        .footer-section h3 {
            margin-bottom: 15px;
            color: var(--light);
        }

        .footer-section p, .footer-section a {
            color: var(--text-light);
            text-decoration: none;
            margin-bottom: 8px;
            display: block;
        }

        .footer-section a:hover {
            color: var(--primary);
        }

        .social-icons {
            margin-bottom: 20px;
        }

        .social-icons a {
            color: var(--text);
            font-size: 1.3rem;
            margin: 0 10px;
            transition: all 0.3s ease;
        }

        .social-icons a:hover {
            color: var(--primary);
        }

        .footer-bottom {
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            color: var(--text-light);
            font-size: 0.9rem;
        }

       
        @media (max-width: 900px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }

            nav ul {
                margin-top: 15px;
                justify-content: center;
            }

            nav ul li {
                margin: 0 10px;
            }

            .hero h1 {
                font-size: 2.5rem;
            }
        }

        @media (max-width: 768px) {
            .about-content, .features, .team, .stats-container, .footer-content {
                flex-direction: column;
                align-items: center;
            }

            .feature-card, .team-member, .footer-section {
                width: 100%;
                max-width: 400px;
            }
            
            .hero h1 {
                font-size: 2.2rem;
            }
            
            .section-title {
                font-size: 2rem;
            }
        }

        @media (max-width: 480px) {
            .hero h1 {
                font-size: 1.9rem;
            }

            .hero p {
                font-size: 1rem;
            }

            .btn {
                padding: 10px 20px;
            }

            .section-title {
                font-size: 1.8rem;
            }

            .stat-number {
                font-size: 2rem;
            }
            
            nav ul li {
                margin-left: 10px;
            }
        }
    </style>
</head>
<body>
    <!-- <header>
        <div class="container header-content">
            <div class="logo">
                <i class="fas fa-book-open"></i>
                <span>eBook Haven</span>
            </div>
            <nav>
                 <ul>
                <li><a href="events.html">Events</a></li>
                <li><a href="contact.html">Contact us</a></li>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About us</a></li>
                <li><a href="login.html">Login</a></li>
                <li><a href="user/dashboard.html">Dashboard</a></li>
                <li><a href="categroies.html">Categories</a></li>
                <li><a href="competition.html">Competition</a></li>
                <li><a href="cart.html">Cart</a></li>
                </ul>
            </nav>
        </div>
    </header> -->
   <?php include 'nav.php'; ?>
    <section class="hero">
        <div class="container">
            <h1>Our Story: eBook Haven</h1>
            <p>Discover the journey of how we became your favorite destination for digital reading</p>
            <a href="books.php" class="btn">Explore Our Library</a>
        </div>
    </section>

    <div class="container">
        <section class="about-content">
            <div class="about-text">
                <h2>We Believe in the Power of Stories</h2>
                <p>Founded in 2015, eBook Haven began with a simple mission: to make reading accessible to everyone, everywhere. What started as a small digital library has grown into a comprehensive platform with over 100,000 titles across every genre.</p>
                <p>Our team of book lovers and tech enthusiasts work tirelessly to create the best reading experience. We carefully curate our collection to include both bestsellers and hidden gems, ensuring there's something for every reader.</p>
                <p>At eBook Haven, we're committed to supporting authors and publishers while providing our readers with affordable access to their next favorite book.</p>
            </div>
            <div class="about-image">
                <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='500' height='300' viewBox='0 0 500 300'><rect width='500' height='300' fill='%232A2A3C'/><text x='250' y='150' font-family='Arial' font-size='24' fill='%23E2E2E2' text-anchor='middle'>Reading Community Image</text></svg>" alt="eBook Haven reading community">
            </div>
        </section>

        <h2 class="section-title">Why Choose eBook Haven</h2>
        <section class="features">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-book"></i>
                </div>
                <h3>Vast Library</h3>
                <p>Access over 100,000 titles across every genre imaginable, from bestsellers to niche interests.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-laptop"></i>
                </div>
                <h3>Read Anywhere</h3>
                <p>Enjoy your books on any device - phone, tablet, computer, or e-reader with our free app.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-tags"></i>
                </div>
                <h3>Affordable Prices</h3>
                <p>Get great deals on eBooks with our daily discounts and membership benefits.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-heart"></i>
                </div>
                <h3>Curated Collections</h3>
                <p>Discover new favorites with our hand-picked recommendations and themed collections.</p>
            </div>
        </section>

        <section class="stats">
            <div class="stats-container">
                <div class="stat">
                    <div class="stat-number">100K+</div>
                    <div class="stat-title">eBooks Available</div>
                </div>
                <div class="stat">
                    <div class="stat-number">500K+</div>
                    <div class="stat-title">Happy Readers</div>
                </div>
                <div class="stat">
                    <div class="stat-number">50+</div>
                    <div class="stat-title">Awards Won</div>
                </div>
                <div class="stat">
                    <div class="stat-number">24/7</div>
                    <div class="stat-title">Support Available</div>
                </div>
            </div>
        </section>

        <h2 class="section-title">Meet Our Team</h2>
        <section class="team">
            <div class="team-member">
                <div class="team-img">
                    <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' viewBox='0 0 120 120'><circle cx='60' cy='60' r='60' fill='%236C63FF'/><text x='60' y='70' font-family='Arial' font-size='20' fill='white' text-anchor='middle'>JD</text></svg>" alt="John Doe">
                </div>
                <h3>John Doe</h3>
                <p>Founder & CEO</p>
            </div>
            <div class="team-member">
                <div class="team-img">
                    <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' viewBox='0 0 120 120'><circle cx='60' cy='60' r='60' fill='%23FF6584'/><text x='60' y='70' font-family='Arial' font-size='20' fill='white' text-anchor='middle'>AS</text></svg>" alt="Anna Smith">
                </div>
                <h3>Anna Smith</h3>
                <p>Content Curator</p>
            </div>
            <div class="team-member">
                <div class="team-img">
                    <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' viewBox='0 0 120 120'><circle cx='60' cy='60' r='60' fill='%2336D1DC'/><text x='60' y='70' font-family='Arial' font-size='20' fill='white' text-anchor='middle'>MJ</text></svg>" alt="Mike Johnson">
                </div>
                <h3>Mike Johnson</h3>
                <p>Tech Lead</p>
            </div>
        </section>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>eBook Haven</h3>
                    <p>Your destination for the world's best eBooks. Discover, read, and enjoy!</p>
                </div>
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <a href="index.html">Home</a>
                    <a href="categroies.html">Library</a>
                    <a href="categroies.html">Categories</a>
                </div>
                <div class="footer-section">
                    <h3>Contact Us</h3>
                    <p><i class="fas fa-envelope"></i> support@ebookhaven.com</p>
                    <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
                </div>
            </div>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 eBook Haven. All rights reserved.</p>
            </div>
        </div>
    </footer>
    <script>
        (function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="3muZwl8ydn2bOkQ31Fx3A";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();
    </script>
</body>
</html>