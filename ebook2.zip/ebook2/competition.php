<?php
 include './config.php';
 $query="SELECT * FROM Launch_Story_Competition";
 $run=mysqli_query($conn,$query);
 

 $notificationQuery = "SELECT * FROM notifications";
 $notificationRun = mysqli_query($conn, $notificationQuery);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Story Competitions - Apply Now</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        :root {
            --primary: #bb86fc;
            --light: #ffffff;
            --text: #e0e0e0;
        }
        
        body {
            background-color: #121212;
            color: #e0e0e0;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* Navigation Styles */
        nav {
            background: #1a1a1a;
            color: white;
            padding: 18px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            margin: 0 auto;
            padding: 0 2%;
        }

        .logo {
            font-size: 26px;
            font-weight: 700;
            display: flex;
            align-items: center;
            color: var(--light);
        }
        
        span {
            color: rgba(224, 212, 212, 1);
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        .links {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .links a {
            color: var(--text);
            text-decoration: none;
            font-weight: 500;
            margin: 0 12px;
            transition: all 0.3s ease;
            padding: 6px 0;
            font-size: 0.95rem;
        }

        .links a:hover {
            color: var(--primary);
        }
        
        @media (max-width: 900px) {
            .nav-container {
                flex-direction: column;
                text-align: center;
            }

            .links {
                margin-top: 15px;
            }
              
            .links a {
                margin: 5px 10px;
            }
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            padding: 30px 20px;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }
        
        /* Header Styles */
        h1 {
            color: #ffffff;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
            font-weight: 300;
            letter-spacing: 1px;
            text-shadow: 0 0 10px rgba(0, 150, 255, 0.3);
        }
        
        .page-description {
            text-align: center;
            margin-bottom: 40px;
            color: #aaa;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            font-size: 1.1rem;
        }
        
        /* Competition Cards */
        .competitions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .competition-card {
            background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: 1px solid #333;
        }
        
        .competition-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.5);
        }
        
        .card-header {
            background: linear-gradient(135deg, #bb86fc, #7c4dff);
            padding: 20px;
            text-align: center;
        }
        
        .card-header h3 {
            color: white;
            font-size: 1.4rem;
            margin-bottom: 5px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .card-details {
            margin-bottom: 20px;
        }
        
        .detail-item {
            display: flex;
            margin-bottom: 10px;
            align-items: flex-start;
        }
        
        .detail-label {
            font-weight: 600;
            color: #bb86fc;
            min-width: 120px;
        }
        
        .detail-value {
            flex: 1;
        }
        
        .prize-highlight {
            background: linear-gradient(135deg, #ffb74d, #ff9800);
            color: #121212;
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: 600;
            text-align: center;
            margin: 15px 0;
        }
        
        .apply-btn {
            display: block;
            width: 100%;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            text-align: center;
            padding: 12px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .apply-btn:hover {
            background: linear-gradient(135deg, #2196f3, #1565c0);
            box-shadow: 0 5px 15px rgba(0, 100, 200, 0.4);
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            overflow-y: auto;
        }
        
        .modal-content {
            background-color: #1e1e1e;
            margin: 5% auto;
            width: 90%;
            max-width: 600px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            animation: modalFade 0.3s;
        }
        
        @keyframes modalFade {
            from {opacity: 0; transform: translateY(-50px);}
            to {opacity: 1; transform: translateY(0);}
        }
        
        .modal-header {
            background: linear-gradient(135deg, #bb86fc, #7c4dff);
            padding: 20px;
            border-radius: 15px 15px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h2 {
            color: white;
            font-size: 1.5rem;
        }
        
        .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            transition: transform 0.2s;
        }
        
        .close-btn:hover {
            transform: scale(1.2);
        }
        
        .modal-body {
            padding: 25px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #bb86fc;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            background-color: #2a2a2a;
            border: 1px solid #444;
            border-radius: 8px;
            color: #e0e0e0;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #bb86fc;
        }
        
        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }
        
        .submit-btn {
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
            margin-top: 10px;
        }
        
        .submit-btn:hover {
            background: linear-gradient(135deg, #2196f3, #1565c0);
            box-shadow: 0 5px 15px rgba(0, 100, 200, 0.4);
        }
        
        /* Notification Sidebar */
        .notify-btn {
            padding: 12px 20px;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            border: none;
            border-radius: 6px;
            color: white;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        }
        
        .notify-btn:hover {
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
        .sidebar-modal {
            position: fixed;
            top: 0;
            right: -450px;
            width: 450px;
            height: 100%;
            background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
            box-shadow: -4px 0 15px rgba(0,0,0,0.6);
            transition: right 0.3s ease;
            z-index: 1000;
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-modal.active {
            right: 0;
        }
        
        .sidebar-header {
            padding: 15px;
            background: #0d47a1;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 1.2rem;
            font-weight: bold;
        }
        
        .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        .notifications {
            padding: 20px;
            flex: 1;
            overflow-y: auto;
        }
        
        .notification {
            background: #2a2a2a;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 5px solid #1e88e5;
            transition: background 0.2s;
        }
        
        .notification:hover {
            background: #333;
        }
        
        .notification-title {
            font-weight: 600;
            margin-bottom: 5px;
            color: #bb86fc;
        }
        
        .notification-time {
            font-size: 0.8rem;
            color: #aaa;
        }
        
        .overlay {
            position: fixed;
            top: 0; 
            left: 0;
            width: 100%; 
            height: 100%;
            background: rgba(0,0,0,0.6);
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease;
            z-index: 999;
        }
        
        .overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        /* Footer Styles */
        footer {
            background: #1a1a1a;
            color: #e0e0e0;
            padding: 40px 0 20px;
            margin-top: auto;
        }
        
        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }
        
        .footer-section h3 {
            color: #bb86fc;
            margin-bottom: 20px;
            font-size: 1.2rem;
        }
        
        .footer-section p {
            margin-bottom: 15px;
            line-height: 1.6;
        }
        
        .footer-links {
            list-style: none;
        }
        
        .footer-links li {
            margin-bottom: 10px;
        }
        
        .footer-links a {
            color: #e0e0e0;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: #bb86fc;
        }
        
        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 15px;
        }
        
        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            background: #333;
            border-radius: 50%;
            color: #e0e0e0;
            transition: all 0.3s;
        }
        
        .social-links a:hover {
            background: #bb86fc;
            color: #121212;
            transform: translateY(-3px);
        }
        
        .footer-bottom {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #333;
            color: #888;
            font-size: 0.9rem;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #666;
            background-color: #1e1e1e;
            border-radius: 15px;
            margin: 20px 0;
            grid-column: 1 / -1;
        }
        
        .empty-state h3 {
            margin-bottom: 10px;
            color: #bb86fc;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .main-content {
                padding: 20px 15px;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            .competitions-grid {
                grid-template-columns: 1fr;
            }
            
            .modal-content {
                width: 95%;
                margin: 10% auto;
            }
            
            .sidebar-modal {
                width: 85%;
                right: -85%;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav>
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-book-open"></i>
                <span>Ebook World</span>
            </div>
            <div class="links">
               <a href="index.php">Home</a>
              <a href="about.php">About us</a>
              <a href="contact.php">Contact us</a>
              <a href="login.php">Login</a>
                <a href="events.php">Events</a>
                <a href="books.php">Browse Books</a>
                <a href="competition.php">Competition</a>
                <a href="cart/cart.php">Cart</a>
                <a href="user/dashboard.php">Dashboard</a>
                <a href="#" onclick="openSidebar()">Notifications</a>
                 <a href="logout.php" style='color:red' >logout</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <h1>🏆 Story Competitions - Apply Now</h1>
        
        <p class="page-description">
            Discover exciting story writing competitions and showcase your talent. 
            Apply now for a chance to win amazing prizes and get your work recognized!
        </p>
        
        <div class="competitions-grid">
            <?php 
            if(mysqli_num_rows($run) > 0) { 
                while ($row = mysqli_fetch_assoc($run)) { 
            ?>
            <div class="competition-card">
                <div class="card-header">
                    <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                </div>
                <div class="card-body">
                    <div class="card-details">
                        <div class="detail-item">
                            <span class="detail-label">Description:</span>
                            <span class="detail-value"><?php echo htmlspecialchars($row['description']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Duration:</span>
                            <span class="detail-value"><?php echo htmlspecialchars($row['duration']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Previous Winner:</span>
                            <span class="detail-value"><?php echo htmlspecialchars($row['previuos_winner']); ?></span>
                        </div>
                    </div>
                    <div class="prize-highlight">
                        Prize: <?php echo htmlspecialchars($row['price']); ?>
                    </div>
                    <button class="apply-btn" onclick='notify()'>
                        Apply for this Competition
                    </button>
                </div>
            </div>
            <?php 
                } 
            } else { 
            ?>
            <div class="empty-state">
                <h3>No Active Competitions</h3>
                <p>Check back later for new story competitions!</p>
            </div>
            <?php } ?>
        </div>
    </div>
    
    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-section">
                <h3>About Ebook World</h3>
                <p>Your premier destination for digital books, story competitions, and literary events. Join our community of readers and writers today.</p>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
            
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul class="footer-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="books.php">Browse Books</a></li>
                    <li><a href="competition.php">Competitions</a></li>
                    <li><a href="events.php">Events</a></li>
                    <li><a href="about.php">About Us</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3>Help & Support</h3>
                <ul class="footer-links">
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="#">FAQs</a></li>
                    <li><a href="#">Terms of Service</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Refund Policy</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3>Contact Info</h3>
                <p><i class="fas fa-map-marker-alt"></i> 123 Book Street, Literary City</p>
                <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
                <p><i class="fas fa-envelope"></i> info@ebookworld.com</p>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Ebook World. All rights reserved.</p>
        </div>
    </footer>
    
  
    <div id="applicationModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Apply for Competition</h2>
                <button class="close-btn">&times;</button>
            </div>
            <div class="modal-body">
                <form id="applicationForm" action="submit_application.php" method="POST">
                    <input type="hidden" id="competitionId" name="competition_id">
                    
                    <div class="form-group">
                        <label for="fullName">Full Name</label>
                        <input type="text" id="fullName" name="full_name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="storyTitle">Story Title</label>
                        <input type="text" id="storyTitle" name="story_title" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="storyContent">Your Story</label>
                        <textarea id="storyContent" name="story_content" class="form-control" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="storyGenre">Story Genre</label>
                        <select id="storyGenre" name="story_genre" class="form-control" required>
                            <option value="">Select a genre</option>
                            <option value="Fiction">Fiction</option>
                            <option value="Non-Fiction">Non-Fiction</option>
                            <option value="Fantasy">Fantasy</option>
                            <option value="Science Fiction">Science Fiction</option>
                            <option value="Mystery">Mystery</option>
                            <option value="Romance">Romance</option>
                            <option value="Horror">Horror</option>
                            <option value="Thriller">Thriller</option>
                            <option value="Historical">Historical</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="wordCount">Word Count</label>
                        <input type="number" id="wordCount" name="word_count" class="form-control" min="1" required>
                    </div>
                    
                    <button type="submit" class="submit-btn">Submit Application</button>
                </form>
            </div>
        </div>
    </div>
    
   
    <div class="overlay" id="overlay" onclick="closeSidebar()"></div>
    <div class="sidebar-modal" id="sidebarModal">
        <div class="sidebar-header">
            Notifications
            <button class="close-btn" onclick="closeSidebar()">&times;</button>
        </div>
        <div class="notifications">
            <?php while($row = mysqli_fetch_assoc($notificationRun)) { ?>
                <div class="notification">
                    <div class="notification-title"><?php echo $row['title']; ?></div>
                    <p><?php echo $row['description']; ?></p>
                    <div class="notification-time"><?php echo $row['created_at']; ?></div>
                </div>
            <?php } ?>
        </div>
    </div>
    
    <script>
        // Modal functionality
        // document.addEventListener('DOMContentLoaded', function() {
        //     const modal = document.getElementById('applicationModal');
        //     const applyButtons = document.querySelectorAll('.apply-btn');
        //     const closeBtn = document.querySelector('.modal .close-btn');
        //     const modalTitle = document.getElementById('modalTitle');
        //     const competitionIdInput = document.getElementById('competitionId');
            
        //     // Open modal when apply button is clicked
        //     applyButtons.forEach(button => {
        //         button.addEventListener('click', function() {
        //             const competitionId = this.getAttribute('data-id');
        //             const competitionName = this.getAttribute('data-name');
                    
        //             competitionIdInput.value = competitionId;
        //             modalTitle.textContent = `Apply for: ${competitionName}`;
        //             modal.style.display = 'block';
        //         });
        //     });
            
        //     // Close modal when close button is clicked
        //     closeBtn.addEventListener('click', function() {
        //         modal.style.display = 'none';
        //     });
            
        //     // Close modal when clicking outside the modal content
        //     window.addEventListener('click', function(event) {
        //         if (event.target === modal) {
        //             modal.style.display = 'none';
        //         }
        //     });
            
        //     // Form submission handling
        //     const applicationForm = document.getElementById('applicationForm');
        //     applicationForm.addEventListener('submit', function(e) {
        //         e.preventDefault();
                
        //         // Here you would typically send the form data to the server
        //         // For now, we'll just show an alert and close the modal
        //         alert('Your application has been submitted successfully!');
        //         modal.style.display = 'none';
        //         applicationForm.reset();
                
        //         // In a real implementation, you would use AJAX to submit the form
        //         // without refreshing the page
        //     });
        // });
        
        // Notification sidebar functions
        function openSidebar() {
            document.getElementById("sidebarModal").classList.add("active");
            document.getElementById("overlay").classList.add("active");
        }

        function closeSidebar() {
            document.getElementById("sidebarModal").classList.remove("active");
            document.getElementById("overlay").classList.remove("active");
        }
        function notify(){
            window.location.href='form.php';
        }
        (function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="3muZwl8ydn2bOkQ31Fx3A";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();

    </script>
</body>
</html>