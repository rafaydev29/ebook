<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events - Ebook World</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #8B80F9;
            --secondary: #FF6584;
            --accent: #4CD8E1;
            --dark: #121212;
            --darker: #0A0A0A;
            --light: #E0E0E0;
            --lighter: #F5F5F5;
            --gray: #2A2A2A;
            --gray-light: #3A3A3A;
            --success: #42B883;
            --text-primary: #E0E0E0;
            --text-secondary: #A0A0A0;
            
            /* Dark theme variables */
            --bg-color: #121212;
            --bg-gradient: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            --card-bg: #242442;
            --text-color: #F8F9FC;
            --text-secondary: #b0b0c0;
            --nav-bg: linear-gradient(to right, #5a54d6, #2fc7d1);
            --shadow: rgba(0, 0, 0, 0.3);
            --footer-bg: #0f0f1a;
        }

        body {
            background: var(--bg-gradient);
            color: var(--text-color);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            /* width: 90%; */
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Theme Toggle */
        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px var(--shadow);
            transition: all 0.3s ease;
        }

        .theme-toggle:hover {
            transform: scale(1.1);
            background: #7a6ff0;
        }

        /* Navigation */
        /* nav {
            background: var(--nav-bg);
            color: white;
            padding: 20px 0;
            box-shadow: 0 4px 12px var(--shadow);
            position: sticky;
            top: 0;
            /* z-index: 100; 
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%; 
            max-width: 1200px;
            margin: 0 auto;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .logo i {
            margin-right: 10px;
            color: var(--lighter);
        }

        .links {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            margin: 0 15px;
            transition: all 0.3s ease;
            padding: 8px 5px;
        }

        .links a:hover {
            color: var(--lighter);
            text-shadow: 0 0 5px rgba(255, 255, 255, 0.5);
        } */

        /* Mobile Menu */
        .menu-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .menu-toggle:hover {
            color: var(--lighter);
        }

        /* Hero Section */
        .events-hero {
            text-align: center;
            padding: 80px 0;
           background: linear-gradient(rgba(43, 42, 51, 0.9), rgba(12, 36, 38, 0.9)), 
                        radial-gradient(circle at top left, rgba(139, 128, 249, 0.2) 0%, transparent 50%),
                        radial-gradient(circle at bottom right, rgba(76, 216, 225, 0.2) 0%, transparent 50%),
                        var(--darker);
            color: white;
            border-radius: 0 0 40px 40px;
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
        }

        /* .events-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><rect fill="white" opacity="0.05" width="10" height="10"/></svg>');
            z-index: 0;
        } */

        .page-title {
            font-size: 3.5rem;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
            position: relative;
            z-index: 1;
        }

        .page-subtitle {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto 30px;
            color: var(--lighter);
            position: relative;
            z-index: 1;
        }

        /* Events Grid */
        .events-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 30px;
            margin-bottom: 60px;
        }

        .event-card {
            background: var(--card-bg);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px var(--shadow);
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        .event-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
            border-color: rgba(255, 255, 255, 0.1);
        }

        .event-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
            filter: brightness(0.9);
            transition: filter 0.3s ease;
        }

        .event-card:hover .event-image {
            filter: brightness(1);
        }

        .event-content {
            padding: 25px;
        }

        .event-date {
            color: var(--primary);
            font-weight: 600;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
        }

        .event-date i {
            margin-right: 8px;
        }

        .event-title {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: var(--text-color);
        }

        .event-description {
            color: var(--text-secondary);
            margin-bottom: 20px;
        }

        .event-meta {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            color: var(--text-secondary);
        }

        .event-meta span {
            display: flex;
            align-items: center;
        }

        .event-meta i {
            margin-right: 5px;
        }

        .event-button {
            display: inline-block;
            background: var(--secondary);
            color: white;
            padding: 12px 25px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(255, 101, 132, 0.4);
            text-align: center;
            width: 100%;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }

        .event-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(255, 101, 132, 0.6);
            background: #ff4d72;
        }

        /* Newsletter Section */
        .newsletter {
            /* background: linear-gradient(rgba(43, 42, 51, 0.9), rgba(12, 36, 38, 0.9)), 
                        radial-gradient(circle at top left, rgba(139, 128, 249, 0.2) 0%, transparent 50%),
                        radial-gradient(circle at bottom right, rgba(76, 216, 225, 0.2) 0%, transparent 50%),
                        var(--darker); */
            color: white;
            padding: 60px 0;
            border-radius: 40px;
            margin-bottom: 60px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        /* .newsletter::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><rect fill="white" opacity="0.05" width="10" height="10"/></svg>');
            z-index: 0;
        } */

        .newsletter h2 {
            font-size: 2.2rem;
            margin-bottom: 20px;
            position: relative;
            z-index: 1;
        }

        .newsletter p {
            max-width: 600px;
            margin: 0 auto 30px;
            font-size: 1.1rem;
            position: relative;
            z-index: 1;
        }

        .newsletter-form {
            display: flex;
            justify-content: center;
            max-width: 500px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }

        .newsletter-input {
            flex: 1;
            padding: 15px 20px;
            border: none;
            border-radius: 30px 0 0 30px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.9);
            color: var(--dark);
        }

        .newsletter-button {
            background: var(--secondary);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 0 30px 30px 0;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .newsletter-button:hover {
            background: #ff4d72;
        }

        /* Footer */
        /* .footer {
            background: var(--footer-bg);
            color: white;
            padding: 60px 0 20px;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }

        .footer-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
        }

        .footer-content h2 {
            font-size: 2.2rem;
            margin-bottom: 20px;
        }

        .footer-content p {
            max-width: 600px;
            margin-bottom: 30px;
            color: var(--text-secondary);
        }

        .footer-icons {
            display: flex;
            gap: 20px;
        }

        .footer-icons a {
            color: var(--text-secondary);
            font-size: 1.5rem;
            transition: all 0.3s ease;
        }

        .footer-icons a:hover {
            color: var(--accent);
        }

        .footer-bottom {
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            color: var(--text-secondary);
        } */

        /* Dark theme scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--dark);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--gray-light);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .events-grid {
                grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                gap: 20px;
            }
        }

        @media (max-width: 900px) {
            .nav-container {
                flex-direction: row;
                text-align: center;
            }

            .links {
                display: none;
                flex-direction: column;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                /* background: var(--gray); */
                padding: 20px;
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
                z-index: 99;
                /* border-top: 1px solid rgba(255, 255, 255, 0.1); */
            }

            .links.active {
                display: flex;
            }

            .links a {
                margin: 10px 0;
                padding: 10px;
                /* border-bottom: 1px solid rgba(255, 255, 255, 0.1); */
            }

            .menu-toggle {
                display: block;
            }

            .page-title {
                font-size: 2.5rem;
            }
        }

        @media (max-width: 768px) {
            .events-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .newsletter-form {
                flex-direction: column;
                gap: 15px;
            }

            .newsletter-input, .newsletter-button {
                border-radius: 30px;
                width: 100%;
            }

            .theme-toggle {
                top: 80px;
                right: 20px;
            }

            .event-meta {
                flex-direction: column;
                gap: 10px;
            }
        }

        @media (max-width: 480px) {
            .page-title {
                font-size: 2rem;
            }

            .page-subtitle {
                font-size: 1rem;
            }

            .event-card {
                margin: 0 10px;
            }

            .footer-icons {
                flex-wrap: wrap;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
  

    <!-- <nav>
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-book-open"></i>
                <span>Ebook World</span>
            </div>
            <button class="menu-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </button>
            <div class="links" id="navLinks">
                <a href="events.html">Events</a>
                <a href="contact.html">Contact us</a>
                <a href="index.html">Home</a>
                <a href="about.html">About us</a>
                <a href="login.html">Login</a>
                <a href="user/dashboard.html">Dashboard</a>
                <a href="categories.html">Categories</a>
                <a href="competition.html">Competition</a>
                <a href="cart.html">Cart</a>
            </div>
        </div>
    </nav> -->
    <?php include 'nav.php'; ?>
    <section class="events-hero">
        <div class="container">
            <h1 class="page-title">Upcoming Events</h1>
            <p class="page-subtitle">Join our community events to connect with authors, participate in discussions, and expand your reading horizons.</p>
        </div>
    </section>

    <div class="container">
        <div class="events-grid">
            <!-- Event 1 -->
            <div class="event-card">
                <img src="https://images.unsplash.com/photo-1516979187457-637abb4f9353?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Author Meetup" class="event-image">
                <div class="event-content">
                    <div class="event-date"><i class="fas fa-calendar-alt"></i> June 15, 2025 | 6:00 PM EST</div>
                    <h3 class="event-title">Author Meet & Greet</h3>
                    <p class="event-description">Join bestselling author Jane Doe for an intimate discussion of her latest novel and Q&A session.</p>
                    <div class="event-meta">
                        <span><i class="fas fa-users"></i> 45 spots left</span>
                        <span><i class="fas fa-map-marker-alt"></i> Virtual Event</span>
                    </div>
                    <a href="#" class="event-button">Register Now</a>
                </div>
            </div>
            
            <!-- Event 2 -->
            <div class="event-card">
                <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Book Club" class="event-image">
                <div class="event-content">
                    <div class="event-date"><i class="fas fa-calendar-alt"></i> June 22, 2025 | 7:30 PM EST</div>
                    <h3 class="event-title">Monthly Book Club</h3>
                    <p class="event-description">This month we're discussing "The Midnight Library" by Matt Haig. All readers welcome!</p>
                    <div class="event-meta">
                        <span><i class="fas fa-users"></i> 32 spots left</span>
                        <span><i class="fas fa-map-marker-alt"></i> Virtual Event</span>
                    </div>
                    <a href="#" class="event-button">Join Discussion</a>
                </div>
            </div>
            
            <!-- Event 3 -->
            <div class="event-card">
                <img src="https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Writing Workshop" class="event-image">
                <div class="event-content">
                    <div class="event-date"><i class="fas fa-calendar-alt"></i> July 5-6, 2025 | 10:00 AM EST</div>
                    <h3 class="event-title">Creative Writing Workshop</h3>
                    <p class="event-description">A two-day intensive workshop focused on developing characters and building compelling narratives.</p>
                    <div class="event-meta">
                        <span><i class="fas fa-users"></i> 18 spots left</span>
                        <span><i class="fas fa-map-marker-alt"></i> Virtual Event</span>
                    </div>
                    <a href="#" class="event-button">Reserve Spot</a>
                </div>
            </div>
            
            <!-- Event 4 -->
            <div class="event-card">
                <img src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Poetry Night" class="event-image">
                <div class="event-content">
                    <div class="event-date"><i class="fas fa-calendar-alt"></i> July 12, 2025 | 8:00 PM EST</div>
                    <h3 class="event-title">Poetry Reading Night</h3>
                    <p class="event-description">An evening of poetry featuring established and emerging poets. Open mic session included.</p>
                    <div class="event-meta">
                        <span><i class="fas fa-users"></i> 56 spots left</span>
                        <span><i class="fas fa-map-marker-alt"></i> Virtual Event</span>
                    </div>
                    <a href="#" class="event-button">Join Event</a>
                </div>
            </div>
            
            <!-- Event 5 -->
            <div class="event-card">
                <img src="https://images.unsplash.com/photo-1532012197267-da84d127e765?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Publishing Seminar" class="event-image">
                <div class="event-content">
                    <div class="event-date"><i class="fas fa-calendar-alt"></i> July 20, 2025 | 2:00 PM EST</div>
                    <h3 class="event-title">Publishing 101 Seminar</h3>
                    <p class="event-description">Learn about the publishing process from industry experts. Perfect for aspiring authors.</p>
                    <div class="event-meta">
                        <span><i class="fas fa-users"></i> 24 spots left</span>
                        <span><i class="fas fa-map-marker-alt"></i> Virtual Event</span>
                    </div>
                    <a href="#" class="event-button">Register</a>
                </div>
            </div>
            
            <!-- Event 6 -->
            <div class="event-card">
                <img src="https://images.unsplash.com/photo-1457369804613-52c61a468e7d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Children's Storytime" class="event-image">
                <div class="event-content">
                    <div class="event-date"><i class="fas fa-calendar-alt"></i> July 27, 2025 | 11:00 AM EST</div>
                    <h3 class="event-title">Children's Storytime</h3>
                    <p class="event-description">Interactive story reading session for children ages 3-8. Includes fun activities and discussions.</p>
                    <div class="event-meta">
                        <span><i class="fas fa-users"></i> 40 spots left</span>
                        <span><i class="fas fa-map-marker-alt"></i> Virtual Event</span>
                    </div>
                    <a href="#" class="event-button">Sign Up</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="newsletter">
        <div class="container">
            <h2>Stay Updated on Future Events</h2>
            <p>Subscribe to our newsletter to receive notifications about upcoming events, author interviews, and exclusive content.</p>
            <form class="newsletter-form">
                <input type="email" placeholder="Your email address" class="newsletter-input" required>
                <button type="submit" class="newsletter-button">Subscribe</button>
            </form>
        </div>
    </div>

    <!-- <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <h2 class="logo">Ebook World</h2>
                <p>Dive into the world of ebooks with us. Read, learn, and explore.</p>
                <div class="footer-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-tiktok"></i></a>
                    <a href="#"><i class="fab fa-discord"></i></a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Ebook World | All Rights Reserved</p>
            </div>
        </div>
    </footer> -->
    <?php include 'footer.php'; ?>

    <script>
        // Theme Toggle Functionality
        const themeToggle = document.getElementById('themeToggle');
        const themeIcon = themeToggle.querySelector('i');
        
        // Set dark theme as default
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
        
        themeToggle.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            
            // Update icon
            if (newTheme === 'dark') {
                themeIcon.classList.remove('fa-moon');
                themeIcon.classList.add('fa-sun');
            } else {
                themeIcon.classList.remove('fa-sun');
                themeIcon.classList.add('fa-moon');
            }
        });
        
        // Mobile Menu Toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        
        menuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            
            // Change menu icon
            const icon = menuToggle.querySelector('i');
            if (navLinks.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
        
        // Close mobile menu when clicking on a link
        document.querySelectorAll('.links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                const icon = menuToggle.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            });
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!navLinks.contains(event.target) && !menuToggle.contains(event.target)) {
                navLinks.classList.remove('active');
                const icon = menuToggle.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });

        // Event card hover effect enhancement
        document.querySelectorAll('.event-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-10px)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
    </script>
</body>
</html>