<?php
session_start();
include '../config.php'; 

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'not_logged_in']);
    exit;
}

$book_id = intval($_POST['book_id']);


if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (!in_array($book_id, $_SESSION['cart'])) {
    $_SESSION['cart'][] = $book_id;
}

echo json_encode(['status' => 'success']);
