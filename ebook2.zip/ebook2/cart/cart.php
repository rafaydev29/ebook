<?php
session_start();
include '../config.php';

$cart_items = $_SESSION['cart'] ?? [];

if (empty($cart_items)) {
    echo "<h2>Your cart is empty.</h2>";
    echo "<h2>add something to cart for purchase.</h2>";
    echo '<a href="../index.php">Back to Library</a>';
    exit;
}


$ids = implode(",", array_map('intval', $cart_items));
$query = "SELECT id, title, price FROM fiction WHERE id IN ($ids)";
$result = mysqli_query($conn, $query);

$total = 0;
$books = [];
while ($row = mysqli_fetch_assoc($result)) {
    $row['price'] = (float)$row['price']; 
    $books[] = $row;
    $total += $row['price']; }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Cart - Dark Library</title>
  <style>
    :root {
      --bg-primary: #121212;
      --bg-secondary: #1e1e1e;
      --bg-card: #2d2d2d;
      --text-primary: #e0e0e0;
      --text-secondary: #a0a0a0;
      --accent: #7c4dff;
      --accent-hover: #6a3dff;
      --danger: #ff5252;
      --success: #4caf50;
      --border: #404040;
      --shadow: rgba(0, 0, 0, 0.5);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      background-color: var(--bg-primary);
      color: var(--text-primary);
      line-height: 1.6;
      padding: 0;
      margin: 0;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }

    header {
      background-color: var(--bg-secondary);
      padding: 20px 0;
      box-shadow: 0 4px 12px var(--shadow);
      margin-bottom: 30px;
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }

    h1 {
      font-size: 2.2rem;
      margin-bottom: 10px;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .back-link {
      color: var(--text-secondary);
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 5px;
      transition: color 0.3s;
      padding: 8px 15px;
      border-radius: 4px;
      background-color: var(--bg-card);
    }

    .back-link:hover {
      color: var(--accent);
      background-color: rgba(124, 77, 255, 0.1);
    }

    .cart-container {
      display: grid;
      grid-template-columns: 1fr;
      gap: 30px;
    }

    @media (min-width: 768px) {
      .cart-container {
        grid-template-columns: 1fr 1fr;
      }
    }

    .cart-items {
      background-color: var(--bg-secondary);
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 4px 12px var(--shadow);
    }

    .cart-items h2 {
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid var(--border);
      color: var(--text-primary);
    }

    .book-list {
      list-style: none;
    }

    .book-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 0;
      border-bottom: 1px solid var(--border);
    }

    .book-item:last-child {
      border-bottom: none;
    }

    .book-info {
      flex-grow: 1;
    }

    .book-title {
      font-weight: 600;
      margin-bottom: 5px;
    }

    .book-price {
      color: var(--accent);
      font-weight: 600;
    }

    .remove-btn {
      color: var(--danger);
      text-decoration: none;
      margin-left: 15px;
      padding: 5px 10px;
      border-radius: 4px;
      transition: background-color 0.3s;
    }

    .remove-btn:hover {
      background-color: rgba(255, 82, 82, 0.1);
    }

    .download-link {
      display: none;
      color: var(--success);
      text-decoration: none;
      margin-left: 15px;
      padding: 8px 15px;
      border-radius: 4px;
      background-color: rgba(76, 175, 80, 0.1);
      transition: background-color 0.3s;
    }

    .download-link:hover {
      background-color: rgba(76, 175, 80, 0.2);
    }

    .total-section {
      /* background-color: var(--bg-secondary); */
      background-color: #312e2eff;
      border-radius: 8px;
      padding: 20px;
      margin-top: 20px;
      box-shadow: 0 4px 12px var(--shadow);
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 1.2rem;
    }

    .total-amount {
      color: var(--accent);
      font-weight: bold;
      font-size: 1.4rem;
    }

    .payment-section {
      background-color: var(--bg-secondary);
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 4px 12px var(--shadow);
    }

    .payment-section h2 {
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid var(--border);
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .payment-form {
      display: grid;
      grid-template-columns: 1fr;
      gap: 20px;
    }

    @media (min-width: 480px) {
      .payment-form {
        grid-template-columns: 1fr 1fr;
      }
      
      .form-group.full-width {
        grid-column: 1 / -1;
      }
    }

    .form-group {
      display: flex;
      flex-direction: column;
    }

    .form-group label {
      margin-bottom: 8px;
      color: var(--text-secondary);
      font-weight: 500;
    }

    .form-group input {
      padding: 12px 15px;
      border: 1px solid var(--border);
      border-radius: 4px;
      background-color: var(--bg-card);
      color: var(--text-primary);
      font-size: 1rem;
      transition: border-color 0.3s;
    }

    .form-group input:focus {
      outline: none;
      border-color: var(--accent);
    }

    .amount-input {
      position: relative;
    }

    .amount-input::before {
      content: "$";
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--text-secondary);
    }

    .amount-input input {
      padding-left: 30px;
    }

    .submit-btn {
      grid-column: 1 / -1;
      padding: 14px;
      background-color: var(--accent);
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.3s;
      margin-top: 10px;
    }

    .submit-btn:hover {
      background-color: var(--accent-hover);
    }

    .empty-cart {
      text-align: center;
      padding: 40px 20px;
      background-color: var(--bg-secondary);
      border-radius: 8px;
      box-shadow: 0 4px 12px var(--shadow);
    }

    .empty-cart h2 {
      margin-bottom: 20px;
      color: var(--text-secondary);
    }

    .success-message {
      display: none;
      background-color: rgba(76, 175, 80, 0.1);
      color: var(--success);
      padding: 15px;
      border-radius: 4px;
      margin-top: 20px;
      text-align: center;
    }

    footer {
      text-align: center;
      margin-top: 40px;
      padding: 20px;
      color: var(--text-secondary);
      font-size: 0.9rem;
      border-top: 1px solid var(--border);
    }
  </style>
</head>
<body>
  <header>
    <div class="container">
      <div class="header-content">
        <h1>🛒 Your Shopping Cart</h1>
        <a href="../books.php" class="back-link">⬅ Back to Library</a>
      </div>
    </div>
  </header>

  <div class="container">
    <div class="cart-container">
      <div class="cart-items">
        <h2>Items in Your Cart</h2>
        <ul class="book-list">
          <?php foreach ($books as $row) { ?>
            <li class="book-item">
              <div class="book-info">
                <div class="book-title"><?php echo htmlspecialchars($row['title']); ?></div>
                <div class="book-price">$<?php echo number_format($row['price'], 2); ?></div>
              </div>
              <div>
                <a class="download-link" href="download.php?id=<?php echo $row['id']; ?>">📥 Download</a>
                <a class="remove-btn" href="remove_from_cart.php?id=<?php echo $row['id']; ?>" id='remove'>❌ Remove</a>
              </div>
            </li>
          <?php } ?>
        </ul>
        
        <div class="total-section">
          <span>Total Amount:</span>
          <span class="total-amount">$<?php echo number_format($total, 2); ?></span>
        </div>
      </div>

      <div class="payment-section">
        <h2>💳 Payment Information</h2>
        <form id="paymentForm" class="payment-form">
          <div class="form-group full-width">
            <label for="name">Name on Card</label>
            <input type="text" id="name" name="name" required>
          </div>
          
          <div class="form-group full-width">
            <label for="card">Card Number</label>
            <input type="text" id="card" name="card" placeholder="1234 5678 9012 3456" required>
          </div>
          
          <div class="form-group">
            <label for="expiry">Expiry Date</label>
            <input type="text" id="expiry" name="expiry" placeholder="MM/YY" required>
          </div>
          
          <div class="form-group">
            <label for="cvv">CVV</label>
            <input type="password" id="cvv" name="cvv" required>
          </div>
          
          <div class="form-group full-width amount-input">
            <label for="amount">Enter Total Amount ($<?php echo number_format($total, 2); ?>)</label>
            <input type="number" step="0.01" id="amount" required>
          </div>
          
          <button type="submit" class="submit-btn">Pay Now</button>
        </form>
        
        <div id="successMessage" class="success-message">
          ✅ Payment successful! You can now download your books.
        </div>
      </div>
    </div>
  </div>

  <footer>
    <div class="container">
      <p>© <?php echo date('Y'); ?> Dark Library. All rights reserved.</p>
    </div>
  </footer>

  <script>
    const form = document.getElementById('paymentForm');
    const successMessage = document.getElementById('successMessage');
    const remove = document.getElementById('remove');

    const total = <?php echo $total; ?>; 
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const enteredAmount = parseFloat(document.getElementById('amount').value);

        if (enteredAmount !== total) {
            alert("❌ Please enter the exact total amount: $" + total.toFixed(2));
            return;
        }

        
        successMessage.style.display = "block";
        
        
        document.querySelectorAll('.download-link').forEach(link => {
            link.style.display = "inline-block";
        });

       
        form.style.display = "none";
        
    
        successMessage.scrollIntoView({ behavior: 'smooth' });
    });
    (function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="3muZwl8ydn2bOkQ31Fx3A";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();

  </script>
</body>
</html>