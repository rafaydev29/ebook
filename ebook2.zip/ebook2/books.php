<?php
session_start();
include 'config.php'; 

$selected_cate = isset($_GET['cate']) ? $_GET['cate'] : "";

$search_query = isset($_GET['search']) ? $_GET['search'] : "";

$where_conditions = [];

if ($selected_cate && $selected_cate != "all") {
    $where_conditions[] = "cate = '" . mysqli_real_escape_string($conn, $selected_cate) . "'";
}

if ($search_query) {
    $where_conditions[] = "title LIKE '%" . mysqli_real_escape_string($conn, $search_query) . "%'";
}

if (count($where_conditions) > 0) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
} else {
    $where_clause = "";
}

$query = "SELECT id, title, cate, cv FROM fiction " . $where_clause . " ORDER BY uploaded_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Ebook Library</title>
  <style>
    /* Dark Theme CSS */
    :root {
      --bg-primary: #121212;
      --bg-secondary: #1e1e1e;
      --bg-card: #2d2d2d;
      --text-primary: #e0e0e0;
      --text-secondary: #a0a0a0;
      --accent-color: #bb86fc;
      --accent-hover: #9d65d0;
      --border-color: #333;
      --shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
      --container-max-width: 1200px;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      background-color: var(--bg-primary);
      color: var(--text-primary);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      line-height: 1.6;
      padding: 0;
      min-height: 100vh;
    }

    .container {
      max-width: var(--container-max-width);
      margin: 0 auto;
      padding: 20px;
    }

    /* Banner Styles */
    .banner {
      background: linear-gradient(135deg, var(--bg-secondary) 0%, #2a2a2a 100%);
      border-bottom: 1px solid var(--border-color);
      padding: 30px 20px;
      margin-bottom: 30px;
      box-shadow: var(--shadow);
      border-radius: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .banner h1 {
      margin: 0;
      color: var(--accent-color);
      font-size: 2.5rem;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    }

    .banner a {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 12px 24px;
      background-color: var(--accent-color);
      color: var(--bg-primary);
      text-decoration: none;
      border-radius: 6px;
      font-weight: bold;
      transition: all 0.3s ease;
      font-size: 1rem;
    }

    .banner a:hover {
      background-color: var(--accent-hover);
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    /* Filter and Search Container */
    .filter-search-container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      background-color: var(--bg-secondary);
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 30px;
      box-shadow: var(--shadow);
    }

    .filter-container, .search-container {
      display: flex;
      flex-direction: column;
    }

    .filter-container label, .search-container label {
      display: block;
      margin-bottom: 10px;
      font-weight: bold;
      color: var(--text-primary);
      font-size: 1.1rem;
    }

    .filter-container select, .search-container input {
      background-color: var(--bg-card);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      padding: 12px 15px;
      border-radius: 6px;
      width: 100%;
      font-size: 1rem;
    }

    .filter-container select:focus, .search-container input:focus {
      outline: none;
      border-color: var(--accent-color);
      box-shadow: 0 0 0 2px rgba(187, 134, 252, 0.2);
    }

    .search-container {
  display: flex;
  flex-direction: column;
}

.search-container label {
  margin-bottom: 8px;
  font-weight: bold;
  color: var(--text-primary);
}

.search-box {
  display: flex;
  align-items: center;
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 6px;
  overflow: hidden;
  box-shadow: var(--shadow);
}

.search-box input {
  flex: 1;
  padding: 12px 15px;
  background: transparent;
  border: none;
  outline: none;
  color: var(--text-primary);
  font-size: 1rem;
}

.search-box button {
  background: var(--accent-color);
  color: var(--bg-primary);
  border: none;
  padding: 12px 20px;
  cursor: pointer;
  font-weight: bold;
  transition: background 0.3s ease;
}

.search-box button:hover {
  background: var(--accent-hover);
}

    /* Ebook Cards */
    .ebooks-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 25px;
      margin-top: 20px;
    }

    .ebook-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      overflow: hidden;
      box-shadow: var(--shadow);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    .ebook-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.4);
    }

    .ebook-image {
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: var(--bg-secondary);
    }

    .ebook-card img {
      width: 100%;
      height: 100%;
      transition: transform 0.5s ease;
    }

    .ebook-card:hover img {
      transform: scale(1.05);
    }

    .ebook-content {
      padding: 20px;
      display: flex;
      flex-direction: column;
      flex-grow: 1;
    }

    .ebook-card a {
      text-decoration: none;
      color: var(--text-primary);
    }

    .ebook-card h3 {
      font-size: 1.2rem;
      margin-bottom: 10px;
      transition: color 0.3s ease;
      line-height: 1.4;
    }

    .ebook-card a:hover h3 {
      color: var(--accent-color);
    }

    .ebook-category {
      font-size: 0.9rem;
      color: var(--text-secondary);
      margin-bottom: 15px;
      padding: 5px 10px;
      background-color: rgba(187, 134, 252, 0.1);
      border-radius: 4px;
      display: inline-block;
      align-self: flex-start;
    }

    .add-to-cart {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 10px 15px;
      background: var(--accent-color);
      color: var(--bg-primary);
      border-radius: 6px;
      text-decoration: none;
      font-size: 0.95rem;
      font-weight: bold;
      transition: all 0.3s ease;
      margin-top: auto;
    }

    .add-to-cart:hover {
      background: var(--accent-hover);
      transform: scale(1.03);
    }

    .no-image {
      width: 100%;
      height: 100%;
      background: var(--bg-secondary);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-secondary);
      font-size: 1.1rem;
    }

    hr {
      border: none;
      height: 1px;
      background-color: var(--border-color);
      margin: 25px 0;
    }

    /* Empty State */
    .empty-state {
      text-align: center;
      padding: 40px 20px;
      color: var(--text-secondary);
      grid-column: 1 / -1;
    }

    .empty-state h3 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .container {
        padding: 15px;
      }
      
      .banner {
        padding: 20px 15px;
        flex-direction: column;
        gap: 15px;
        text-align: center;
      }
      
      .banner h1 {
        font-size: 2rem;
      }
      
      .filter-search-container {
        grid-template-columns: 1fr;
        gap: 15px;
      }
      
      .ebooks-container {
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 20px;
      }
      
      .filter-container, .search-container {
        padding: 0;
      }
    }

    @media (max-width: 480px) {
      .ebooks-container {
        grid-template-columns: 1fr;
      }
      
      .banner h1 {
        font-size: 1.8rem;
      }
    }
  </style>
</head>
<body>
  <?php include 'nav.php'; ?>
  <div class="container">
   
    <div class="banner">
      <h1>Ebook Library</h1>
      <a href="cart/cart.php">🛒 View Cart</a>
    </div>

    
    <div class="filter-search-container">
      
      <div class="filter-container">
        <form method="GET" action="">
          <label for="cate">Filter by Category:</label>
          <select name="cate" id="cate" onchange="this.form.submit()">
            <option value="all" <?php if ($selected_cate == "all") echo "selected"; ?>>All Categories</option>
            <option value="tech" <?php if ($selected_cate == "tech") echo "selected"; ?>>Tech</option>
            <option value="fiction" <?php if ($selected_cate == "fiction") echo "selected"; ?>>Fiction</option>
            <option value="non-fictional" <?php if ($selected_cate == "non-fictional") echo "selected"; ?>>Non-Fictional</option>
            <option value="sciencefiction" <?php if ($selected_cate == "sciencefiction") echo "selected"; ?>>Science Fiction</option>
            <option value="mystery&thriller" <?php if ($selected_cate == "mystery&thriller") echo "selected"; ?>>Mystery & Thriller</option>
            <option value="business&finance" <?php if ($selected_cate == "business&finance") echo "selected"; ?>>Business & Finance</option>

            <option value="self-help" <?php if ($selected_cate == "self-help") echo "selected"; ?>>Self-Help</option>
            <option value="solar system" <?php if ($selected_cate == "solar system") echo "selected"; ?>>Solar System</option>
          </select>
          <?php if ($search_query): ?>
            <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
          <?php endif; ?>
        </form>
      </div>

      <div class="search-container">
        <div class="search-container">
  <form method="GET" action="" class="search-form">
    <label for="search">Search by Title:</label>
    <div class="search-box">
      <input 
        type="text" 
        name="search" 
        id="search" 
        placeholder="🔍 Search ebooks..." 
        value="<?php echo htmlspecialchars($search_query); ?>">
      <button type="submit">Search</button>
    </div>
    <?php if ($selected_cate && $selected_cate != "all"): ?>
      <input type="hidden" name="cate" value="<?php echo htmlspecialchars($selected_cate); ?>">
    <?php endif; ?>
  </form>
</div>

      </div>
    </div>

    <hr>

   
    <div class="ebooks-container">
      <?php 
      if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) { 
      ?>
        <div class="ebook-card">
         
          <div class="ebook-image">
            <?php if (!empty($row['cv'])): ?>
              <a href="book-details.php?id=<?php echo $row['id']; ?>">
                <img src="<?php echo htmlspecialchars($row['cv']); ?>" alt='no cover image' >
              </a>
            <?php else: ?>
              <div class="no-image">
                No Cover Image
              </div>
            <?php endif; ?>
          </div>

          <div class="ebook-content">
          
            <a href="book-details.php?id=<?php echo $row['id']; ?>">
              <h3><?php echo htmlspecialchars($row['title']); ?></h3>
            </a>

            <span class="ebook-category"><?php echo htmlspecialchars($row['cate']); ?></span>

                  <a href="#" class="btn btn-primary add-to-cart" data-id="<?php echo $row['id']; ?>">Add to Cart</a>

          </div>
        </div>
      <?php 
        }
      } else {
        echo '<div class="empty-state"><h3>No ebooks found</h3><p>Try selecting a different category or search term</p></div>';
      }
      ?>
    </div>
  </div>
  <?php include 'footer.php'; ?>
  <script>

document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', function(e){
        e.preventDefault();
        const bookId = this.dataset.id;

        fetch('cart/add_to_cart.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'book_id=' + bookId
        })
        .then(res => res.json())
        .then(data => {
            if(data.status === 'success'){
                alert('Book added to cart!');
            } else if(data.status === 'not_logged_in'){
                alert('You must register yourself to add to cart.');
                window.location.href = 'login.php';
            }
        });
    });
});
(function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="3muZwl8ydn2bOkQ31Fx3A";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();

</script>

</body>
</html>