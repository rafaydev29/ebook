<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Essay Writing Competition - Ebook World</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6C63FF;
            --secondary: #FF6584;
            --accent: #36D1DC;
            --dark: #121212;
            --darker: #0A0A0A;
            --light: #F8F9FC;
            --light-dark: #1E1E1E;
            --text: #E0E0E0;
            --text-muted: #A0A0A0;
            --success: #42B883;
            --warning: #FF9F43;
        }

        body {
            background: linear-gradient(135deg, #0A0A0A 0%, #1E1E1E 100%);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            transition: background 0.3s ease;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Navigation */
        nav {
            background: linear-gradient(to right, var(--primary), var(--accent));
            color: white;
            padding: 20px 0;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .logo i {
            margin-right: 10px;
            color: var(--light);
        }

        .links {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            margin: 0 15px;
            transition: all 0.3s ease;
            padding: 8px 5px;
        }

        .links a:hover {
            color: var(--light);
            text-shadow: 0 0 5px rgba(255, 255, 255, 0.5);
        }

        /* Header */
        header {
            text-align: center;
            padding: 40px 0;
            margin-bottom: 30px;
        }

        header h1 {
            font-size: 3rem;
            margin-bottom: 15px;
            color: var(--text);
            background: linear-gradient(to right, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .subtitle {
            font-size: 1.2rem;
            color: var(--text-muted);
            max-width: 700px;
            margin: 0 auto;
        }

        /* Competition Info */
        .competition-info {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            margin-bottom: 40px;
        }

        .info-card {
            flex: 1;
            min-width: 250px;
            background: var(--light-dark);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4);
        }

        .info-card h3 {
            color: var(--primary);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }

        .info-card h3 i {
            margin-right: 10px;
        }

        /* Controls */
        .controls {
            background: var(--light-dark);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
            align-items: center;
        }

        .timer-container {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 600;
        }

        .timer {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary);
            background: var(--darker);
            padding: 10px 20px;
            border-radius: 10px;
            min-width: 120px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .timer.warning {
            color: var(--secondary);
            animation: pulse 1s infinite;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
        }

        .word-count {
            font-weight: 600;
            background: var(--darker);
            padding: 10px 20px;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .word-count span {
            color: var(--primary);
            font-weight: 700;
        }

        .buttons {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 30px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-start {
            background: var(--success);
            color: white;
        }

        .btn-stop {
            background: var(--secondary);
            color: white;
        }

        .btn-reset {
            background: var(--darker);
            color: var(--text);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        /* Writing Area */
        .writing-area {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            margin-bottom: 40px;
        }

        textarea {
            flex: 2;
            min-width: 300px;
            height: 400px;
            padding: 20px;
            background: var(--light-dark);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            font-size: 1.1rem;
            line-height: 1.6;
            resize: vertical;
            transition: border-color 0.3s ease;
            color: var(--text);
        }

        textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.2);
        }

        textarea::placeholder {
            color: var(--text-muted);
        }

        .prompt-section {
            flex: 1;
            min-width: 300px;
            background: var(--light-dark);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
        }

        .prompt-section h3 {
            color: var(--primary);
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid rgba(255, 255, 255, 0.1);
        }

        .prompt-text {
            font-size: 1.1rem;
            line-height: 1.6;
            color: var(--text);
            background: var(--darker);
            padding: 20px;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Footer */
        /* .footer {
            background: var(--darker);
            color: var(--text);
            padding: 40px 0 20px;
            text-align: center;
            margin-top: auto;
        }

        .footer-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
        }

        .footer-content h2 {
            font-size: 2.2rem;
            margin-bottom: 20px;
        }

        .footer-content p {
            max-width: 600px;
            margin-bottom: 30px;
            color: var(--text-muted);
        }

        .footer-icons {
            display: flex;
            gap: 20px;
        }

        .footer-icons a {
            color: var(--text);
            font-size: 1.5rem;
            transition: all 0.3s ease;
        }

        .footer-icons a:hover {
            color: var(--accent);
        }

        .footer-bottom {
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--text-muted);
        } */

        /* Theme Toggle */
        .theme-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--light-dark);
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            z-index: 100;
            transition: all 0.3s ease;
        }

        .theme-toggle:hover {
            transform: scale(1.1);
        }

        .theme-toggle i {
            font-size: 1.5rem;
            color: var(--primary);
        }

        /* Responsive Design */
        @media (max-width: 900px) {
            .nav-container {
                flex-direction: column;
                text-align: center;
            }

            .links {
                margin-top: 20px;
            }

            .links a {
                margin: 5px 10px;
            }

            header h1 {
                font-size: 2.5rem;
            }
        }

        @media (max-width: 768px) {
            .controls {
                flex-direction: column;
                align-items: stretch;
            }

            .timer-container, .word-count {
                justify-content: center;
            }

            .buttons {
                justify-content: center;
            }

            .writing-area {
                flex-direction: column;
            }
            
            .info-card {
                min-width: 100%;
            }
        }

        @media (max-width: 480px) {
            header h1 {
                font-size: 2rem;
            }

            .subtitle {
                font-size: 1rem;
            }

            .links a {
                font-size: 0.9rem;
                margin: 3px 5px;
            }

            .buttons {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .timer {
                font-size: 1.5rem;
                min-width: 100px;
            }
            
            .theme-toggle {
                width: 40px;
                height: 40px;
                bottom: 15px;
                right: 15px;
            }
            
            .theme-toggle i {
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>
  <?php include 'nav.php'; ?>

    <div class="container">
        <header>
            <h1>Essay Writing Competition</h1>
            <p class="subtitle">Test your typing speed and writing skills under time pressure</p>
        </header>
        
        <div class="competition-info">
            <div class="info-card">
                <h3><i class="fas fa-trophy"></i> Prize</h3>
                <p>First place: $1000 + Publication in our magazine<br>
                Second place: $500<br>
                Third place: $250</p>
            </div>
            
            <div class="info-card">
                <h3><i class="fas fa-ruler"></i> Guidelines</h3>
                <p>• Minimum 500 words<br>
                • Original content only<br>
                • Proper grammar and spelling<br>
                • Submit before time expires</p>
            </div>
            
            <div class="info-card">
                <h3><i class="fas fa-calendar"></i> Deadline</h3>
                <p>Competition ends: December 31, 2025<br>
                Winners announced: January 15, 2026<br>
                Results published on our website</p>
            </div>
        </div>
        
        <div class="controls">
            <div class="timer-container">
                <span>Time Remaining:</span>
                <div class="timer" id="timer">30:00</div>
            </div>
            
            <div class="word-count">Words: <span id="word-count">0</span></div>
            
            <div class="buttons">
                <button class="btn btn-start" id="start-btn">
                    <i class="fas fa-play"></i> Start
                </button>
                <button class="btn btn-stop" id="stop-btn" disabled>
                    <i class="fas fa-pause"></i> Pause
                </button>
                <button class="btn btn-reset" id="reset-btn">
                    <i class="fas fa-redo"></i> Reset
                </button>
            </div>
        </div>
        
        <div class="writing-area">
            <textarea id="essay-text" placeholder="Begin typing your essay here..." disabled></textarea>
            
            <div class="prompt-section">
                <h3>Essay Prompt</h3>
                <p class="prompt-text" id="prompt">Discuss the impact of artificial intelligence on modern education. How is AI changing the way students learn and teachers teach? What are the potential benefits and challenges of these technological advancements?</p>
            </div>
        </div>
    </div>

    <!-- <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <h2 class="logo">Ebook World</h2>
                <p>Dive into the world of ebooks with us. Read, learn, and explore.</p>
                <div class="footer-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-tiktok"></i></a>
                    <a href="#"><i class="fab fa-discord"></i></a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>Essay Writing Competition &copy; 2025 | Timer will turn red when 5 minutes remain</p>
            </div>
        </div>
    </footer> -->
    <?php include 'footer.php';?>
<!-- 
    <div class="theme-toggle" id="theme-toggle">
        <i class="fas fa-moon"></i>
    </div> -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const essayText = document.getElementById('essay-text');
            const timerDisplay = document.getElementById('timer');
            const wordCountDisplay = document.getElementById('word-count');
            const startBtn = document.getElementById('start-btn');
            const stopBtn = document.getElementById('stop-btn');
            const resetBtn = document.getElementById('reset-btn');
            const promptElement = document.getElementById('prompt');
            const themeToggle = document.getElementById('theme-toggle');
            
            let timeLeft = 30 * 60; 
            let timerInterval;
            let isRunning = false;
            let isDarkTheme = true;
            
            // Essay prompts
            const prompts = [
                "Discuss the impact of artificial intelligence on modern education. How is AI changing the way students learn and teachers teach? What are the potential benefits and challenges of these technological advancements?",
                "Climate change is one of the most pressing issues of our time. What responsibilities do individuals, corporations, and governments have in addressing this global challenge? Propose concrete solutions that could make a significant impact.",
                "Social media has transformed how we communicate and interact. Analyze both the positive and negative effects of social media on society, particularly on young people's mental health and social development.",
                "Examine the role of technology in shaping the future of work. How will automation and remote work change employment patterns? What skills will be most valuable in the job market of tomorrow?"
            ];
            
            // Set a random prompt
            promptElement.textContent = prompts[Math.floor(Math.random() * prompts.length)];
            
            // Update word count
            essayText.addEventListener('input', function() {
                const text = essayText.value.trim();
                const words = text === '' ? 0 : text.split(/\s+/).length;
                wordCountDisplay.textContent = words;
            });
            
            // Format time as MM:SS
            function formatTime(seconds) {
                const mins = Math.floor(seconds / 60);
                const secs = seconds % 60;
                return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
            }
            
            // Update timer display
            function updateTimer() {
                timerDisplay.textContent = formatTime(timeLeft);
                
                // Change color when 5 minutes remain
                if (timeLeft <= 300) {
                    timerDisplay.classList.add('warning');
                } else {
                    timerDisplay.classList.remove('warning');
                }
                
                // Stop when time is up
                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    essayText.disabled = true;
                    startBtn.disabled = true;
                    stopBtn.disabled = true;
                    alert("Time's up! Please submit your essay.");
                }
                
                timeLeft--;
            }
            
            // Start timer
            startBtn.addEventListener('click', function() {
                if (!isRunning) {
                    isRunning = true;
                    essayText.disabled = false;
                    essayText.focus();
                    startBtn.disabled = true;
                    stopBtn.disabled = false;
                    
                    timerInterval = setInterval(updateTimer, 1000);
                }
            });
            
            // Pause timer
            stopBtn.addEventListener('click', function() {
                if (isRunning) {
                    isRunning = false;
                    clearInterval(timerInterval);
                    essayText.disabled = true;
                    startBtn.disabled = false;
                    stopBtn.disabled = true;
                    
                    if (timeLeft > 0) {
                        startBtn.innerHTML = '<i class="fas fa-play"></i> Resume';
                    }
                }
            });
            
            // Reset timer
            resetBtn.addEventListener('click', function() {
                clearInterval(timerInterval);
                isRunning = false;
                timeLeft = 30 * 60;
                timerDisplay.textContent = formatTime(timeLeft);
                timerDisplay.classList.remove('warning');
                essayText.value = '';
                essayText.disabled = true;
                wordCountDisplay.textContent = '0';
                startBtn.disabled = false;
                stopBtn.disabled = true;
                startBtn.innerHTML = '<i class="fas fa-play"></i> Start';
                
                // Set a new random prompt
                promptElement.textContent = prompts[Math.floor(Math.random() * prompts.length)];
            });
            
            // Theme toggle functionality
            themeToggle.addEventListener('click', function() {
                isDarkTheme = !isDarkTheme;
                
                if (isDarkTheme) {
                    // Switch to dark theme
                    document.body.style.background = 'linear-gradient(135deg, #0A0A0A 0%, #1E1E1E 100%)';
                    document.body.style.color = '#E0E0E0';
                    themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
                } else {
                    // Switch to light theme
                    document.body.style.background = 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)';
                    document.body.style.color = '#2A2A3C';
                    themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
                }
            });
        });
    </script>
</body>
</html>