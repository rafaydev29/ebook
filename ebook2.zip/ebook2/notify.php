<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submission Successful</title>
    <style>
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #121212;
            color: #e0e0e0;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            text-align: center;
        }
        
        /* Success Container */
        .success-container {
            background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            max-width: 600px;
            width: 100%;
            border: 1px solid #333;
        }
        
        /* Success Icon */
        .success-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            color: #4caf50;
            animation: bounce 1s ease infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        /* Header Styles */
        h1 {
            color: #4caf50;
            margin-bottom: 20px;
            font-size: 2.2rem;
            font-weight: 600;
            text-shadow: 0 0 10px rgba(76, 175, 80, 0.3);
        }
        
        /* Message Styles */
        .success-message {
            background-color: rgba(76, 175, 80, 0.1);
            padding: 20px;
            border-radius: 10px;
            margin: 25px 0;
            border-left: 4px solid #4caf50;
            text-align: left;
        }
        
        .success-message p {
            margin-bottom: 15px;
            font-size: 1.1rem;
            color: #b0b0b0;
        }
        
        .success-message p:last-child {
            margin-bottom: 0;
        }
        
        /* Highlight Text */
        .highlight {
            color: #bb86fc;
            font-weight: 600;
        }
        
        /* Back Button */
        .back-btn {
            display: inline-block;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            text-decoration: none;
            padding: 14px 30px;
            border-radius: 30px;
            font-weight: 600;
            margin-top: 20px;
            box-shadow: 0 4px 15px rgba(0, 100, 200, 0.3);
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1.1rem;
        }
        
        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 100, 200, 0.4);
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
        /* Navigation */
        .nav {
            display: flex;
            flex-direction: row;
            justify-content: center;
            gap: 10px;
            margin-top: 30px;
        }
        
        .nav a {
            border-radius: 10px;
            width: 200px;
            text-align: center;
            text-decoration: none;
        }
        
        /* Upload Button */
        .upload-btn {
            display: inline-block;
            background: linear-gradient(135deg, #2d2d2d, #1a1a1a);
            color: #bb86fc;
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 30px;
            font-weight: 600;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            border: 1px solid #333;
        }
        
        .upload-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.4);
            background: linear-gradient(135deg, #3d3d3d, #2a2a2a);
        }
        
        /* Footer */
        footer {
            text-align: center;
            margin-top: 40px;
            color: #666;
            font-size: 0.9rem;
            width: 100%;
        }
        
        /* Progress Bar */
        .progress-container {
            width: 100%;
            background-color: #2d2d2d;
            border-radius: 10px;
            margin: 25px 0;
            overflow: hidden;
        }
        
        .progress-bar {
            width: 0%;
            height: 8px;
            background: linear-gradient(90deg, #4caf50, #8bc34a);
            border-radius: 10px;
            animation: fillProgress 2s ease-in-out forwards;
        }
        
        @keyframes fillProgress {
            to { width: 100%; }
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }
            
            .success-container {
                padding: 30px 20px;
            }
            
            h1 {
                font-size: 1.8rem;
            }
            
            .nav {
                flex-direction: column;
                align-items: center;
            }
            
            .nav a {
                width: 100%;
                max-width: 250px;
            }
        }
        
        /* Celebration Animation */
        .confetti {
            position: fixed;
            width: 10px;
            height: 10px;
            background-color: #bb86fc;
            opacity: 0;
            animation: confettiFall 5s ease-in-out forwards;
        }
        
        @keyframes confettiFall {
            0% {
                transform: translateY(-100px) rotate(0deg);
                opacity: 1;
            }
            100% {
                transform: translateY(100vh) rotate(360deg);
                opacity: 0;
            }
        }
    </style>
</head>
<body>
    <div class="success-container">
        <div class="success-icon">🎉</div>
        
        <h1>Your Story Has Been Submitted Successfully!</h1>
        
        <div class="progress-container">
            <div class="progress-bar"></div>
        </div>
        
        <div class="success-message">
            <p>Congratulations! Your story submission has been received and is now in the review process.</p>
            
            <p>Our admin team will carefully evaluate your submission. If your story is selected as the winner, you will be notified via email.</p>
            
            <p>The review process typically takes <span class="highlight">2 to 3 days</span> maximum. We appreciate your patience and wish you the best of luck!</p>
        </div>
        
        <a href="competition.php" class="back-btn">Back to Competitions</a>
        
        <div class="nav">
            <a href="index.php" class="upload-btn">Browse More Stories</a>
            <a href="competition.php" class="upload-btn">View Competitions</a>
        </div>
    </div>
    
    <footer>
        <p>Story Competition Platform &copy; <?php echo date('Y'); ?></p>
    </footer>

    <script>
       
        function createConfetti() {
            const colors = ['#bb86fc', '#03dac6', '#ffb74d', '#cf6679', '#4caf50'];
            for (let i = 0; i < 50; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.left = Math.random() * 100 + 'vw';
                confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
                confetti.style.animationDelay = Math.random() * 5 + 's';
                document.body.appendChild(confetti);
                
                
                setTimeout(() => {
                    confetti.remove();
                }, 6000);
            }
        }
        
        
        window.addEventListener('load', createConfetti);
        
      
        document.addEventListener('click', function() {
            createConfetti();
        });
    </script>
</body>
</html>