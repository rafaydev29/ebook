<?php
 include './config.php';
 $query="SELECT * FROM  notifications";
 $run=mysqli_query($conn,$query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
         nav {
            background: black;
            color: white;
            padding: 18px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            /* max-width: 1200  px; */
            margin: 0 auto;
            padding: 0 2%;
        }

        .logo {
            font-size: 26px;
            font-weight: 700;
            display: flex;
            align-items: center;
            color: var(--light);
        }
        span{
            color:rgba(224, 212, 212, 1);
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        .links {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .links a {
            color: var(--text);
            text-decoration: none;
            font-weight: 500;
            margin: 0 12px;
            transition: all 0.3s ease;
            padding: 6px 0;
            font-size: 0.95rem;
        }

        .links a:hover {
            color: var(--primary);
        }
        @media (max-width: 900px) {
            .nav-container {
                flex-direction: column;
                text-align: center;
            }

            .links {
                margin-top: 15px;
              }
              
              .links a {
                margin: 5px 10px;
              }
              
              .hero {
                font-size: 2.5rem;
              }
            }
            <style>
              body {
                font-family: Arial, sans-serif;
                background: #121212;
                color: white;
                margin: 0;
                padding: 20px;
              }
          
              /* Trigger Button */
              .notify-btn {
                padding: 12px 20px;
                background: linear-gradient(135deg, #1e88e5, #0d47a1);
                border: none;
                border-radius: 6px;
                color: white;
                font-weight: 600;
                cursor: pointer;
                box-shadow: 0 4px 10px rgba(0,0,0,0.3);
              }
              .notify-btn:hover {
                background: linear-gradient(135deg, #2196f3, #1565c0);
              }
          
              /* Sidebar Modal */
             /* Sidebar Modal */
          .sidebar-modal {
            position: fixed;
            top: 0;
            right: -450px; /* hide outside screen */
            width: 450px;  /* wider sidebar */
            height: 100%;
            background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
            box-shadow: -4px 0 15px rgba(0,0,0,0.6);
            transition: right 0.3s ease;
            z-index: 1000;
            display: flex;
            flex-direction: column;
          }
          
          .sidebar-modal.active {
            right: 0; /* slide in */
          }
          
          
              /* Header */
              .sidebar-header {
                padding: 15px;
                background: #0d47a1;
                color: white;
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 1.2rem;
                font-weight: bold;
              }
          
              .close-btn {
                background: none;
                border: none;
                color: white;
                font-size: 1.5rem;
                cursor: pointer;
              }
          
              /* Notifications */
              .notifications {
                padding: 20px;
                flex: 1;
                overflow-y: auto;
              }
          
              .notification {
                background: #2a2a2a;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 15px;
                border-left: 5px solid #1e88e5;
                transition: background 0.2s;
              }
              .notification:hover {
                background: #333;
              }
              .notification-title {
                font-weight: 600;
                margin-bottom: 5px;
                color: #bb86fc;
              }
              .notification-time {
                font-size: 0.8rem;
                color: #aaa;
              }
          
              /* Overlay */
              .overlay {
                position: fixed;
                top: 0; left: 0;
                width: 100%; height: 100%;
                background: rgba(0,0,0,0.6);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease;
                z-index: 999;
              }
              .overlay.active {
                opacity: 1;
                visibility: visible;
              }
            </style>
    </style>
</head>
<body>
     <nav>
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-book-open"></i>
                <span>Ebook World</span>
            </div>
            <div class="links">
              <a href="index.php">Home</a>
              <a href="about.php">About us</a>
              <a href="contact.php">Contact us</a>
              <a href="login.php">Login</a>
                <a href="events.php">Events</a>
                <a href="books.php">Browse Books</a>
                <a href="competition.php">Competition</a>
                <a href="cart/cart.php">Cart</a>
                <a href="user/dashboard.php">Dashboard</a>
                <a href="#" onclick="openSidebar()">Notifications</a>
                <a href="logout.php" style='color:red' >logout</a>
            </div>
        </div>
    </nav>
</body>
</html>
</head>
<body>

  <!-- Overlay -->
  <div class="overlay" id="overlay" onclick="closeSidebar()"></div>

  <!-- Sidebar Modal -->
  <div class="sidebar-modal" id="sidebarModal">
    <div class="sidebar-header">
      Notifications
      <button class="close-btn" onclick="closeSidebar()">&times;</button>
    </div>
    <div class="notifications">

      
    <?php while($row = mysqli_fetch_assoc($run)) { ?>
  <div class="notification">
    <div class="notification-title"><?php echo $row['title']; ?></div>
    <p><?php echo $row['description']; ?></p>
    <div class="notification-time"><?php echo $row['created_at']; ?></div>
  </div>
<?php } ?>

   

    </div>
  </div>

  <script>
    function openSidebar() {
      document.getElementById("sidebarModal").classList.add("active");
      document.getElementById("overlay").classList.add("active");
    }

    function closeSidebar() {
      document.getElementById("sidebarModal").classList.remove("active");
      document.getElementById("overlay").classList.remove("active");
    }
  </script>
</body>
</html>
