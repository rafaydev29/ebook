<?php include './config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Story Submission</title>
    <style>
        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #121212;
            color: #e0e0e0;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* Header Styles */
        h1 {
            color: #ffffff;
            text-align: center;
            margin: 20px 0;
            font-size: 2.5rem;
            font-weight: 300;
            letter-spacing: 1px;
            text-shadow: 0 0 10px rgba(0, 150, 255, 0.3);
        }
        
        /* Navigation */
        .nav {
            display: flex;
            flex-direction: row;
            justify-content: center;
            gap: 10px;
            margin-bottom: 30px;
            padding: 0 20px;
        }
        
        .nav a {
            border-radius: 10px;
            width: 300px;
            text-align: center;
            text-decoration: none;
        }
        
        /* Upload Button */
        .upload-btn {
            display: inline-block;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 30px;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0, 100, 200, 0.3);
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .upload-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 100, 200, 0.4);
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
        /* Split Layout Container */
        .split-container {
            display: flex;
            flex: 1;
            gap: 0;
            height: calc(100vh - 200px);
        }
        
        /* Form Section */
        .form-section {
            flex: 1;
            background-color: #1e1e1e;
            padding: 30px;
            overflow-y: auto;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.3);
        }
        
        /* Story Section */
        .story-section {
            flex: 1;
            background-color: #1a1a1a;
            padding: 30px;
            display: flex;
            flex-direction: column;
        }
        
        /* Form Elements */
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #bb86fc;
            font-weight: 500;
        }
        
        input, textarea, select {
            width: 100%;
            padding: 12px 15px;
            background-color: #2d2d2d;
            border: 1px solid #333;
            border-radius: 6px;
            color: #e0e0e0;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: #bb86fc;
            box-shadow: 0 0 0 2px rgba(187, 134, 252, 0.2);
        }
        
        /* Story Textarea */
        #story {
            flex: 1;
            min-height: 300px;
            resize: none;
            font-family: 'Courier New', monospace;
            line-height: 1.5;
        }
        
        .story-label {
            color: #bb86fc;
            font-weight: 500;
            margin-bottom: 10px;
            font-size: 1.1rem;
        }
        
        /* Submit Button */
        .submit-btn {
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            border: none;
            padding: 14px 20px;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 100, 200, 0.3);
            margin-top: 20px;
        }
        
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 100, 200, 0.4);
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
        /* Messages */
        .success-message {
            background-color: rgba(76, 175, 80, 0.2);
            color: #4caf50;
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #4caf50;
        }
        
        .error-message {
            background-color: rgba(244, 67, 54, 0.2);
            color: #f44336;
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #f44336;
        }
        
        /* Footer */
        footer {
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 0.9rem;
            background-color: #1e1e1e;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .split-container {
                flex-direction: column;
                height: auto;
            }
            
            .form-section, .story-section {
                flex: none;
                min-height: 50vh;
            }
            
            .nav {
                flex-direction: column;
                align-items: center;
            }
            
            .nav a {
                width: 100%;
                max-width: 300px;
            }
            
            h1 {
                font-size: 2rem;
            }
        }
        
        /* Character Counter */
        .char-counter {
            text-align: right;
            color: #ffffffff;
            font-size: 0.9rem;
            margin-top: 5px;
            font-family:franklin gothic;
        }
        
        /* Competition Info */
        .competition-info {
            background: linear-gradient(135deg, #2d2d2d, #1a1a1a);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #bb86fc;
        }
        
        .competition-info h3 {
            color: #bb86fc;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php include 'nav.php'; ?>
    <h1>📖 Submit Your Story</h1>
    
  <div class="split-container">
    <!-- Left Side - Form Fields -->
    <div class="form-section">
        <div class="competition-info">
            <h3>Competition Details</h3>
            <p>Submit your original story for a chance to win!</p>
        </div>
        
        <form action="" method="POST">
            <div class="form-group">
                <label for="name">Enter your Name</label>
                <input type="text" name="name" id="name" required>
            </div>
            
            <div class="form-group">
                <label for="email">Enter your Email</label>
                <input type="email" name="email" id="email" required>
            </div>
            
            <div class="form-group">
                <label for="topic">Topic of your Story</label>
                <input type="text" name="topic" id="topic" required>
            </div>
            
            <div class="form-group">
                <label for="com_name">Competition name (which you are applying for)</label>
                <input type="text" name="com_name" id="com_name" required>
            </div>

            <!-- ✅ Keep only this one -->
            <div class="form-group">
                <label for="story">Paste your story here</label>
                <textarea name="story" id="story" required placeholder="Begin writing or paste your story here..."></textarea>
                <div class="char-counter"><span id="char-count">0</span> characters</div>
            </div>
            
            <button type="submit" name="btn" class="submit-btn">Submit Your Story</button>
        </form>
    </div>
</div>



        
        <!-- Right Side - Story Textarea -->
        <!-- <div class="story-section">
            <label for="story" class="story-label">Paste your story here</label>
            <textarea name="story" id="story" required placeholder="Begin writing or paste your story here..."></textarea>
            <div class="char-counter"><span id="char-count">0</span> characters</div>
        </div> -->
    </div>
    <?php include 'footer.php'; ?>

    <script>
        // Character counter for the story textarea
        const storyTextarea = document.getElementById('story');
        const charCount = document.getElementById('char-count');
        
        storyTextarea.addEventListener('input', function() {
            charCount.textContent = this.value.length;
        });
        
    </script>

<?php
if(isset($_POST['btn'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $topic = mysqli_real_escape_string($conn, $_POST['topic']);
    $com_name = mysqli_real_escape_string($conn, $_POST['com_name']);
    $story = mysqli_real_escape_string($conn, $_POST['story']);

    $query = "INSERT INTO submitted_stories(name,email,topic,competition_name,story) 
              VALUES ('$name','$email','$topic','$com_name','$story')";
    $run = mysqli_query($conn, $query);

    if($run){
        echo "<script>
                alert('Your story was submitted successfully'); 
                window.location.href='notify.php';
              </script>";
    } else {
        echo "<script>alert('you have already take part in this competition');</script>";
    }
}
?>
</body>
</html>