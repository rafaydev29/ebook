<?php 
include './config.php';

$query = "SELECT * FROM essay_competition where status='active'";
$run = mysqli_query($conn, $query);

if (!$run) {
    die("Query failed: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Essay Competitions</title>
    <style>
        :root {
            --bg-color: #0f0b1d;
            --card-bg: #1a1535;
            --text-color: #e2e2e2;
            --text-secondary: #b8b8d6;
            --accent-primary: #9c4dff;
            --accent-secondary: #ff4da6;
            /* --accent-secondary: #ffc534ff; */
            --accent-gradient: linear-gradient(135deg, #9c4dff, #ff4da6);
            --shadow-color: rgba(0,0,0,0.4);
            /* --border-color: #2d2750; */
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-color);
            margin: 0;
            padding: 0;
            color: var(--text-color);
            min-height: 100vh;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(156, 77, 255, 0.1) 0%, transparent 20%),
                radial-gradient(circle at 90% 80%, rgba(255, 77, 166, 0.1) 0%, transparent 20%);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 30px 0;
            position: relative;
        }

        .header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            
            border-radius: 2px;
        }

        h1 {
            margin: 0;
            font-size: 2.8rem;
            background:white;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            /* font-weight: 800; */
            letter-spacing: 1px;
            text-shadow: 0 2px 10px rgba(156, 77, 255, 0.3);
            font-weight:light;
        }

        .subtitle {
            font-size: 1.2rem;
            color: var(--text-secondary);
            margin-top: 10px;
            font-weight: 300;
        }

        .competitions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 25px;
        }

        .card {
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: 0 8px 20px var(--shadow-color);
            padding: 25px;
            transition: all 0.3s ease;
            /* border: 1px solid var(--border-color); */
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--accent-gradient);
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.5);
            /* border-color: rgba(156, 77, 255, 0.5); */
            
        }

        .card h3 {
            margin: 0 0 15px;
            color: var(--text-color);
            font-size: 1.4rem;
            font-weight: 700;
            /* line-height: 1.3; */
            
        }

        .card p {
            margin: 12px 0;
            color: var(--text-secondary);
            line-height: 1.5;
        }

        .prize {
            font-weight: bold;
            color: var(--accent-secondary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .duration {
            font-style: italic;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .card-footer {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 24px;
            background:  #ffc534ff;
            color:black;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            width: 300px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(156, 77, 255, 0.3);
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(156, 77, 255, 0.5);
        }

        .tag {
            background: rgba(156, 77, 255, 0.2);
            color: var(--accent-primary);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .icon {
            font-size: 1.2rem;
        }

        /* Animation for cards */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card {
            animation: fadeInUp 0.5s ease forwards;
            opacity: 0;
        }

        .card:nth-child(1) { animation-delay: 0.1s; }
        .card:nth-child(2) { animation-delay: 0.2s; }
        .card:nth-child(3) { animation-delay: 0.3s; }
        .card:nth-child(4) { animation-delay: 0.4s; }
        .card:nth-child(5) { animation-delay: 0.5s; }
        .card:nth-child(6) { animation-delay: 0.6s; }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .competitions-grid {
                grid-template-columns: 1fr;
            }
            
            h1 {
                font-size: 2.2rem;
            }
        }
    </style>
</head>
<body>
    <?php include 'nav.php';?>
    <div class="container">
        <div class="header">
            <h1>Essay Competitions</h1>
            <p class="subtitle">Showcase your writing skills and win amazing prizes</p>
        </div>
        
        <div class="competitions-grid">
            <?php while($row = mysqli_fetch_assoc($run)) { ?>
                <div class="card">
                    <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                    <p><?php echo htmlspecialchars($row['description']); ?></p>
                    <p class="prize"><span class="icon">🏆</span> Prize: <?php echo htmlspecialchars($row['prize']); ?></p>
                    <p class="duration"><span class="icon">⏳</span> Duration: <?php echo htmlspecialchars($row['duration']); ?></p>
                    <div class="card-footer">
                        <!-- <span class="tag">Open</span> -->
                        <a href="essay-writing.php" class="btn">Join Now</a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
   <?php include 'footer.php';?>
  <script>
        (function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="3muZwl8ydn2bOkQ31Fx3A";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();

  </script>
</body>
</html>