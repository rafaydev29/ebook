<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sidebar Notification Modal</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #121212;
      color: white;
      margin: 0;
      padding: 20px;
    }

    /* Trigger Button */
    .notify-btn {
      padding: 12px 20px;
      background: linear-gradient(135deg, #1e88e5, #0d47a1);
      border: none;
      border-radius: 6px;
      color: white;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    }
    .notify-btn:hover {
      background: linear-gradient(135deg, #2196f3, #1565c0);
    }

    /* Sidebar Modal */
   /* Sidebar Modal */
.sidebar-modal {
  position: fixed;
  top: 0;
  right: -450px; /* hide outside screen */
  width: 450px;  /* wider sidebar */
  height: 100%;
  background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
  box-shadow: -4px 0 15px rgba(0,0,0,0.6);
  transition: right 0.3s ease;
  z-index: 1000;
  display: flex;
  flex-direction: column;
}

.sidebar-modal.active {
  right: 0; /* slide in */
}


    /* Header */
    .sidebar-header {
      padding: 15px;
      background: #0d47a1;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 1.2rem;
      font-weight: bold;
    }

    .close-btn {
      background: none;
      border: none;
      color: white;
      font-size: 1.5rem;
      cursor: pointer;
    }

    /* Notifications */
    .notifications {
      padding: 20px;
      flex: 1;
      overflow-y: auto;
    }

    .notification {
      background: #2a2a2a;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 15px;
      border-left: 5px solid #1e88e5;
      transition: background 0.2s;
    }
    .notification:hover {
      background: #333;
    }
    .notification-title {
      font-weight: 600;
      margin-bottom: 5px;
      color: #bb86fc;
    }
    .notification-time {
      font-size: 0.8rem;
      color: #aaa;
    }

    /* Overlay */
    .overlay {
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: rgba(0,0,0,0.6);
      opacity: 0;
      visibility: hidden;
      transition: opacity 0.3s ease;
      z-index: 999;
    }
    .overlay.active {
      opacity: 1;
      visibility: visible;
    }
  </style>
</head>
<body>
  <button class="notify-btn" onclick="openSidebar()">🔔 Show Notifications</button>

  <!-- Overlay -->
  <div class="overlay" id="overlay" onclick="closeSidebar()"></div>

  <!-- Sidebar Modal -->
  <div class="sidebar-modal" id="sidebarModal">
    <div class="sidebar-header">
      Notifications
      <button class="close-btn" onclick="closeSidebar()">&times;</button>
    </div>
    <div class="notifications">
      <div class="notification">
        <div class="notification-title">New Story Submitted</div>
        <p>Ali submitted a story for the competition.</p>
        <div class="notification-time">2 mins ago</div>
      </div>
      <div class="notification">
        <div class="notification-title">New User Registered</div>
        <p>Sarah just signed up to your platform.</p>
        <div class="notification-time">10 mins ago</div>
      </div>
      <div class="notification">
        <div class="notification-title">Story Approved</div>
        <p>You approved John’s story.</p>
        <div class="notification-time">1 hour ago</div>
      </div>
    </div>
  </div>

  <script>
    function openSidebar() {
      document.getElementById("sidebarModal").classList.add("active");
      document.getElementById("overlay").classList.add("active");
    }

    function closeSidebar() {
      document.getElementById("sidebarModal").classList.remove("active");
      document.getElementById("overlay").classList.remove("active");
    }
  </script>
</body>
</html>
