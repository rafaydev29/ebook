<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Luxurious Ebooks</title>
    <style>
        /* Dark Theme Variables */
        :root {
            --bg-primary: #121212;
            --bg-secondary: #1e1e1e;
            --bg-tertiary: #2d2d2d;
            --text-primary: #ffffff;
            --text-secondary: #b0b0b0;
            --accent-color: #6c63ff;
            --accent-hover: #5a52d5;
            --error-color: #ff5252;
            --success-color: #4caf50;
            --border-color: #404040;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            --transition: all 0.3s ease;
        }

        /* Light Theme (Optional) */
        .light-theme {
            --bg-primary: #f5f5f5;
            --bg-secondary: #ffffff;
            --bg-tertiary: #f0f0f0;
            --text-primary: #333333;
            --text-secondary: #666666;
            --accent-color: #6c63ff;
            --accent-hover: #5a52d5;
            --error-color: #d32f2f;
            --success-color: #388e3c;
            --border-color: #dddddd;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            transition: var(--transition);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            height:300px;
            /* background-image:URL('https://plus.unsplash.com/premium_photo-1681488394409-5614ef55488c?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8Ym9vayUyMGJhY2tncm91bmR8ZW58MHx8MHx8fDA%3D'); */
        }

        /* Theme Toggle */
        .theme-toggle-container {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .theme-toggle {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 50px;
            width: 60px;
            height: 30px;
            cursor: pointer;
            display: flex;
            align-items: center;
            padding: 0 5px;
            position: relative;
        }

        .theme-toggle::before {
            content: '';
            width: 22px;
            height: 22px;
            background-color: var(--accent-color);
            border-radius: 50%;
            transition: transform 0.3s;
        }

        .light-theme .theme-toggle::before {
            transform: translateX(30px);
        }

        .theme-label {
            font-size: 14px;
            color: var(--text-secondary);
        }

        /* Form Container */
        .form-container {
            background-color: var(--bg-secondary);
            border-radius: 12px;
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 500px;
            padding: 40px 30px;
            border: 1px solid var(--border-color);
            position: relative;
            overflow: hidden;
        }

        .form-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--accent-color), #ff7eb3);
        }

        h1 {
            text-align: center;
            margin-bottom: 10px;
            color: var(--text-primary);
            font-size: 2.2rem;
            font-weight: 700;
            background: linear-gradient(90deg, var(--accent-color), #ff7eb3);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .subtitle {
            text-align: center;
            margin-bottom: 30px;
            color: var(--text-secondary);
            font-size: 1.1rem;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-secondary);
            font-size: 0.95rem;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background-color: var(--bg-tertiary);
            color: var(--text-primary);
            font-size: 16px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: var(--accent-color);
            box-shadow: 0 0 0 2px rgba(108, 99, 255, 0.2);
        }

        .password-container {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            font-size: 0.9rem;
        }

        button[type="submit"] {
            width: 100%;
            padding: 14px;
            background: linear-gradient(90deg, var(--accent-color), #ff7eb3);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, opacity 0.3s;
            margin-top: 10px;
            position: relative;
            overflow: hidden;
        }

        button[type="submit"]:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }

        button[type="submit"]:active {
            transform: translateY(0);
        }

        button[type="submit"]::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 5px;
            height: 5px;
            background: rgba(255, 255, 255, 0.5);
            opacity: 0;
            border-radius: 100%;
            transform: scale(1, 1) translate(-50%);
            transform-origin: 50% 50%;
        }

        button[type="submit"]:focus:not(:active)::after {
            animation: ripple 1s ease-out;
        }

        @keyframes ripple {
            0% {
                transform: scale(0, 0);
                opacity: 0.5;
            }
            100% {
                transform: scale(20, 20);
                opacity: 0;
            }
        }

        .login-link {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
        }

        .login-link a {
            color: var(--accent-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        /* Messages */
        .message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-top: 20px;
            text-align: center;
            font-weight: 500;
        }

        .success {
            background-color: rgba(76, 175, 80, 0.1);
            color: var(--success-color);
            border: 1px solid rgba(76, 175, 80, 0.3);
        }

        .error {
            background-color: rgba(255, 82, 82, 0.1);
            color: var(--error-color);
            border: 1px solid rgba(255, 82, 82, 0.3);
        }

        .login-redirect {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: var(--accent-color);
            text-decoration: none;
            font-weight: 500;
        }

        .login-redirect:hover {
            text-decoration: underline;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            .form-container {
                padding: 30px 20px;
            }
            
            h1 {
                font-size: 1.9rem;
            }
            
            .subtitle {
                font-size: 1rem;
            }
            
            input[type="text"],
            input[type="email"],
            input[type="password"],
            button[type="submit"] {
                padding: 12px 14px;
            }
        }

        @media (max-width: 400px) {
            body {
                padding: 10px;
            }
            
            .form-container {
                padding: 25px 15px;
            }
            
            h1 {
                font-size: 1.7rem;
            }
            
            .theme-toggle-container {
                top: 10px;
                right: 10px;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
            margin-right: 10px;
            vertical-align: middle;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .btn-loading {
            pointer-events: none;
            opacity: 0.7;
        }
    </style>
</head>
<body class="dark-theme">
    <!-- <div class="theme-toggle-container">
        <span class="theme-label">Dark</span>
        <div class="theme-toggle" id="themeToggle"></div>
        <span class="theme-label">Light</span>
    </div>
     -->
    <div class="form-container">
        <form action="" method="POST" id="registerForm">
            <h1>Register</h1>
            <p class="subtitle">Register yourself and dive into the world of luxurious ebooks</p>
            
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" required>
            </div>
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" name="email" id="email" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-container">
                    <input type="password" name="password" id="password" required>
                    <button type="button" class="toggle-password" id="togglePassword">Show</button>
                </div>
            </div>
            
            <button type="submit" name="submit" id="submitBtn">Create Account</button>
            
            <div class="login-link">
                <a href="login.php">Already have an account? Login here</a>
            </div>
        </form>

        <?php
        if (isset($_POST['submit'])) {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $pass = $_POST['password'];

            // Check if user already exists
            $check = $conn->prepare("SELECT id FROM Verified_users WHERE email = ?");
            $check->bind_param("s", $email);
            $check->execute();
            $check->store_result();

            if ($check->num_rows > 0) {
                echo "<div class='message error'>You are already registered!</div>";
                echo '<a class="login-redirect" href="login.php">Login here</a>';
            } else {
                // Insert new user
                $state = $conn->prepare("INSERT INTO Verified_users (name, email, pass) VALUES (?, ?, ?)");
                $state->bind_param("sss", $name, $email, $pass);

                if ($state->execute()) {
                    echo "<div class='message success'>You have been registered successfully!</div>";
                } else {
                    echo "<div class='message error'>Error: " . $conn->error . "</div>";
                }
                $state->close();
            }

            $check->close();
        }
        ?>
    </div>

    <script>
        // Theme Toggle Functionality
        const themeToggle = document.getElementById('themeToggle');
        const body = document.body;
        
        // Check for saved theme preference or default to dark
        const savedTheme = localStorage.getItem('theme') || 'dark';
        body.classList.toggle('light-theme', savedTheme === 'light');
        
        themeToggle.addEventListener('click', () => {
            body.classList.toggle('light-theme');
            const isLightTheme = body.classList.contains('light-theme');
            localStorage.setItem('theme', isLightTheme ? 'light' : 'dark');
        });
        
        // Password visibility toggle
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        
        togglePassword.addEventListener('click', () => {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            togglePassword.textContent = type === 'password' ? 'Show' : 'Hide';
        });
        
        // Form validation and submission
        const form = document.getElementById('registerForm');
        const submitBtn = document.getElementById('submitBtn');
        
        form.addEventListener('submit', (e) => {
            const name = form.querySelector('input[name="name"]');
            const email = form.querySelector('input[name="email"]');
            const password = form.querySelector('input[name="password"]');
            
            // Simple validation
            let isValid = true;
            
            // Name validation
            if (name.value.trim().length < 2) {
                isValid = false;
                showError(name, 'Name must be at least 2 characters long');
            } else {
                clearError(name);
            }
            
            // Email format validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value)) {
                isValid = false;
                showError(email, 'Please enter a valid email address');
            } else {
                clearError(email);
            }
            
            // Password validation
            if (password.value.length < 6) {
                isValid = false;
                showError(password, 'Password must be at least 6 characters long');
            } else {
                clearError(password);
            }
            
            if (!isValid) {
                e.preventDefault();
            } else {
                // Show loading state
                submitBtn.innerHTML = '<span class="loading"></span> Creating Account...';
                submitBtn.classList.add('btn-loading');
            }
        });
        
        function showError(input, message) {
            clearError(input);
            const error = document.createElement('div');
            error.className = 'error-message';
            error.style.color = 'var(--error-color)';
            error.style.fontSize = '0.85rem';
            error.style.marginTop = '5px';
            error.textContent = message;
            input.parentNode.appendChild(error);
            input.style.borderColor = 'var(--error-color)';
        }
        
        function clearError(input) {
            const error = input.parentNode.querySelector('.error-message');
            if (error) {
                error.remove();
            }
            input.style.borderColor = '';
        }
        
        // Real-time validation
        const inputs = form.querySelectorAll('input[required]');
        inputs.forEach(input => {
            input.addEventListener('blur', () => {
                if (input.value.trim() !== '') {
                    // Validate based on input type
                    if (input.type === 'email') {
                        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                        if (!emailRegex.test(input.value)) {
                            showError(input, 'Please enter a valid email address');
                        } else {
                            clearError(input);
                        }
                    } else if (input.type === 'password' && input.value.length < 6) {
                        showError(input, 'Password must be at least 6 characters long');
                    } else if (input.id === 'name' && input.value.trim().length < 2) {
                        showError(input, 'Name must be at least 2 characters long');
                    } else {
                        clearError(input);
                    }
                }
            });
        });
    </script>
</body>
</html>