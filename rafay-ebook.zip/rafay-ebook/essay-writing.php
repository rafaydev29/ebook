<?php 
include './config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Essay Writing Competition</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Dark Theme CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        :root {
            --primary: #bb86fc;
            --light: #ffffff;
            --text: #e0e0e0;
            --bg-dark: #121212;
            --bg-card: #1e1e1e;
            --bg-input: #2a2a2a;
            --border: #333;
            --accent: #1e88e5;
            --danger: #cf6679;
            --success: #03dac6;
        }
        
        body {
            background-color: var(--bg-dark);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .container {
            width: 100%;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .header {
            background: linear-gradient(135deg, #bb86fc, #7c4dff);
            padding: 25px;
            text-align: center;
        }
        
        .header h1 {
            color: white;
            font-size: 2.2rem;
            margin-bottom: 10px;
        }
        
        .header p {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1.2rem;
        }
        
        .content {
            flex: 1;
            padding: 30px;
            display: flex;
            flex-direction: column;
        }
        
        .rules {
            background: rgba(187, 134, 252, 0.1);
            border-left: 4px solid var(--primary);
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 0 8px 8px 0;
        }
        
        .rules h3 {
            color: var(--primary);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .rules ul {
            padding-left: 20px;
        }
        
        .rules li {
            margin-bottom: 8px;
        }
        
        .form-container {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--primary);
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            background-color: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        textarea.form-control {
            min-height: 300px;
            resize: vertical;
            font-family: inherit;
        }
        
        .timer-container {
            background: var(--bg-input);
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
            border: 1px solid var(--border);
        }
        
        #timer {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary);
            margin: 10px 0;
        }
        
        .timer-label {
            font-size: 0.9rem;
            color: var(--text);
            opacity: 0.8;
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }
        
        .btn {
            flex: 1;
            padding: 14px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #2196f3, #1565c0);
            box-shadow: 0 5px 15px rgba(0, 100, 200, 0.4);
        }
        
        .btn-secondary {
            background: var(--bg-input);
            color: var(--text);
            border: 1px solid var(--border);
        }
        
        .btn-secondary:hover {
            background: #2d2d2d;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #cf6679, #b00020);
            color: white;
        }
        
        .btn-danger:hover {
            background: linear-gradient(135deg, #d6798a, #c2185b);
            box-shadow: 0 5px 15px rgba(207, 102, 121, 0.4);
        }
        
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .warning {
            color: var(--danger);
            font-size: 0.9rem;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .success {
            color: var(--success);
            font-size: 0.9rem;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-danger {
            background: rgba(207, 102, 121, 0.2);
            border: 1px solid var(--danger);
            color: var(--danger);
        }
        
        .alert-success {
            background: rgba(3, 218, 198, 0.2);
            border: 1px solid var(--success);
            color: var(--success);
        }
        
        @media (max-width: 768px) {
            .btn-group {
                flex-direction: column;
            }
            
            .content {
                padding: 20px;
            }
            
            .header h1 {
                font-size: 1.8rem;
            }
            
            .header p {
                font-size: 1rem;
            }
            
            textarea.form-control {
                min-height: 250px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-pen-fancy"></i> Essay Writing Competition</h1>
            <p>Showcase your writing skills and win amazing prizes</p>
        </div>
        
        <div class="content">
            <div class="rules">
                <h3><i class="fas fa-info-circle"></i> Competition Rules</h3>
                <ul>
                    <li>Each user can participate in only one competition</li>
                    <li>For dual participation, use a different email address</li>
                    <li>You have 3 hours to complete your essay once you start</li>
                    <li>After 3 hours, time will be up but you can still submit</li>
                    <li>Your essay will be automatically saved when you submit</li>
                </ul>
            </div>
            
            <div class="form-container">
                <form action="" method="POST" id="essayForm" onsubmit="return validateForm()">
                    <div class="form-group">
                        <label for="name"><i class="fas fa-user"></i> Full Name</label>
                        <input type="text" name="name" id="name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                        <input type="email" name="email" id="email" class="form-control" required>
                        <div class="warning">
                            <i class="fas fa-exclamation-circle"></i>
                            Use a different email for dual participation
                        </div>
                    </div>
                    
                    <div class="timer-container">
                        <div class="timer-label">Time Remaining</div>
                        <div id="timer">Time Left: 0:00:05</div>
                        <div class="timer-label">Click "Start Writing" to begin</div>
                    </div>
                    
                    <div class="form-group" style="flex: 1; display: flex; flex-direction: column;">
                        <label for="area"><i class="fas fa-edit"></i> Your Essay</label>
                        <textarea name="area" id="area" class="form-control" style="flex: 1;" disabled required></textarea>
                    </div>
                    
                    <div class="btn-group">
                        <button type="button" id="startBtn" class="btn btn-primary">
                            <i class="fas fa-play"></i> Start Writing (3 hours)
                        </button>
                        <button type="submit" name="submit" class="btn btn-secondary">
                            <i class="fas fa-paper-plane"></i> Submit Essay
                        </button>
                        <button type="button" onclick="leave()" class="btn btn-danger">
                            <i class="fas fa-sign-out-alt"></i> Leave Competition
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // For testing set to 5, for real use: 3 * 60 * 60
        let timerDuration = 5; // seconds (set to 5 for testing)
        let timerInterval;
        let timeOver = false;  // true when timer finished
        let started = false;   // true when user clicked Start

        const areaEl = document.getElementById("area");
        const startBtn = document.getElementById("startBtn");

        startBtn.addEventListener("click", function() {
            // enable textarea for typing
            areaEl.disabled = false;
            areaEl.readOnly = false;
            started = true;
            this.disabled = true; // Disable Start button once clicked

            // Start countdown
            updateTimerDisplay(); // immediate update
            timerInterval = setInterval(() => {
                if (timerDuration <= 0) {
                    clearInterval(timerInterval);
                    // Make textarea readonly (NOT disabled) so it is included in form POST
                    areaEl.disabled = false;   // ensure it's enabled for submission
                    areaEl.readOnly = true;    // prevent further edits
                    timeOver = true;           // mark that time finished
                    alert("Time is up! You can now only submit or leave.");
                } else {
                    timerDuration--;
                    updateTimerDisplay();
                }
            }, 1000);
        });

        function updateTimerDisplay() {
            let hours = Math.floor(timerDuration / 3600);
            let minutes = Math.floor((timerDuration % 3600) / 60);
            let seconds = timerDuration % 60;

            // Change color when less than 30 seconds remaining (for testing)
            let timerColor = timerDuration < 30 ? "#cf6679" : "#bb86fc";
            
            document.getElementById("timer").innerHTML =
                `<span style="color:${timerColor}">Time Left: ${hours}:${minutes.toString().padStart(2,'0')}:${seconds.toString().padStart(2,'0')}</span>`;
        }

        function leave(){
            if(confirm('Are you sure you want to leave without submitting your essay?')) {
                window.location.href='essay_competition.php';
            }
        }

        // JS validation before submitting
        function validateForm() {
            let name = document.getElementById("name").value.trim();
            let email = document.getElementById("email").value.trim();
            let area = document.getElementById("area").value.trim();

            // basic required check
            if(name === "" || email === "" || area === "") {
                alert("Please fill all fields before submitting.");
                return false;
            }

            // block submission if user never started and time hasn't finished
            if(!started && !timeOver) {
                alert("Please start the timer before submitting.");
                return false;
            }

            // otherwise allow submit (includes case: started=true OR timeOver=true)
            return true;
        }
    </script>

    <?php
    if(isset($_POST['submit'])) {
        $name  = $_POST['name'];
        $email = $_POST['email'];
        $area  = $_POST['area'];

        if(!empty($name) && !empty($email) && !empty($area)) {
            $state = $conn->prepare("INSERT INTO essay_writing_submission (name,email,area) VALUES (?,?,?)");
            $state->bind_param('sss', $name, $email, $area);

            if($state->execute()){
                echo "<script>alert('Your essay has been submitted successfully');</script>";
            } else {
                echo "<script>alert('You have already submitted your essay');</script>";
            }
            $state->close();
        } else {
            echo "<script>alert('All fields are required!');</script>";
        }
    }
    ?>
</body>
</html>