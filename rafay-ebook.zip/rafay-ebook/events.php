<?php 
    include './config.php';
    $query = "SELECT * FROM events_view where status='resume'"; 
    $run = mysqli_query($conn, $query);

    if(!$run){
        die("Query failed: " . mysqli_error($conn));
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <style>
        /* Dark theme styles */
        body {
            background-color: #121212;
            color: #e0e0e0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            line-height: 1.6;
            overflow-x:hidden;
        }
        
        /* Navigation styling */
            /* nav {
                background-color: #1e1e1e;
                padding: 1rem 0;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            }
            
            nav ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
            }
            
            nav li {
                margin: 0 1.5rem;
            }
            
            nav a {
                color: #bb86fc;
                text-decoration: none;
                font-weight: 500;
                transition: color 0.3s;
            }
            
            nav a:hover {
                color: #ffffff;
            }
            */
        /* Horizontal card styling - preserved as requested */
        .horizontal-card {
            width: 90%;
            border: 2px solid darkblue;
            margin: 1.5rem auto;
            padding: 1.5rem;
            /* display; */
            border-radius: 8px;
            background-color: #1e1e1e;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .horizontal-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }
        
        .horizontal-card h2 {
            color: #bb86fc;
            margin-top: 0;
            border-bottom: 1px solid #333;
            padding-bottom: 0.5rem;
        }
        
        .horizontal-card h3 {
            color: #03dac6;
        }
        
        /* Footer styling */
        footer {
            background-color: #1e1e1e;
            color: #888;
            text-align: center;
            padding: 1.5rem 0;
            margin-top: 2rem;
            border-top: 1px solid #333;
        }
        
        /* Container for content */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }
        
        /* Page header */
        .page-header {
            text-align: center;
            margin-bottom: 2rem;
            color: #bb86fc;
        }
        button{
            width:200px;
            height:50px;
            background-color:  #bb86fc;
            border:2px solid purple;
            border-radius:10px;
            font-size: 20px;
            font-family: franklin gothic;
            cursor:pointer;
        }
    </style>
</head>
<body>
    <?php include 'nav.php'; ?>
    
    <div class="container">
        <h1 class="page-header">Current Events</h1>
        
        <?php while($row = mysqli_fetch_assoc($run)){ ?>
            <div class="horizontal-card">
                <h2><?php echo $row['name'] ?></h2>
                <p><?php echo $row['desc'] ?></p>
                <h3>prize <?php echo $row['number'] ?></h3>
                <h3>Duration <?php echo $row['time'] ?></h3>
                <button>Learn more</button>
            </div>
        <?php } ?>
    </div>
    
    <?php include 'footer.php'; ?>
    <script>
            (function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="3muZwl8ydn2bOkQ31Fx3A";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();

    </script>
</body>
</html>