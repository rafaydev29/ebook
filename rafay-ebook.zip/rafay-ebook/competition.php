<?php
 include './config.php';
 $query="SELECT * FROM Launch_Story_Competition";
 $run=mysqli_query($conn,$query);
 

 $notificationQuery = "SELECT * FROM notifications";
 $notificationRun = mysqli_query($conn, $notificationQuery);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Story Competitions - Apply Now</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        :root {
            --primary: #bb86fc;
            --light: #ffffff;
            --text: #e0e0e0;
        }
        
        body {
            background-color: #121212;
            color: #e0e0e0;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* Navigation Styles */
        nav {
            background: #1a1a1a;
            color: white;
            padding: 18px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            margin: 0 auto;
            padding: 0 2%;
        }

        .logo {
            font-size: 26px;
            font-weight: 700;
            display: flex;
            align-items: center;
            color: var(--light);
        }
        
        span {
            color: rgba(224, 212, 212, 1);
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        .links {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .links a {
            color: var(--text);
            text-decoration: none;
            font-weight: 500;
            margin: 0 12px;
            transition: all 0.3s ease;
            padding: 6px 0;
            font-size: 0.95rem;
        }

        .links a:hover {
            color: var(--primary);
        }
        
        @media (max-width: 900px) {
            .nav-container {
                flex-direction: column;
                text-align: center;
            }

            .links {
                margin-top: 15px;
            }
              
            .links a {
                margin: 5px 10px;
            }
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            padding: 30px 20px;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }
        
        /* Header Styles */
        h1 {
            color: #ffffff;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
            font-weight: 300;
            letter-spacing: 1px;
            text-shadow: 0 0 10px rgba(0, 150, 255, 0.3);
        }
        
        .page-description {
            text-align: center;
            margin-bottom: 40px;
            color: #aaa;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            font-size: 1.1rem;
        }
        
        /* Enhanced Competition Cards */
        .competitions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .competition-card {
            background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: 1px solid #333;
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        
        .competition-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.5);
        }
        
        .card-header {
            background: linear-gradient(135deg, #bb86fc, #7c4dff);
            padding: 25px 20px;
            text-align: center;
            position: relative;
        }
        
        .card-header h3 {
            color: white;
            font-size: 1.5rem;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .card-category {
            display: inline-block;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            margin-top: 5px;
        }
        
        .card-body {
            padding: 25px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .card-description {
            margin-bottom: 20px;
            line-height: 1.5;
            color: #ccc;
            flex: 1;
        }
        
        .card-details {
            margin-bottom: 25px;
            background: rgba(42, 42, 42, 0.5);
            border-radius: 10px;
            padding: 15px;
           
        }
        
        .detail-item {
            display: flex;
            margin-bottom: 12px;
            align-items: center;
            gap:20px;
            text-align: center;
        }
        
        .detail-item:last-child {
            margin-bottom: 0;
        }
        
        .detail-label {
            font-weight: 600;
            color: #bb86fc;
            min-width: 140px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .detail-label i {
            width: 16px;
            text-align: center;
        }
        
        .detail-value {
            flex: 1;
            color: #e0e0e0;
        }
        
        .prize-section {
            margin: 20px 0;
            text-align: center;
        }
        
        .prize-highlight {
            background: linear-gradient(135deg, #ffb74d, #ff9800);
            color: #121212;
            padding: 12px 20px;
            border-radius: 10px;
            font-weight: 700;
            text-align: center;
            font-size: 1.1rem;
            box-shadow: 0 4px 10px rgba(255, 183, 77, 0.3);
            display: inline-block;
            width: 100%;
        }
        
        .apply-btn {
            display: block;
            width: 100%;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            text-align: center;
            padding: 14px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            margin-top: auto;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .apply-btn:hover {
            background: linear-gradient(135deg, #2196f3, #1565c0);
            box-shadow: 0 5px 15px rgba(0, 100, 200, 0.4);
            transform: translateY(-2px);
        }
        
        .card-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
            font-size: 0.85rem;
            color: #888;
        }
        
        .card-footer span {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            overflow-y: auto;
        }
        
        .modal-content {
            background-color: #1e1e1e;
            margin: 5% auto;
            width: 90%;
            max-width: 600px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            animation: modalFade 0.3s;
        }
        
        @keyframes modalFade {
            from {opacity: 0; transform: translateY(-50px);}
            to {opacity: 1; transform: translateY(0);}
        }
        
        .modal-header {
            background: linear-gradient(135deg, #bb86fc, #7c4dff);
            padding: 20px;
            border-radius: 15px 15px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h2 {
            color: white;
            font-size: 1.5rem;
        }
        
        .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            transition: transform 0.2s;
        }
        
        .close-btn:hover {
            transform: scale(1.2);
        }
        
        .modal-body {
            padding: 25px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #bb86fc;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            background-color: #2a2a2a;
            border: 1px solid #444;
            border-radius: 8px;
            color: #e0e0e0;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #bb86fc;
        }
        
        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }
        
        .submit-btn {
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
            margin-top: 10px;
        }
        
        .submit-btn:hover {
            background: linear-gradient(135deg, #2196f3, #1565c0);
            box-shadow: 0 5px 15px rgba(0, 100, 200, 0.4);
        }
        
        /* Notification Sidebar */
        .notify-btn {
            padding: 12px 20px;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            border: none;
            border-radius: 6px;
            color: white;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        }
        
        .notify-btn:hover {
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
        .sidebar-modal {
            position: fixed;
            top: 0;
            right: -450px;
            width: 450px;
            height: 100%;
            background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
            box-shadow: -4px 0 15px rgba(0,0,0,0.6);
            transition: right 0.3s ease;
            z-index: 1000;
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-modal.active {
            right: 0;
        }
        
        .sidebar-header {
            padding: 15px;
            background: #0d47a1;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 1.2rem;
            font-weight: bold;
        }
        
        .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        .notifications {
            padding: 20px;
            flex: 1;
            overflow-y: auto;
        }
        
        .notification {
            background: #2a2a2a;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 5px solid #1e88e5;
            transition: background 0.2s;
        }
        
        .notification:hover {
            background: #333;
        }
        
        .notification-title {
            font-weight: 600;
            margin-bottom: 5px;
            color: #bb86fc;
        }
        
        .notification-time {
            font-size: 0.8rem;
            color: #aaa;
        }
        
        .overlay {
            position: fixed;
            top: 0; 
            left: 0;
            width: 100%; 
            height: 100%;
            background: rgba(0,0,0,0.6);
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease;
            z-index: 999;
        }
        
        .overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        /* Footer Styles */
        footer {
            background: #1a1a1a;
            color: #e0e0e0;
            padding: 40px 0 20px;
            margin-top: auto;
        }
        
        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }
        
        .footer-section h3 {
            color: #bb86fc;
            margin-bottom: 20px;
            font-size: 1.2rem;
        }
        
        .footer-section p {
            margin-bottom: 15px;
            line-height: 1.6;
        }
        
        .footer-links {
            list-style: none;
        }
        
        .footer-links li {
            margin-bottom: 10px;
        }
        
        .footer-links a {
            color: #e0e0e0;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: #bb86fc;
        }
        
        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 15px;
        }
        
        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            background: #333;
            border-radius: 50%;
            color: #e0e0e0;
            transition: all 0.3s;
        }
        
        .social-links a:hover {
            background: #bb86fc;
            color: #121212;
            transform: translateY(-3px);
        }
        
        .footer-bottom {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #333;
            color: #888;
            font-size: 0.9rem;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #666;
            background-color: #1e1e1e;
            border-radius: 15px;
            margin: 20px 0;
            grid-column: 1 / -1;
        }
        
        .empty-state h3 {
            margin-bottom: 10px;
            color: #bb86fc;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .main-content {
                padding: 20px 15px;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            .competitions-grid {
                grid-template-columns: 1fr;
            }
            
            .modal-content {
                width: 95%;
                margin: 10% auto;
            }
            
            .sidebar-modal {
                width: 85%;
                right: -85%;
            }
            
            .detail-item {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .detail-label {
                min-width: auto;
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
   
   <?php include 'nav.php';?>
  
    <div class="main-content">
        <h1>🏆 Story Competitions - Apply Now</h1>
        
        <p class="page-description">
            Discover exciting story writing competitions and showcase your talent. 
            Apply now for a chance to win amazing prizes and get your work recognized!
        </p>
        
        <div class="competitions-grid">
            <?php 
            if(mysqli_num_rows($run) > 0) { 
                while ($row = mysqli_fetch_assoc($run)) { 
            ?>
            <div class="competition-card">
                <div class="card-header">
                    <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                    <div class="card-category">Story Writing</div>
                </div>
                <div class="card-body">
                    <div class="card-description">
                        <?php echo htmlspecialchars($row['description']); ?>
                    </div>
                    
                    <div class="card-details">
                        <div class="detail-item">
                            <span class="detail-label"><i class="far fa-clock"></i> Duration:</span>
                            <span class="detail-value"><?php echo htmlspecialchars($row['duration']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label"><i class="fas fa-trophy"></i> Previous Winner:</span>
                            <span class="detail-value"><?php echo htmlspecialchars($row['previuos_winner']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label"><i class="fas fa-users"></i> Participants:</span>
                            <span class="detail-value">Open to all writers</span>
                        </div>
                    </div>
                    
                    <div class="prize-section">
                        <div class="prize-highlight">
                            <i class="fas fa-award"></i> Prize: $<?php echo htmlspecialchars($row['price']); ?>
                        </div>
                    </div>
                    
                    <button class="apply-btn" onclick='notify()'>
                        <i class="fas fa-edit"></i> Apply for this Competition
                    </button>
                    
                    <div class="card-footer">
                        <span><i class="far fa-calendar"></i> Deadline: Ongoing</span>
                        <span><i class="fas fa-star"></i> Entry Fee: Free</span>
                    </div>
                </div>
            </div>
            <?php 
                } 
            } else { 
            ?>
            <div class="empty-state">
                <h3>No Active Competitions</h3>
                <p>Check back later for new story competitions!</p>
            </div>
            <?php } ?>
        </div>
    </div>

  <?php include 'footer.php';?>
  
  <script>
    function notify() {
        window.location.href='form.php';
    }
        (function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="3muZwl8ydn2bOkQ31Fx3A";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();

  </script>
</body>
</html>