<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit();
}
// optionally ensure role is 'user':
if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ebook World - Dive into the world of Ebooks</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6C63FF;
            --secondary: #FF6584;
            --accent: #36D1DC;
            --dark: #1E1E2E;
            --darker: #161622;
            --light: #F0F0F5;
            --card-bg: #2A2A3C;
            --text: #E2E2E2;
            --text-light: #A0A0B0;
        }

        body {
            background: linear-gradient(135deg, var(--darker) 0%, var(--dark) 100%);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Navigation */
        /* nav {
            background: var(--dark);
            color: white;
            padding: 18px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        .logo {
            font-size: 26px;
            font-weight: 700;
            display: flex;
            align-items: center;
            color: var(--light);
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        .links {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .links a {
            color: var(--text);
            text-decoration: none;
            font-weight: 500;
            margin: 0 12px;
            transition: all 0.3s ease;
            padding: 6px 0;
            font-size: 0.95rem;
        }

        .links a:hover {
            color: var(--primary);
        } */

        /* Hero Section */
        .sec1 {
            text-align: center;
            padding: 100px 0;
            background: linear-gradient(rgba(30, 30, 46, 0.9), rgba(42, 42, 60, 0.9));
            color: white;
            margin-bottom: 40px;
        }

        .hero {
            font-size: 3.2rem;
            margin-bottom: 20px;
            color: var(--light);
            font-weight: 700;
        }

        .sec1 p {
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto 30px;
            color: var(--text-light);
        }

        /* Section Headers */
        .logo1 {
            text-align: center;
            font-size: 2.3rem;
            margin: 50px 0 30px;
            color: var(--light);
            font-weight: 600;
        }

        .logo1:after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: var(--primary);
            margin: 15px auto;
            border-radius: 2px;
        }

        /* Card Sections */
        .sec2, .sec3, .sec4 {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            margin-bottom: 60px;
            justify-content: center;
        }

        .card1, .card3, .card4 {
            flex: 1;
            min-width: 300px;
            max-width: 350px;
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        .card1:hover, .card3:hover, .card4:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .card1 h2, .card3 h2, .card4 h2 {
            font-size: 1.6rem;
            margin-bottom: 15px;
            color: var(--light);
        }

        .card1 article, .card3 article, .card4 article {
            margin-bottom: 20px;
            color: var(--text-light);
            line-height: 1.6;
        }

        button {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 10px 25px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 0.95rem;
        }

        button:hover {
            background: #5a52e0;
            transform: translateY(-2px);
        }

        /* Book Cards Section */
        .book-card {
            background: var(--card-bg);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.05);
            max-width: 350px;
        }

        .book-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .book-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            background: var(--darker);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-light);
            font-size: 3rem;
        }

        .book-details {
            padding: 20px;
        }

        .book-title {
            font-size: 1.3rem;
            margin-bottom: 10px;
            color: var(--light);
            font-weight: 600;
        }

        .book-author {
            color: var(--text-light);
            margin-bottom: 15px;
            font-size: 0.95rem;
        }

        .book-price {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }

        .price {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
        }

        .original-price {
            text-decoration: line-through;
            color: var(--text-light);
            font-size: 1rem;
            margin-left: 10px;
        }

        .discount-badge {
            background: var(--secondary);
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        /* Footer */
        .footer {
            background: var(--darker);
            color: white;
            padding: 50px 0 20px;
            text-align: center;
            margin-top: 60px;
        }

        .footer-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
        }

        .footer-content h2 {
            font-size: 2rem;
            margin-bottom: 15px;
            color: var(--light);
        }

        .footer-content p {
            max-width: 600px;
            margin-bottom: 25px;
            color: var(--text-light);
        }

        .footer-icons {
            display: flex;
            gap: 15px;
        }

        .footer-icons a {
            color: var(--text);
            font-size: 1.3rem;
            transition: all 0.3s ease;
        }

        .footer-icons a:hover {
            color: var(--primary);
        }

        .footer-bottom {
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            color: var(--text-light);
            font-size: 0.9rem;
        }

        /* Search Bar */
        .search-container {
            display: flex;
            justify-content: center;
            margin: 30px 0;
        }

        .search-bar {
            display: flex;
            width: 100%;
            max-width: 500px;
        }

        .search-bar input {
            flex: 1;
            padding: 12px 20px;
            border: none;
            border-radius: 6px 0 0 6px;
            background: var(--card-bg);
            color: var(--text);
            font-size: 1rem;
        }

        .search-bar input:focus {
            outline: none;
            box-shadow: 0 0 0 2px var(--primary);
        }

        .search-bar button {
            border-radius: 0 6px 6px 0;
            padding: 12px 20px;
        }

        /* Responsive Design */
        @media (max-width: 900px) {
            .nav-container {
                flex-direction: column;
                text-align: center;
            }

            .links {
                margin-top: 15px;
            }

            .links a {
                margin: 5px 10px;
            }

            .hero {
                font-size: 2.5rem;
            }
        }

        @media (max-width: 768px) {
            .sec2, .sec3, .sec4 {
                flex-direction: column;
                align-items: center;
            }

            .card1, .card3, .card4, .book-card {
                width: 100%;
                max-width: 500px;
            }
            
            .hero {
                font-size: 2.2rem;
            }
            
            .logo1 {
                font-size: 2rem;
            }
        }

        @media (max-width: 480px) {
            .hero {
                font-size: 1.9rem;
            }

            .logo1 {
                font-size: 1.7rem;
            }

            .links a {
                font-size: 0.9rem;
                margin: 3px 8px;
            }
            
            .sec1 {
                padding: 70px 0;
            }
            
            .card1, .card3, .card4, .book-card {
                padding: 20px;
            }
            
            .book-image {
                height: 200px;
                font-size: 2.5rem;
            }
        }
        .btn{
            margin:20px 40%;
        }
        .btn button{
            width:300px;
            height:100px;
            font-size: 20px;
            text-align: center;
        }
        .reload{
            border: radius 10px;
        }
    </style>
</head>
<body>
    <!-- <nav>
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-book-open"></i>
                <span>Ebook World</span>
            </div>
            <div class="links">
                <a href="events.html">Events</a>
                <a href="contact.html">Contact us</a>
                <a href="index.html">Home</a>
                <a href="about.html">About us</a>
                <a href="login.html">Login</a>
                <a href="user/dashboard.html">Dashboard</a>
                <a href="categroies.php">Categories</a>
                <a href="competition.html">Competition</a>
                <a href="cart.html">Cart</a>
            </div>
        </div>
    </nav> -->
    <?php include 'nav.php'; ?>

    <section class="sec1">
        <div class="container">
            <h1 class="hero">Dive into the World of Ebooks</h1>
            <p>Discover thousands of books at your fingertips in our immersive digital library</p>
            
            <div class="search-container">
                <div class="search-bar">
                    <input type="text" placeholder="Search for books, authors, or categories...">
                    <button id='searchme'><i class="fas fa-search"></i>click to  Search here</button>
                </div>
            </div>
        </div>
    </section>
     
    <h2 class="logo1">Featured Books</h2>
    <div class="sec2">
        <div class="card1">
            <h2>New Releases</h2>
            <article>Discover our latest additions to the collection. Fresh stories, new authors, and exciting narratives await you in our new releases section.</article>
            <button onclick="redirect()">Explore Now</button>
        </div>
        <div class="card1">
            <h2>Best Sellers</h2>
            <article>See what everyone is reading! Our best sellers collection features the most popular books loved by our community of readers.</article>
            <button onclick="redirect()">Browse Collection</button>
        </div>
        <div class="card1">
            <h2>50% Off Sale</h2>
            <article>Don't miss our limited-time offer! Get premium ebooks at half the price. This sale won't last long, so grab your favorites now.</article>
            <button onclick="redirect()">View Deals</button>
        </div>
    </div>
    
    <!-- <h2 class="logo1">Special Offers</h2>
    <div class="sec3">
       <div class="card3">
            <h2>Biggest Prize</h2>
            <article>Enter our annual reading challenge for a chance to win amazing prizes. Read more, earn points, and claim your rewards!</article>
            <button>Learn More</button>
        </div>
       <div class="card3">
            <h2>Global Competition</h2>
            <article>Join readers from around the world in our global reading competition. Test your reading speed and comprehension skills.</article>
            <button>Join Now</button>
        </div>
       <div class="card3">
            <h2>Black Friday</h2>
            <article>Our biggest sale of the year is coming soon! Mark your calendars for incredible discounts on thousands of titles.</article>
            <button>Notify Me</button>
        </div>
    </div> -->
    
    <!-- New Book Cards Section -->
    <h2 class="logo1">Popular Books</h2>
    <div class="sec4">
        <div class="book-card">
            <div class="book-image">
                <i class="fas fa-book"></i>
            </div>
           <div class="book-details">
    <h3 class="book-title">Klara and the Sun</h3>
    <p class="book-author">by Kazuo Ishiguro</p>
    <p>From the bestselling author of Never Let Me Go and The Remains of the Day, 
       a stunning new novel about love, humanity and science.</p>
    
    <div class="book-price">
        <div>
            <span class="price">FREE</span>
        </div>
        <span class="discount-badge">Download</span>
    </div>

    <!-- Direct download button -->
    <a href="ebooks/klara-and-the-sun.docx" download
       style="display:block; text-align:center; margin-top:15px; padding:10px; 
              background:#007bff; color:white; border-radius:5px; text-decoration:none;">
       Download Ebook
    </a>
</div>

        </div>
        
        <div class="book-card">
            <div class="book-image">
                <i class="fas fa-book"></i>
            </div>
          <div class="book-details">
    <h3 class="book-title">Klara and the Sun</h3>
    <p class="book-author">by Kazuo Ishiguro</p>
    <p>From the bestselling author of Never Let Me Go and The Remains of the Day, 
       a stunning new novel about love, humanity and science.</p>
    
    <div class="book-price">
        <div>
            <span class="price">FREE</span>
        </div>
        <span class="discount-badge">Download</span>
    </div>

    <!-- Direct download button -->
    <a href="ebooks/klara-and-the-sun.docx" download
       style="display:block; text-align:center; margin-top:15px; padding:10px; 
              background:#007bff; color:white; border-radius:5px; text-decoration:none;">
       Download Ebook
    </a>
</div>

        </div>
        
        <div class="book-card">
            <div class="book-image">
                <i class="fas fa-book"></i>
            </div>
           <div class="book-details">
    <h3 class="book-title">Klara and the Sun</h3>
    <p class="book-author">by Kazuo Ishiguro</p>
    <p>From the bestselling author of Never Let Me Go and The Remains of the Day, 
       a stunning new novel about love, humanity and science.</p>
    
    <div class="book-price">
        <div>
            <span class="price">FREE</span>
        </div>
        <span class="discount-badge">Download</span>
    </div>

    <!-- Direct download button -->
    <a href="ebooks/klara-and-the-sun.docx" download
       style="display:block; text-align:center; margin-top:15px; padding:10px; 
              background:#007bff; color:white; border-radius:5px; text-decoration:none;">
       Download Ebook
    </a>
</div>
        </div>
    </div>
    <div class='btn'>
        <button onclick="redirect2()">Browse more Books</button>
    </div>

    <!-- Footer -->
    <!-- <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <h2 class="logo">Ebook World</h2>
                <p>Dive into the world of ebooks with us. Read, learn, and explore endless possibilities in our digital library.</p>
                <div class="footer-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-tiktok"></i></a>
                    <a href="#"><i class="fab fa-discord"></i></a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Ebook World | All Rights Reserved</p>
            </div>
        </div>
    </footer> -->
    <?php include 'footer.php';?>
    <script>
        // books collection
    document.getElementById('searchme').addEventListener('click', function () {
    let btn = this; // the button itself
    btn.innerText = '......'; // show dots
    // btn.classlist.add('reload');
    setTimeout(() => {
        window.location.href = 'books.php'; // redirect
    }, 500);
});
      
        function redirect(){
            window.location.href='books.php';
        }
        function redirect2(){
            window.location.href='books.php';
        }
       
(function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="3muZwl8ydn2bOkQ31Fx3A";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();

    </script>
</body>
</html>