<?php
// login.php
// MUST be the very first output. No whitespace before <?php
session_start();
include 'config.php'; // make sure config.php does NOT echo/print anything

$error = '';

if (isset($_POST['login'])) {
    // Basic sanitization
    $email = trim($_POST['email']);
    $pass  = trim($_POST['password']);

    if ($email === '' || $pass === '') {
        $error = "Please provide both email and password.";
    } else {
        // Prepared statement to fetch user
        $stmt = $conn->prepare("SELECT id, name, pass, role FROM verified_users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows === 1) {
            $row = $result->fetch_assoc();

            // If you hashed passwords during register, use password_verify()
            // If you did NOT hash, fallback to direct compare (not recommended)
            $stored_hash = $row['pass'];

            $password_ok = false;
            if (password_needs_rehash($stored_hash, PASSWORD_DEFAULT) || strpos($stored_hash, '$2y$') === 0) {
                // Likely hashed using password_hash
                $password_ok = password_verify($pass, $stored_hash);
            } else {
                // Plain-text stored (legacy). direct compare (not secure) 
                $password_ok = ($pass === $stored_hash);
            }

           if ($row['pass'] === $pass) {
    // password correct
    $_SESSION['user_id']   = $row['id'];
    $_SESSION['user_name'] = $row['name'];
    $_SESSION['role']      = $row['role'];

    if ($row['role'] === 'admin') {
        header("Location: admin/admin_users.php");
        exit();
    } else {
        header("Location: index.php");
        exit();
    }
} else {
    $error = "Invalid password!";
}

        } else {
            $error = "No account found with that email.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login</title>
<link rel="stylesheet" href="css/register.css">
<style>
/* Add this to your css/register.css file */
/* Dark Theme Variables */
:root {
    --bg-primary: #0f0f0f;
    --bg-secondary: #1a1a1a;
    --bg-tertiary: #2d2d2d;
    --text-primary: #e0e0e0;
    --text-secondary: #a0a0a0;
    --accent-color: #6c63ff;
    --accent-hover: #7b73ff;
    --error-color: #ff6b6b;
    --success-color: #4ade80;
    --border-color: #333333;
    --shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
    --transition: all 0.3s ease;
}

/* Base Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: var(--bg-primary);
    color: var(--text-primary);
    line-height: 1.6;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    background-image: 
        radial-gradient(circle at 15% 50%, rgba(108, 99, 255, 0.05) 0%, transparent 20%),
        radial-gradient(circle at 85% 30%, rgba(108, 99, 255, 0.05) 0%, transparent 20%);
}

/* Form Container */
.form-container {
    background-color: var(--bg-secondary);
    border-radius: 16px;
    box-shadow: var(--shadow);
    width: 100%;
    max-width: 500px;
    padding: 40px 32px;
    border: 1px solid var(--border-color);
    position: relative;
    overflow: hidden;
}

.form-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, var(--accent-color), #9d94ff);
}

h1 {
    text-align: center;
    margin-bottom: 16px;
    font-size: 2.2rem;
    font-weight: 700;
    background: linear-gradient(135deg, var(--accent-color), #9d94ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.subtitle {
    text-align: center;
    margin-bottom: 30px;
    color: var(--text-secondary);
    font-size: 1.1rem;
}

/* Form Elements */
.form-group {
    margin-bottom: 20px;
    position: relative;
}

label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: var(--text-secondary);
    font-size: 0.95rem;
}

input[type="text"],
input[type="email"],
input[type="password"] {
    width: 100%;
    padding: 14px 16px;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    background-color: var(--bg-tertiary);
    color: var(--text-primary);
    font-size: 16px;
    transition: var(--transition);
}

input[type="text"]:focus,
input[type="email"]:focus,
input[type="password"]:focus {
    outline: none;
    border-color: var(--accent-color);
    box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.1);
    background: var(--bg-secondary);
}

input[type="text"]:hover,
input[type="email"]:hover,
input[type="password"]:hover {
    border-color: #444444;
}

.password-container {
    position: relative;
}

.toggle-password {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    font-size: 0.9rem;
    transition: var(--transition);
}

.toggle-password:hover {
    color: var(--text-primary);
}

button[type="submit"] {
    width: 100%;
    padding: 14px;
    background: var(--accent-color);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    margin-top: 10px;
    position: relative;
    overflow: hidden;
}

button[type="submit"]:hover {
    background: var(--accent-hover);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(108, 99, 255, 0.3);
}

button[type="submit"]:active {
    transform: translateY(0);
}

.login-link {
    text-align: center;
    margin-top: 25px;
    padding-top: 20px;
    border-top: 1px solid var(--border-color);
}

.login-link a {
    color: var(--accent-color);
    text-decoration: none;
    font-weight: 500;
    transition: var(--transition);
}

.login-link a:hover {
    text-decoration: underline;
    color: var(--accent-hover);
}

/* Messages */
.message {
    padding: 12px 16px;
    border-radius: 8px;
    margin-top: 20px;
    text-align: center;
    font-weight: 500;
}

.success {
    background-color: rgba(74, 222, 128, 0.1);
    color: var(--success-color);
    border: 1px solid rgba(74, 222, 128, 0.3);
}

.error {
    background-color: rgba(255, 107, 107, 0.1);
    color: var(--error-color);
    border: 1px solid rgba(255, 107, 107, 0.3);
}

.login-redirect {
    display: block;
    text-align: center;
    margin-top: 15px;
    color: var(--accent-color);
    text-decoration: none;
    font-weight: 500;
    transition: var(--transition);
}

.login-redirect:hover {
    text-decoration: underline;
    color: var(--accent-hover);
}

/* Responsive Design */
@media (max-width: 600px) {
    .form-container {
        padding: 30px 20px;
    }
    
    h1 {
        font-size: 1.9rem;
    }
    
    .subtitle {
        font-size: 1rem;
    }
    
    input[type="text"],
    input[type="email"],
    input[type="password"],
    button[type="submit"] {
        padding: 12px 14px;
    }
}

@media (max-width: 400px) {
    body {
        padding: 10px;
    }
    
    .form-container {
        padding: 25px 15px;
    }
    
    h1 {
        font-size: 1.7rem;
    }
}

/* Loading Animation */
.loading {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 3px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    border-top-color: #fff;
    animation: spin 1s ease-in-out infinite;
    margin-right: 10px;
    vertical-align: middle;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.btn-loading {
    pointer-events: none;
    opacity: 0.7;
}

/* Error message styling */
.error-message {
    color: var(--error-color) !important;
    font-size: 0.85rem !important;
    margin-top: 5px !important;
}

/* Custom scrollbar */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: var(--bg-primary);
}

::-webkit-scrollbar-thumb {
    background: var(--bg-tertiary);
    border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
    background: var(--accent-color);
}
</style>
</head>
<body>
<div class="form-container">
    <h2 style="text-align:center;margin-bottom:16px">Login</h2>

    <?php if (!empty($error)): ?>
        <div class="message error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form action="" method="POST" autocomplete="off">
        <div style="margin-bottom:10px">
            <label for="email">Email</label><br>
            <input id="email" type="email" name="email" required style="width:100%;padding:10px;background:#2a2a2a;border:1px solid #333;color:#fff;border-radius:6px">
        </div>

        <div style="margin-bottom:10px">
            <label for="password">Password</label><br>
            <input id="password" type="password" name="password" required style="width:100%;padding:10px;background:#2a2a2a;border:1px solid #333;color:#fff;border-radius:6px">
        </div>

        <button type="submit" name="login" style="width:100%;padding:12px;border-radius:6px;background:#6c63ff;color:#fff;border:none;font-weight:600">Login</button>
    </form>

    <p style="text-align:center;margin-top:12px"><a href="register.php">Don't have an account? Register</a></p>
</div>
</body>
</html>
