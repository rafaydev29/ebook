<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - eBook Haven</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #8B5FBF;
            --secondary: #FF6584;
            --accent: #36D1DC;
            --dark: #121212;
            --darker: #0A0A0A;
            --light: #1E1E1E;
            --lighter: #2A2A2A;
            --text: #E0E0E0;
            --text-light: #A0A0A0;
            --success: #42B883;
            --border: rgba(255, 255, 255, 0.08);
        }

        body {
            background-color: var(--dark);
            color: var(--text);
            line-height: 1.6;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            background: var(--darker);
            color: white;
            padding: 20px 0;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid var(--border);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }

        nav ul {
            display: flex;
            list-style: none;
        }

        nav ul li {
            margin-left: 25px;
        }

        nav ul li a {
            color: var(--text-light);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            padding: 5px 0;
            position: relative;
        }

        nav ul li a:hover {
            color: var(--primary);
        }

        nav ul li a:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background: var(--primary);
            transition: width 0.3s ease;
        }

        nav ul li a:hover:after {
            width: 100%;
        }

        .hero {
            text-align: center;
            padding: 100px 0;
            background: linear-gradient(135deg, rgba(139, 95, 191, 0.2), rgba(54, 209, 220, 0.2));
            color: white;
            /* border-radius: 0 0 40px 40px; */
            margin-bottom: 60px;
            border: 1px solid var(--border);
            border-top: none;
        }

        .hero h1 {
            font-size: 3.5rem;
            margin-bottom: 20px;
            background: linear-gradient(to right, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto 30px;
            color: var(--text-light);
        }

        .btn {
            display: inline-block;
            background: linear-gradient(to right, var(--primary), var(--accent));
            color: white;
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(139, 95, 191, 0.3);
        }

        .section-title {
            text-align: center;
            margin-bottom: 50px;
            color: var(--text);
            position: relative;
            font-size: 2.5rem;
        }

        .section-title:after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: linear-gradient(to right, var(--primary), var(--accent));
            margin: 15px auto;
            border-radius: 2px;
        }

        .contact-container {
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            margin-bottom: 80px;
            background-color: black;
        }

        .contact-info {
            flex: 1;
            min-width: 300px;
            background: var(--light);
            padding: 40px;
            border-radius: 16px;
            border: 1px solid var(--border);
        }

        .contact-form {
            flex: 1;
            min-width: 300px;
            background: var(--dark);
            padding: 40px;
            border-radius: 16px;
            border: 1px solid var(--border);
        }

        .info-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 30px;
        }

        .info-icon {
            font-size: 1.5rem;
            color: var(--primary);
            margin-right: 20px;
            min-width: 30px;
            background: rgba(139, 95, 191, 0.1);
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .info-content h3 {
            margin-bottom: 5px;
            color: var(--text);
        }

        .info-content p {
            color: var(--text-light);
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text);
        }

        .form-control {
            width: 100%;
            padding: 15px;
            background: var(--lighter);
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
            color: var(--text);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(139, 95, 191, 0.2);
        }

        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }

        .social-section {
            background: var(--light);
            color: white;
            padding: 60px 0;
            border-radius: 20px;
            margin-bottom: 60px;
            text-align: center;
            border: 1px solid var(--border);
        }

        .social-icons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 30px;
        }

        .social-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--lighter);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            transition: all 0.3s ease;
            color: var(--text);
            border: 1px solid var(--border);
        }

        .social-icon:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-5px);
        }

        .faq-section {
            margin-bottom: 60px;
        }

        .faq-item {
            background: var(--light);
            border-radius: 12px;
            margin-bottom: 20px;
            overflow: hidden;
            border: 1px solid var(--border);
            transition: all 0.3s ease;
        }

        .faq-item:hover {
            border-color: var(--primary);
        }

        .faq-question {
            padding: 20px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
            color: var(--text);
        }

        .faq-answer {
            padding: 0 20px;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            color: var(--text-light);
        }

        .faq-item.active .faq-answer {
            padding: 0 20px 20px;
            max-height: 200px;
        }

        .faq-item.active .faq-toggle i {
            transform: rotate(180deg);
        }

        .faq-toggle {
            transition: all 0.3s ease;
            color: var(--primary);
        }

        /* footer {
            background: var(--darker);
            color: white;
            padding: 60px 0 30px;
            text-align: center;
            border-top: 1px solid var(--border);
        }

        .footer-content {
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            justify-content: space-around;
            margin-bottom: 40px;
        }

        .footer-section {
            flex: 1;
            min-width: 250px;
            text-align: left;
        }

        .footer-section h3 {
            margin-bottom: 20px;
            color: var(--text);
            font-size: 1.3rem;
        }

        .footer-section p, .footer-section a {
            color: var(--text-light);
            margin-bottom: 10px;
            display: block;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-section a:hover {
            color: var(--primary);
        }

        .footer-bottom {
            padding-top: 30px;
            border-top: 1px solid var(--border);
            color: var(--text-light);
        }

        .social-icons-footer {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin: 20px 0;
        }

        .social-icons-footer a {
            color: var(--text-light);
            font-size: 1.3rem;
            transition: all 0.3s ease;
        }

        .social-icons-footer a:hover {
            color: var(--primary);
        } */

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }

            nav ul {
                margin-top: 20px;
                justify-content: center;
                flex-wrap: wrap;
            }

            nav ul li {
                margin: 5px 10px;
            }

            .hero {
                padding: 60px 0;
            }

            .hero h1 {
                font-size: 2.5rem;
            }

            .contact-container, .footer-content {
                flex-direction: column;
                background-color: var(--dark);
            }

            .contact-info, .contact-form {
                width: 100%;
            }
            
            .section-title {
                font-size: 2rem;
            }
        }

        @media (max-width: 480px) {
            .hero h1 {
                font-size: 2rem;
            }

            .hero p {
                font-size: 1rem;
            }

            .btn {
                padding: 10px 20px;
            }

            .section-title {
                font-size: 1.8rem;
            }

            .social-icon {
                width: 50px;
                height: 50px;
                font-size: 1.2rem;
            }
            
            .contact-info, .contact-form {
                padding: 30px 20px;
            }
            
            .info-item {
                flex-direction: column;
                text-align: center;
            }
            
            .info-icon {
                margin-right: 0;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
   
           <?php include 'nav.php'; ?>

    <section class="hero">
        <div class="container">
            <h1>Get In Touch With Us</h1>
            <p>Have questions about our eBook collection or need support? We're here to help!</p>
            <a href="#contact-form" class="btn" style="margin-top: 20px;">Send us a Message</a>
        </div>
    </section>

    <div class="container">
        <h2 class="section-title">Contact eBook Haven</h2>
        
        <div class="contact-container">
            <div class="contact-info">
                <h2 style="margin-bottom: 20px; color: var(--text);">Let's Talk</h2>
                <p style="color: var(--text-light); margin-bottom: 30px;">We'd love to hear from you. Choose the most convenient way to contact us.</p>
                
                <div class="info-item">
                    <div class="info-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div class="info-content">
                        <h3>Visit Us</h3>
                        <p>123 Book Lane, Reading City<br>RC 56789</p>
                    </div>
                </div>
                
                <div class="info-item">
                    <div class="info-icon">
                        <i class="fas fa-phone"></i>
                    </div>
                    <div class="info-content">
                        <h3>Call Us</h3>
                        <p>+1 (555) 123-4567<br>Mon-Fri, 9:00 AM - 6:00 PM</p>
                    </div>
                </div>
                
                <div class="info-item">
                    <div class="info-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="info-content">
                        <h3>Email Us</h3>
                        <p>support@ebookhaven.com<br>info@ebookhaven.com</p>
                    </div>
                </div>
            </div>
            
            <div class="contact-form" id="contact-form">
                <h2 style="margin-bottom: 20px; color: var(--text);">Send a Message</h2>
                <form id="contactForm">
                    <div class="form-group">
                        <label for="name">Your Name</label>
                        <input type="text" id="name" class="form-control" placeholder="Enter your name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" class="form-control" placeholder="Enter your email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" class="form-control" placeholder="What is this regarding?">
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Your Message</label>
                        <textarea id="message" class="form-control" placeholder="Type your message here..." required></textarea>
                    </div>
                    
                    <button type="submit" class="btn" style="width: 100%;">Send Message</button>
                </form>
            </div>
        </div>
        
        <section class="social-section">
            <h2 style="color: var(--text); margin-bottom: 15px;">Follow Us On Social Media</h2>
            <p style="color: var(--text-light); max-width: 600px; margin: 0 auto;">Stay updated with our latest eBook releases, promotions, and news</p>
            
            <div class="social-icons">
                <a href="#" class="social-icon">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a href="#" class="social-icon">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="#" class="social-icon">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="#" class="social-icon">
                    <i class="fab fa-pinterest"></i>
                </a>
                <a href="#" class="social-icon">
                    <i class="fab fa-goodreads"></i>
                </a>
            </div>
        </section>
        
        <section class="faq-section">
            <h2 class="section-title">Frequently Asked Questions</h2>
            
            <div class="faq-item">
                <div class="faq-question">
                    How do I purchase an eBook?
                    <span class="faq-toggle"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="faq-answer">
                    <p>To purchase an eBook, simply browse our collection, click on the book you're interested in, and then click the "Buy Now" button. You'll need to create an account or log in to complete your purchase.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    What formats are your eBooks available in?
                    <span class="faq-toggle"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="faq-answer">
                    <p>Our eBooks are available in multiple formats including PDF, EPUB, and MOBI. You can choose your preferred format during the purchase process.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    Can I read eBooks on multiple devices?
                    <span class="faq-toggle"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="faq-answer">
                    <p>Yes, you can access your eBooks on up to 5 devices. Simply log into your account on any supported device to access your library.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    Do you offer refunds?
                    <span class="faq-toggle"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="faq-answer">
                    <p>We offer refunds within 14 days of purchase if you're unsatisfied with your eBook. Please contact our support team with your order details to request a refund.</p>
                </div>
            </div>
        </section>
    </div>

    <!-- <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>eBook Haven</h3>
                    <p>Your destination for the world's best eBooks. Discover, read, and enjoy!</p>
                </div>
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <a href="index.html">Home</a>
                    <a href="categories.html">Library</a>
                    <a href="categories.html">Categories</a>
                </div>
                <div class="footer-section">
                    <h3>Contact Us</h3>
                    <p><i class="fas fa-envelope"></i> support@ebookhaven.com</p>
                    <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
                </div>
            </div>
            <div class="social-icons-footer">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2023 eBook Haven. All rights reserved.</p>
            </div>
        </div>
    </footer> -->

    <script>
        // FAQ toggle functionality
        document.querySelectorAll('.faq-question').forEach(question => {
            question.addEventListener('click', () => {
                const item = question.parentElement;
                item.classList.toggle('active');
            });
        });

        // Form submission handling
        document.getElementById('contactForm').addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Thank you for your message! We will get back to you soon.');
            this.reset();
        });
        (function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="3muZwl8ydn2bOkQ31Fx3A";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();

    </script>
    <?php include 'footer.php'; ?>
</body>
</html>