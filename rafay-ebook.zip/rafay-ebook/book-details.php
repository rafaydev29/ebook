<?php
include 'config.php'; 

if (!isset($_GET['id'])) {
    die("Book not found!");
}

$id = intval($_GET['id']); // security
$query = "SELECT * FROM fiction WHERE id = $id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Book not found!");
}

$book = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($book['title']); ?> - Ebook World</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
    
        :root {
            --primary: #6C63FF;
            --secondary: #FF6584;
            --accent: #36D1DC;
            --dark: #1E1E2E;
            --darker: #161622;
            --light: #F0F0F5;
            --card-bg: #2A2A3C;
            --text: #E2E2E2;
            --text-light: #A0A0B0;
        }
    
        body {
            background: linear-gradient(135deg, var(--darker) 0%, var(--dark) 100%);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
        }
    
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
    
     
        nav {
            background: var(--dark);
            color: white;
            padding: 18px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
    
        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }
    
        .logo {
            font-size: 26px;
            font-weight: 700;
            display: flex;
            align-items: center;
            color: var(--light);
        }
    
        .logo i {
            margin-right: 10px;
            color: var(--primary);
        }
    
        .links {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
    
        .links a {
            color: var(--text);
            text-decoration: none;
            font-weight: 500;
            margin: 0 12px;
            transition: all 0.3s ease;
            padding: 6px 0;
            font-size: 0.95rem;
        }
    
        .links a:hover {
            color: var(--primary);
        }
    
      
        main {
            padding: 40px 0;
        }
    
        .book-detail {
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            background: var(--card-bg);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin: 0 auto;
            max-width: 1200px;
            width: 90%;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
    
        .book-cover {
            flex: 1;
            min-width: 300px;
            max-width: 400px;
        }
    
        .book-cover img {
            width: 100%;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
    
        .book-info {
            flex: 2;
            min-width: 300px;
        }
    
        .book-title {
            font-size: 2.2rem;
            color: var(--light);
            margin-bottom: 10px;
            font-weight: 600;
        }
    
        .book-author {
            font-size: 1.2rem;
            color: var(--primary);
            margin-bottom: 25px;
            font-style: italic;
        }
    
        .book-description {
            margin-bottom: 30px;
            line-height: 1.8;
        }
    
        .book-description p {
            margin-bottom: 15px;
            color: var(--text-light);
        }
    
        .pricing-section {
            margin-bottom: 30px;
        }
    
        .price {
            font-size: 2rem;
            font-weight: 700;
            color: var(--secondary);
            margin-bottom: 25px;
        }
    
        .formats, .subscription {
            margin-bottom: 25px;
        }
    
        .formats h3, .subscription h3 {
            font-size: 1.2rem;
            margin-bottom: 15px;
            color: var(--light);
            position: relative;
            display: inline-block;
        }
    
        .formats h3:after, .subscription h3:after {
            content: '';
            display: block;
            width: 50px;
            height: 3px;
            background: var(--primary);
            margin-top: 5px;
            border-radius: 2px;
        }
    
        .format-options {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 15px;
        }
    
        .format-btn {
            padding: 10px 20px;
            background: var(--dark);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
            color: var(--text);
        }
    
        .format-btn:hover {
            border-color: var(--primary);
        }
    
        .format-btn.selected {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
    
        .subscription-options {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
    
        .sub-option {
            flex: 1;
            min-width: 150px;
            padding: 15px;
            background: var(--dark);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
    
        .sub-option:hover {
            border-color: var(--primary);
        }
    
        .sub-option.selected {
            border-color: var(--primary);
            background: rgba(108, 99, 255, 0.1);
        }
    
        .sub-option h4 {
            color: var(--light);
            margin-bottom: 5px;
            font-size: 1rem;
        }
    
        .sub-option p {
            color: var(--secondary);
            font-weight: 500;
            font-size: 0.9rem;
        }
    
        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
    
        .btn {
            display: inline-block;
            padding: 12px 25px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }
    
        .btn-primary {
            background: var(--primary);
            color: white;
        }
    
        .btn-primary:hover {
            background: #5a52e0;
            transform: translateY(-2px);
        }
    
        .btn-secondary {
            background: var(--dark);
            color: var(--text);
            border: 2px solid var(--primary);
        }
    
        .btn-secondary:hover {
            background: var(--primary);
            color: white;
        }
    
        /* Footer */
        /* .footer {
            background: var(--darker);
            color: white;
            padding: 50px 0 20px;
            text-align: center;
            margin-top: 60px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }
    
        .footer-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
        }
    
        .footer-content h2 {
            font-size: 2rem;
            margin-bottom: 15px;
            color: var(--light);
        }
    
        .footer-content p {
            max-width: 600px;
            margin-bottom: 25px;
            color: var(--text-light);
        }
    
        .footer-icons {
            display: flex;
            gap: 15px;
        }
    
        .footer-icons a {
            color: var(--text);
            font-size: 1.3rem;
            transition: all 0.3s ease;
        }
    
        .footer-icons a:hover {
            color: var(--primary);
        }
    
        .footer-bottom {
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            color: var(--text-light);
            font-size: 0.9rem;
        }
     */
        /* Book Details Section */
        .book-details {
            margin-top: 30px;
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
    
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
    
        .detail-item {
            margin-bottom: 15px;
        }
    
        .detail-label {
            font-weight: 600;
            color: var(--light);
            margin-bottom: 5px;
        }
    
        .detail-value {
            color: var(--text-light);
        }
    
        /* Responsive Design */
        @media (max-width: 900px) {
            .nav-container {
                flex-direction: column;
                text-align: center;
            }
    
            .links {
                margin-top: 15px;
            }
    
            .links a {
                margin: 5px 10px;
            }
    
            .book-title {
                font-size: 1.9rem;
            }
        }
    
        @media (max-width: 768px) {
            .book-detail {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            
            .book-cover {
                max-width: 300px;
            }
            
            .formats h3:after, .subscription h3:after {
                margin: 5px auto 0;
            }
            
            .format-options, .subscription-options {
                justify-content: center;
            }
            
            .details-grid {
                grid-template-columns: 1fr;
            }
        }
    
        @media (max-width: 480px) {
            .book-title {
                font-size: 1.7rem;
            }
            
            .links a {
                font-size: 0.9rem;
                margin: 3px 8px;
            }
            
            .book-detail {
                padding: 20px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
            }
            
            .subscription-options {
                flex-direction: column;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'nav.php'; ?>
    
    <main>
        <div class="book-detail">
            <div class="book-cover">
               <?php if (!empty($book['cv'])) { ?>
                    <img src="<?php echo htmlspecialchars($book['cv']); ?>" alt="Book Cover" height='100%'>
                <?php } else { ?>
                    <img src="https://via.placeholder.com/400x600/2A2A3C/E2E2E2?text=Book+Cover" alt="Book Cover">
                <?php } ?>

            </div>
            
            <div class="book-info">
                <h1 class="book-title"><?php echo htmlspecialchars($book['title']); ?><span><button class='btn btn-secondary' style='margin:20px;' onclick='redirect()'>back</button></span></h1>
                <p class="book-author">by <?php echo htmlspecialchars($book['author']); ?></p>
                
                <div class="book-description">
                    <p><?php echo nl2br(htmlspecialchars($book['des'])); ?></p>
                </div>
                
                <div class="pricing-section">
                    
                    <div class="price">$<?php echo htmlspecialchars($book['price']); ?></div>
                    
                    <div class="formats">
                        <h3>Available Formats</h3>
                        <div class="format-options">
                            <button class="format-btn selected">PDF</button>
                            <button class="format-btn">ePUB</button>
                            <button class="format-btn">Mobi</button>
                            <button class="format-btn">Audiobook</button>
                        </div>
                    </div>
                    
                    <div class="subscription">
                        <h3>Subscription Options</h3>
                        <div class="subscription-options">
                            <div class="sub-option selected">
                                <h4>One-time Purchase</h4>
                                <p>Keep forever</p>
                            </div>
                            <div class="sub-option">
                                <h4>Monthly Access</h4>
                                <p>$4.99/month</p>
                            </div>
                            <div class="sub-option">
                                <h4>Annual Access</h4>
                                <p>$49.99/year</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="action-buttons">
                  <a href="#" class="btn btn-primary add-to-cart" data-id="<?php echo $book['id']; ?>">Add to Cart</a>
                    <a href="wishlist/add_to_wishlist.php?id=<?php echo $book['id']; ?>" class="btn btn-secondary">Add to Wishlist</a>
                </div>
            </div>
        </div>
        
        <!-- <div class="book-details">
            <h3 style="color: var(--light); margin-bottom: 20px;">Book Details</h3>
            <div class="details-grid">
                <div class="detail-item">
                    <div class="detail-label">Publisher</div>
                    <div class="detail-value"><?php echo htmlspecialchars($book['publisher']); ?></div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Publication Date</div>
                    <div class="detail-value"><?php echo htmlspecialchars($book['publication_date']); ?></div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Pages</div>
                    <div class="detail-value"><?php echo htmlspecialchars($book['pages']); ?></div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Language</div>
                    <div class="detail-value"><?php echo htmlspecialchars($book['language']); ?></div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">ISBN</div>
                    <div class="detail-value"><?php echo htmlspecialchars($book['isbn']); ?></div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Category</div>
                    <div class="detail-value"><?php echo htmlspecialchars($book['cate']); ?></div>
                </div>
            </div>
        </div> -->
    </main>

    <!-- <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <h2 class="logo">Ebook World</h2>
                <p>Dive into the world of ebooks with us. Read, learn, and explore.</p>
                <div class="footer-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-tiktok"></i></a>
                    <a href="#"><i class="fab fa-discord"></i></a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Ebook World | All Rights Reserved</p>
            </div>
        </div>
    </footer> -->
    <?php include 'footer.php'; ?>
   <script>
    function redirect(){
        window.location.href='books.php';
    }
document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', function(e){
        e.preventDefault();
        const bookId = this.dataset.id;

        fetch('cart/add_to_cart.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'book_id=' + bookId
        })
        .then(res => res.json())
        .then(data => {
            if(data.status === 'success'){
                alert('Book added to cart!');
                window.location.href = 'cart/cart.php';
            } else if(data.status === 'not_logged_in'){
                alert('You must register yourself to add to cart.');
                window.location.href = 'login.php';
            }
        });
    });
});
</script>

</body>
</html>
