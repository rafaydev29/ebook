<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        footer {
            background: var(--darker);
            color: white;
            padding: 60px 0 30px;
            text-align: center;
            border-top: 1px solid var(--border);
            /* display:flex; */
        }

        .footer-content {
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            justify-content: space-around;
            margin-bottom: 40px;
            flex-direction:row;
        }

        .footer-section {
            /* flex: 1; */
            min-width: 250px;
            text-align: left;
        }

        .footer-section h3 {
            margin-bottom: 20px;
            color: var(--text);
            font-size: 1.3rem;
        }

        .footer-section p, .footer-section a {
            color: var(--text-light);
            margin-bottom: 10px;
            display: block;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-section a:hover {
            color: var(--primary);
        }

        .footer-bottom {
            padding-top: 30px;
            border-top: 1px solid var(--border);
            color: var(--text-light);
        }

        .social-icons-footer {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin: 20px 0;
        }

        .social-icons-footer a {
            color: var(--text-light);
            font-size: 1.3rem;
            transition: all 0.3s ease;
        }

        .social-icons-footer a:hover {
            color: var(--primary);
        }

    </style>
</head>
<body>
     <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>eBook Haven</h3>
                    <p>Your destination for the world's best eBooks. Discover, read, and enjoy!</p>
                </div>
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <a href="index.html">Home</a>
                    <a href="categories.html">Library</a>
                    <a href="categories.html">Categories</a>
                </div>
                <div class="footer-section">
                    <h3>Contact Us</h3>
                    <p><i class="fas fa-envelope"></i> support@ebookhaven.com</p>
                    <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
                </div>
            </div>
            <div class="social-icons-footer">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2023 eBook Haven. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>