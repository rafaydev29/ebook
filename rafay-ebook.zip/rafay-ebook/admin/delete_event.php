<?php
include '../config.php';
$id=$_GET['id'];
$query="DELETE FROM events_view WHERE id=$id";

if(mysqli_query($conn,$query)){
    header("location:events_view.php");
}else{
    echo "<script>alert('error occured')</script>";
}
?>