<?php
include 'config.php';

$id = $_GET['id'] ?? 0;

if ($id) {
    $sql = "DELETE FROM Verified_users WHERE id=$id";
    if ($conn->query($sql)) {
        header("Location: admin_users.php");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
