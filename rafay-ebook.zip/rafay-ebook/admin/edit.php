<?php
include '../config.php';

$id = intval($_GET['id']);


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $category = $_POST['category'];
    $author = $_POST['author'];
    $description = $_POST['description'];

    $updateParts = [
        "title='$title'",
        "cate='$category'",
        "author='$author'",
        "des='$description'"
    ];

   
    if (!empty($_FILES['cover']['tmp_name'])) {
        $coverName = time() . "_" . basename($_FILES['cover']['name']);
        $targetPath = "../uploads/" . $coverName;
        if (move_uploaded_file($_FILES['cover']['tmp_name'], $targetPath)) {
            $coverPath = "uploads/" . $coverName;
            $updateParts[] = "cv='$coverPath'";
          }
    }

    
    if (!empty($_FILES['ebook']['tmp_name'])) {
        $file = addslashes(file_get_contents($_FILES['ebook']['tmp_name']));
        $file_type = $_FILES['ebook']['type'];
        $updateParts[] = "file='$file'";
        $updateParts[] = "file_type='$file_type'";
    }

    
    $query = "UPDATE fiction SET " . implode(", ", $updateParts) . " WHERE id=$id";

    if (mysqli_query($conn, $query)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Error updating ebook: " . mysqli_error($conn);
    }
}


$result = mysqli_query($conn, "SELECT * FROM fiction WHERE id=$id");
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Ebook - Admin Panel</title>
<style>
  /* Base Styles */
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }
  
  body {
    background-color: #121212;
    color: #e0e0e0;
    line-height: 1.6;
    padding: 20px;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
  
  /* Header Styles */
  h2 {
    color: #ffffff;
    text-align: center;
    margin-bottom: 30px;
    font-size: 2.2rem;
    font-weight: 300;
    letter-spacing: 1px;
    text-shadow: 0 0 10px rgba(0, 150, 255, 0.3);
  }
  
  /* Form Container */
  .form-container {
    background-color: #1e1e1e;
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
    width: 100%;
    max-width: 600px;
  }
  
  /* Form Elements */
  .form-group {
    margin-bottom: 25px;
  }
  
  label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #bb86fc;
  }
  
  input[type="text"],
  select {
    width: 100%;
    padding: 12px 15px;
    background-color: #2d2d2d;
    border: 1px solid #444;
    border-radius: 5px;
    color: #e0e0e0;
    font-size: 1rem;
    transition: all 0.3s;
  }
  
  input[type="text"]:focus,
  select:focus {
    outline: none;
    border-color: #bb86fc;
    box-shadow: 0 0 0 2px rgba(187, 134, 252, 0.2);
  }
  
  input[type="file"] {
    width: 100%;
    padding: 12px 15px;
    background-color: #2d2d2d;
    border: 1px dashed #444;
    border-radius: 5px;
    color: #e0e0e0;
    font-size: 1rem;
    transition: all 0.3s;
  }
  
  input[type="file"]:hover {
    border-color: #bb86fc;
    background-color: #2a2a2a;
  }
  
  /* Update Button */
  .update-btn {
    display: block;
    width: 100%;
    background: linear-gradient(135deg, #ff9800, #f57c00);
    color: white;
    text-decoration: none;
    padding: 14px;
    border-radius: 5px;
    font-weight: 600;
    font-size: 1.1rem;
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-top: 20px;
    text-align: center;
  }
  
  .update-btn:hover {
    background: linear-gradient(135deg, #ffa726, #f57c00);
    transform: translateY(-2px);
    box-shadow: 0 4px 10px rgba(255, 152, 0, 0.3);
  }
  
  /* Back Link */
  .back-link {
    display: inline-block;
    margin-top: 20px;
    color: #bb86fc;
    text-decoration: none;
    padding: 8px 15px;
    border-radius: 4px;
    transition: all 0.2s;
  }
  
  .back-link:hover {
    background-color: rgba(187, 134, 252, 0.1);
    text-decoration: underline;
  }
  
  /* File Upload Preview */
  .file-info {
    margin-top: 10px;
    padding: 10px;
    background-color: #2a2a2a;
    border-radius: 5px;
    font-size: 0.9rem;
  }
  
  .current-file {
    background-color: rgba(3, 218, 198, 0.1);
    border-left: 3px solid #03dac6;
    padding: 10px;
    margin-bottom: 10px;
  }
  
  /* Responsive Design */
  @media (max-width: 768px) {
    body {
      padding: 15px;
    }
    
    .form-container {
      padding: 25px;
    }
    
    h2 {
      font-size: 1.8rem;
    }
  }
  
  /* Success/Error Messages */
  .message {
    padding: 12px;
    border-radius: 5px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: 600;
  }
  
  .success {
    background-color: rgba(76, 175, 80, 0.2);
    color: #4caf50;
    border: 1px solid #4caf50;
  }
  
  .error {
    background-color: rgba(244, 67, 54, 0.2);
    color: #f44336;
    border: 1px solid #f44336;
  }
  
  /* Category Options Styling */
  .category-options {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-top: 10px;
  }
  
  .category-option {
    padding: 10px;
    background-color: #2d2d2d;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.2s;
    text-align: center;
  }
  
  .category-option:hover {
    background-color: #3d3d3d;
  }
  
  .category-option.selected {
    background-color: rgba(187, 134, 252, 0.2);
    border: 1px solid #bb86fc;
  }
</style>
  <style>
    body { background:#121212; color:#e0e0e0; font-family:sans-serif; padding:20px; display:flex; justify-content:center; }
    .form-container { background:#1e1e1e; padding:30px; border-radius:10px; width:100%; max-width:700px; }
    h2 { color:#fff; margin-bottom:20px; text-align:center; }
    .form-group { margin-bottom:20px; }
    label { display:block; margin-bottom:8px; color:#bb86fc; font-weight:600; }
    input[type="text"], textarea, select {
      width:100%; padding:12px; border:1px solid #444; border-radius:5px;
      background:#2d2d2d; color:#e0e0e0; resize:vertical;
    }
    input[type="file"] { width:100%; padding:10px; background:#2d2d2d; border:1px dashed #555; border-radius:5px; color:#ccc; }
    img { max-width:150px; margin-top:10px; border-radius:5px; }
    .update-btn {
      width:100%; padding:14px; background:linear-gradient(135deg,#ff9800,#f57c00);
      border:none; color:#fff; border-radius:5px; font-size:1.1rem; cursor:pointer;
    }
    .update-btn:hover { background:linear-gradient(135deg,#ffa726,#f57c00); }
    .back-link { display:block; margin-top:15px; text-align:center; color:#bb86fc; text-decoration:none; }
    .back-link:hover { text-decoration:underline; }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>✏️ Edit Ebook</h2>
    
    <?php if(isset($error)): ?>
      <div style="color:red; margin-bottom:15px;"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <label for="title">Ebook Title</label>
        <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($row['title']); ?>" required>
      </div>

      <div class="form-group">
        <label for="author">Author</label>
        <input type="text" name="author" id="author" value="<?php echo htmlspecialchars($row['author']); ?>" required>
      </div>

      <div class="form-group">
        <label for="description">Description</label>
        <textarea name="description" id="description" rows="5" required><?php echo htmlspecialchars($row['des']); ?></textarea>
      </div>
      
      <div class="form-group">
        <label for="category">Category</label>
        <select name="category" id="category" required>
          <option value="">-- Choose Category --</option>
          <option value="tech" <?php echo $row['cate']=='tech'?'selected':''; ?>>Tech</option>
          <option value="fiction" <?php echo $row['cate']=='fiction'?'selected':''; ?>>Fiction</option>
          <option value="non-fictional" <?php echo $row['cate']=='non-fictional'?'selected':''; ?>>Non-Fictional</option>
          <option value="sciencefiction" <?php echo $row['cate']=='sciencefiction'?'selected':''; ?>>Science Fiction</option>
          <option value="mystery&thriller" <?php echo $row['cate']=='mystery&thriller'?'selected':''; ?>>Mystery & Thriller</option>
          <option value="business&finance" <?php echo $row['cate']=='business&finance'?'selected':''; ?>>Business & Finance</option>
          <option value="self-help" <?php echo $row['cate']=='self-help'?'selected':''; ?>>Self-Help</option>
          <option value="solar system" <?php echo $row['cate']=='solar system'?'selected':''; ?>>Solar System</option>
        </select>
      </div>

      <div class="form-group">
        <label for="cover">Cover Image (optional)</label>
        <?php if(!empty($row['cv'])): ?>
          <div>Current: <br><img src="../<?php echo $row['cv']; ?>" alt="cover"></div>
        <?php endif; ?>
        <input type="file" name="cover" id="cover" accept="image/*">
      </div>

      <div class="form-group">
        <label for="ebook">Ebook File (optional)</label>
        <div>Current File: <?php echo strtoupper(str_replace('application/','',$row['file_type'])); ?></div>
        <input type="file" name="ebook" id="ebook" accept=".pdf,.doc,.docx">
      </div>
      
      <button type="submit" class="update-btn">Update Ebook</button>
    </form>
    
    <a href="index.php" class="back-link">← Back to Dashboard</a>
  </div>
</body>
</html>
