<?php
include '../config.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("No event ID provided.");
}

$id = (int)$_GET['id'];


$delete = "DELETE FROM essay_competition WHERE id=$id";

if (mysqli_query($conn, $delete)) {
    echo "<script>alert('Event deleted successfully'); window.location.href='essay_view.php';</script>";
} else {
    echo "Error deleting: " . mysqli_error($conn);
}
?>
