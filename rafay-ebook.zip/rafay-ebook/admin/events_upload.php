<?php include '../config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <label for="name">Events name</label>
        <input type="text" name="name" reqiured>

        <label for="description">Description</label>
        <textarea name="desc" id="" reqiured></textarea>

        <label for="number">Prize (if competition event)</label>
        <input type="text" name="number">

        <label for="time">Duration (if you wanted to add in event)</label>
        <input type="text" name="time">

        <button name="btn">Launch Events</button>
    </form>

    <?php
    if (isset($_POST['btn'])) {
        $name   = $_POST['name'];
        $desc   = $_POST['desc'];
        $number = $_POST['number'];
        $time   = $_POST['time'];

        
        $state = $conn->prepare("INSERT INTO events_view (`name`, `desc`, `number`, `time`) VALUES (?, ?, ?, ?)");

        
        $state->bind_param("ssss", $name, $desc, $number, $time);

        if ($state->execute()) {
            echo "Event launched successfully!";
            header('location:events_view.php');
        } else {
            echo "Error: " . $state->error;
        }
    }
    ?>
</body>
</html>
