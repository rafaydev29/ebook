<?php
include '../config.php';

$query = "SELECT * FROM notifications ORDER BY created_at DESC";
$run = mysqli_query($conn, $query);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql = "INSERT INTO notifications (title, description) 
            VALUES ('$title', '$description')";

    if ($conn->query($sql) === TRUE) {
        $success_message = "<div class='success-message'>✅ Notification has been sent successfully</div>";
        
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $error_message = "<div class='error-message'>❌ Error: " . $conn->error . "</div>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notification Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #bb86fc;
            --secondary: #03dac6;
            --danger: #cf6679;
            --bg-dark: #121212;
            --bg-card: #1e1e1e;
            --bg-input: #2d2d2d;
            --border: #333;
            --text: #e0e0e0;
            --text-light: #888;
        }

        body {
            background: var(--bg-dark);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text);
            display: flex;
            min-height: 100vh;
            line-height: 1.6;
            justify-content:center;
            align-items:center;
        }

       .main-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%; 
}

      .content-wrapper {
    margin-left: 0;  /* remove the sidebar spacing */
    max-width: 800px; /* keep content nicely centered */
    width: 100%;
    padding: 40px;
}

        .page-header {
            margin-bottom: 40px;
            text-align: center;
        }

        .page-title {
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 15px;
            /* margin-right:15%; */
        }

        .page-subtitle {
            color: var(--text-light);
            font-size: 1.1rem;
            width: 600px;
            /* margin: 0 auto; */
            /* margin-right:10%; */
        }

        .form-container {
            background: var(--bg-card);
            padding: 40px;
            border-radius: 16px;
            margin-bottom: 40px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            border: 1px solid var(--border);
            transition: transform 0.3s ease;
            /* margin-right:15%; */
        }

        .form-container:hover {
            transform: translateY(-2px);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--primary);
        }

        .section-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary), #7c4dff);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }

        .section-title {
            font-size: 1.8rem;
            font-weight: 600;
            color: var(--text);
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: var(--primary);
            font-weight: 600;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        label i {
            width: 20px;
            text-align: center;
        }

        input, textarea {
            width: 100%;
            padding: 16px 20px;
            border: 2px solid var(--border);
            border-radius: 12px;
            background: var(--bg-input);
            color: var(--text);
            font-size: 1rem;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        input:focus, textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(187, 134, 252, 0.1);
            transform: translateY(-1px);
        }

        textarea {
            resize: vertical;
            min-height: 140px;
            line-height: 1.5;
        }

        .submit-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            width: 100%;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            border: none;
            padding: 18px;
            color: #fff;
            font-weight: 600;
            font-size: 1.1rem;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: 10px;
        }

        .submit-btn:hover {
            background: linear-gradient(135deg, #2196f3, #1565c0);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(33, 150, 243, 0.4);
        }

        .submit-btn:active {
            transform: translateY(-1px);
        }

        .success-message, .error-message {
            margin: 25px 0;
            padding: 20px;
            border-radius: 12px;
            font-weight: 500;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .success-message {
            background: rgba(76, 175, 80, 0.15);
            border: 2px solid #4caf50;
            color: #4caf50;
        }

        .error-message {
            background: rgba(244, 67, 54, 0.15);
            border: 2px solid #f44336;
            color: #f44336;
        }

        .notifications-container {
            background: var(--bg-card);
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            border: 1px solid var(--border);
        }

        .notifications-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--secondary);
        }

        .notifications-count {
            background: var(--secondary);
            color: var(--bg-dark);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .card-grid {
            display: grid;
            gap: 20px;
        }

        .card {
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 25px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
        }

        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4);
            border-color: var(--primary);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .card-title {
            color: var(--primary);
            font-size: 1.3rem;
            font-weight: 600;
            line-height: 1.3;
            flex: 1;
            margin-right: 15px;
        }

        .card-time {
            color: var(--text-light);
            font-size: 0.85rem;
            font-weight: 500;
            white-space: nowrap;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .card-description {
            color: var(--text);
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .card-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            padding-top: 15px;
            border-top: 1px solid var(--border);
        }

        .action-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .edit-btn {
            background: rgba(30, 136, 229, 0.2);
            color: #1e88e5;
        }

        .delete-btn {
            background: rgba(207, 102, 121, 0.2);
            color: var(--danger);
        }

        .action-btn:hover {
            transform: translateY(-1px);
        }

        .empty-state {
            text-align: center;
            padding: 60px 40px;
            color: var(--text-light);
        }

        .empty-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-title {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--text-light);
        }

        .empty-description {
            font-size: 1rem;
            max-width: 400px;
            margin: 0 auto;
        }

        @media (max-width: 1024px) {
            .content-wrapper {
                margin-left: 0;
                padding: 30px;
            }
        }

        @media (max-width: 768px) {
            .content-wrapper {
                padding: 20px;
            }

            .page-title {
                font-size: 2rem;
            }

            .form-container,
            .notifications-container {
                padding: 30px 25px;
            }

            .section-header {
                flex-direction: column;
                text-align: center;
                gap: 10px;
            }

            .card-header {
                flex-direction: column;
                gap: 10px;
            }

            .card-title {
                margin-right: 0;
            }

            .card-actions {
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .content-wrapper {
                padding: 15px;
            }

            .form-container,
            .notifications-container {
                padding: 25px 20px;
            }

            .page-title {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>    
    
    <div class="main-container">
        <div class="content-wrapper">
            <!-- Page Header -->
            <div class="page-header">
                <h1 class="page-title">Notification Management</h1>
                <p class="page-subtitle">Create and manage notifications for your platform. Keep users informed with important updates and announcements.</p>
            </div>

            <!-- Success/Error Messages -->
            <?php 
            if (isset($success_message)) echo $success_message;
            if (isset($error_message)) echo $error_message;
            ?>

            <!-- Add Notification Form -->
            <div class="form-container">
                <div class="section-header">
                    <div class="section-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h2 class="section-title">Create New Notification</h2>
                </div>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="title">
                            <i class="fas fa-heading"></i>
                            Notification Title
                        </label>
                        <input type="text" id="title" name="title" required 
                               placeholder="Enter a clear and concise title for your notification">
                    </div>
                    
                    <div class="form-group">
                        <label for="description">
                            <i class="fas fa-align-left"></i>
                            Notification Description
                        </label>
                        <textarea id="description" name="description" rows="5" required
                                  placeholder="Provide detailed information about this notification. Include any important details, links, or instructions."></textarea>
                    </div>
                    
                    <button type="submit" class="submit-btn">
                        <i class="fas fa-paper-plane"></i>
                        Send Notification
                    </button>
                </form>
            </div>

            <!-- Existing Notifications -->
            <div class="notifications-container">
                <div class="notifications-header">
                    <div class="section-icon">
                        <i class="fas fa-list-alt"></i>
                    </div>
                    <h2 class="section-title">Existing Notifications</h2>
                    <span class="notifications-count">
                        <?php echo mysqli_num_rows($run); ?> Total
                    </span>
                </div>
                
                <div class="card-grid">
                    <?php 
                    if (mysqli_num_rows($run) > 0) {
                        while($row = mysqli_fetch_assoc($run)) { 
                    ?>
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h3>
                                <span class="card-time">
                                    <i class="far fa-clock"></i>
                                    <?php echo date('M j, Y g:i A', strtotime($row['created_at'])); ?>
                                </span>
                            </div>
                            <p class="card-description"><?php echo htmlspecialchars($row['description']); ?></p>
                            <div class="card-actions">
                                <button class="action-btn edit-btn">
                                    <i class="fas fa-edit"></i>
                                    Edit
                                </button>
                                <button class="action-btn delete-btn">
                                    <i class="fas fa-trash"></i>
                                    Delete
                                </button>
                            </div>
                        </div>
                    <?php 
                        }
                    } else { 
                    ?>
                        <div class="empty-state">
                            <div class="empty-icon">
                                <i class="fas fa-bell-slash"></i>
                            </div>
                            <h3 class="empty-title">No Notifications Yet</h3>
                            <p class="empty-description">
                                Create your first notification using the form above to keep your users informed about important updates and announcements.
                            </p>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Add some interactive functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Add focus effects to form inputs
            const inputs = document.querySelectorAll('input, textarea');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.classList.add('focused');
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.classList.remove('focused');
                });
            });

            // Smooth scroll to form when there's an error
            <?php if (isset($error_message)): ?>
                document.querySelector('.form-container').scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });
            <?php endif; ?>

            // Add confirmation for delete buttons
            const deleteButtons = document.querySelectorAll('.delete-btn');
            deleteButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    if (!confirm('Are you sure you want to delete this notification? This action cannot be undone.')) {
                        e.preventDefault();
                    }
                });
            });
        });
    </script>
</body>
</html>