<?php include '../config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Launch Competition - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Dark Theme CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        :root {
            --primary: #bb86fc;
            --light: #ffffff;
            --text: #e0e0e0;
            --bg-dark: #121212;
            --bg-card: #1e1e1e;
            --bg-input: #2a2a2a;
            --border: #333;
            --accent: #1e88e5;
            --danger: #cf6679;
            --success: #03dac6;
            --warning: #ffb74d;
        }
        
        body {
            background-color: var(--bg-dark);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            padding: 20px;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(156, 77, 255, 0.1) 0%, transparent 20%),
                radial-gradient(circle at 90% 80%, rgba(255, 77, 166, 0.1) 0%, transparent 20%);
        }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: var(--bg-card);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
            border: 1px solid var(--border);
        }
        
        .header {
            background: linear-gradient(135deg, #bb86fc, #7c4dff);
            padding: 25px;
            text-align: center;
        }
        
        .header h1 {
            color: white;
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        .header p {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1.1rem;
        }
        
        .content {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: var(--primary);
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 16px;
            background-color: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(187, 134, 252, 0.2);
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn {
            flex: 1;
            padding: 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-size: 1.1rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #2196f3, #1565c0);
            box-shadow: 0 5px 15px rgba(0, 100, 200, 0.4);
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: var(--bg-input);
            color: var(--text);
            border: 1px solid var(--border);
        }
        
        .btn-secondary:hover {
            background: #2d2d2d;
            transform: translateY(-2px);
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease;
        }
        
        .alert-success {
            background: rgba(3, 218, 198, 0.2);
            border: 1px solid var(--success);
            color: var(--success);
        }
        
        .alert-error {
            background: rgba(207, 102, 121, 0.2);
            border: 1px solid var(--danger);
            color: var(--danger);
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .form-hint {
            font-size: 0.9rem;
            color: var(--text-secondary);
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .input-icon {
            position: relative;
        }
        
        .input-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--primary);
        }
        
        .input-icon .form-control {
            padding-left: 45px;
        }
        
        @media (max-width: 768px) {
            .btn-group {
                flex-direction: column;
            }
            
            body {
                padding: 10px;
            }
            
            .header h1 {
                font-size: 1.7rem;
            }
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php';?>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-rocket"></i> Launch New Competition</h1>
            <p>Create a new essay writing competition for participants</p>
        </div>
        
        <div class="content">
            <?php
            if (isset($_POST['submit'])) {
                $name = $_POST['name'];
                $description = $_POST['description'];
                $prize = $_POST['prize'];
                $duration = $_POST['duration'];

                $stmt = $conn->prepare("INSERT INTO essay_competition (name, description, prize, duration) VALUES (?, ?, ?, ?)");

                if ($stmt === false) {
                    echo '<div class="alert alert-error">
                            <i class="fas fa-exclamation-triangle"></i>
                            <div>
                                <strong>Error:</strong> Prepare failed: ' . $conn->error . '
                            </div>
                          </div>';
                } else {
                    $stmt->bind_param("ssss", $name, $description, $prize, $duration);

                    if ($stmt->execute()) {
                        echo '<div class="alert alert-success">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <strong>Success!</strong> Competition launched successfully!
                                </div>
                              </div>';
                    } else {
                        echo '<div class="alert alert-error">
                                <i class="fas fa-exclamation-triangle"></i>
                                <div>
                                    <strong>Error:</strong> ' . $stmt->error . '
                                </div>
                              </div>';
                    }
                    $stmt->close();
                }
            }
            ?>
            
            <form action="" method="POST">
                <div class="form-group">
                    <label for="name"><i class="fas fa-trophy"></i> Competition Name</label>
                    <div class="input-icon">
                        <i class="fas fa-heading"></i>
                        <input type="text" name="name" class="form-control" placeholder="Enter competition name" required>
                    </div>
                    <div class="form-hint">
                        <i class="fas fa-lightbulb"></i> Choose a catchy name that will attract participants
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description"><i class="fas fa-align-left"></i> Competition Description</label>
                    <div class="input-icon">
                        <i class="fas fa-file-alt"></i>
                        <input type="text" name="description" class="form-control" placeholder="Describe the competition theme and rules" required>
                    </div>
                    <div class="form-hint">
                        <i class="fas fa-lightbulb"></i> Clearly explain what participants need to write about
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="prize"><i class="fas fa-gift"></i> Winning Prize</label>
                    <div class="input-icon">
                        <i class="fas fa-award"></i>
                        <input type="text" name="prize" class="form-control" placeholder="e.g., $500, Certificate, Publication" required>
                    </div>
                    <div class="form-hint">
                        <i class="fas fa-lightbulb"></i> List all prizes and rewards for winners
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="duration"><i class="fas fa-clock"></i> Competition Duration</label>
                    <div class="input-icon">
                        <i class="fas fa-calendar"></i>
                        <input type="text" name="duration" class="form-control" placeholder="e.g., 3 hours, 1 week, 30 days" required>
                    </div>
                    <div class="form-hint">
                        <i class="fas fa-lightbulb"></i> Specify the time limit for participants
                    </div>
                </div>
                
                <div class="btn-group">
                    <button type="submit" name="submit" class="btn btn-primary">
                        <i class="fas fa-rocket"></i> Launch Competition
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset Form
                    </button>
                </div>
            </form>
        </div>
    </div>
    <!-- <?php include 'footer.php';?> -->
</body>
</html>