<?php

include '../config.php';

// Get ID from query string
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("No event ID provided.");
}
$id = (int)$_GET['id'];

// Fetch current event  
$result = mysqli_query($conn, "SELECT * FROM essay_competition WHERE id=$id");
if (!$result || mysqli_num_rows($result) == 0) {
    die("Event not found.");
}
$row = mysqli_fetch_assoc($result);

// Handle form submission
if (isset($_POST['update'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $prize = mysqli_real_escape_string($conn, $_POST['prize']);
    $duration = mysqli_real_escape_string($conn, $_POST['duration']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    $update = "UPDATE essay_competition 
               SET name='$name', description='$description', prize='$prize', duration='$duration', status='$status' 
               WHERE id=$id";

    if (mysqli_query($conn, $update)) {
        echo "<script>alert('Event updated successfully'); window.location.href='essay_view.php';</script>";
    } else {
        echo "Error updating: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Event</title>
</head>
<body>
    <h2>Edit Essay Competition</h2>
    <form method="POST">
        <label>Name:</label><br>
        <input type="text" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required><br><br>

        <label>Description:</label><br>
        <textarea name="description" required><?php echo htmlspecialchars($row['description']); ?></textarea><br><br>

        <label>Prize:</label><br>
        <input type="text" name="prize" value="<?php echo htmlspecialchars($row['prize']); ?>" required><br><br>

        <label>Duration:</label><br>
        <input type="text" name="duration" value="<?php echo htmlspecialchars($row['duration']); ?>" required><br><br>

        <label>Status:</label><br>
        <select name="status">
            <option value="resume" <?php if ($row['status']=="resume") echo "selected"; ?>>Resume</option>
            <option value="paused" <?php if ($row['status']=="paused") echo "selected"; ?>>Paused</option>
            <option value="completed" <?php if ($row['status']=="completed") echo "selected"; ?>>Completed</option>
        </select><br><br>

        <button type="submit" name="update">Update Event</button>
    </form>
</body>
</html>
