<?php
include '../config.php';

// Get ID from query string
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("No event ID provided.");
}
$id = (int)$_GET['id'];

// Fetch current event
$result = mysqli_query($conn, "SELECT * FROM essay_competition WHERE id=$id");
if (!$result || mysqli_num_rows($result) == 0) {
    die("Event not found.");
}
$row = mysqli_fetch_assoc($result);

// Handle form submission
if (isset($_POST['update'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $prize = mysqli_real_escape_string($conn, $_POST['prize']);
    $duration = mysqli_real_escape_string($conn, $_POST['duration']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    $update = "UPDATE essay_competition 
               SET name='$name', description='$description', prize='$prize', duration='$duration', status='$status' 
               WHERE id=$id";

    if (mysqli_query($conn, $update)) {
        echo "<script>alert('Event updated successfully'); window.location.href='essay_view.php';</script>";
    } else {
        echo "Error updating: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Event - Essay Competition</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #bb86fc;
            --primary-dark: #9c67d6;
            --primary-light: #d0b8ff;
            --secondary: #03dac6;
            --bg-dark: #121212;
            --bg-card: #1e1e1e;
            --bg-input: #2d2d2d;
            --border: #333;
            --text: #e0e0e0;
            --text-light: #888;
            --success: #4caf50;
            --warning: #ff9800;
            --danger: #cf6679;
        }

        body {
            background: linear-gradient(135deg, #1a0b2e, #121212);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            line-height: 1.6;
        }

        .container {
            width: 100%;
            max-width: 800px;
            background: var(--bg-card);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.5);
            border: 1px solid var(--border);
        }

        .header {
            background: linear-gradient(135deg, var(--primary), #7c4dff);
            padding: 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
        }

        .header-content {
            position: relative;
            z-index: 1;
        }

        .header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
            color: white;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }

        .header p {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.9);
            max-width: 500px;
            margin: 0 auto;
        }

        .event-id {
            display: inline-block;
            background: rgba(255, 255, 255, 0.2);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            margin-top: 10px;
            color: white;
        }

        .form-container {
            padding: 40px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: var(--primary);
            font-weight: 600;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        label i {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        input, textarea, select {
            width: 100%;
            padding: 16px 20px;
            border: 2px solid var(--border);
            border-radius: 12px;
            background: var(--bg-input);
            color: var(--text);
            font-size: 1rem;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(187, 134, 252, 0.2);
            transform: translateY(-2px);
        }

        textarea {
            resize: vertical;
            min-height: 120px;
            line-height: 1.5;
        }

        select {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23bb86fc' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 15px center;
            background-size: 16px;
            padding-right: 45px;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 16px 25px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(187, 134, 252, 0.4);
        }

        .btn-secondary {
            background: var(--bg-input);
            color: var(--text);
            border: 2px solid var(--border);
        }

        .btn-secondary:hover {
            background: #333;
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        }

        .status-indicator {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
            margin-left: 15px;
        }

        .status-resume {
            background: rgba(76, 175, 80, 0.2);
            color: var(--success);
            border: 1px solid var(--success);
        }

        .status-paused {
            background: rgba(255, 152, 0, 0.2);
            color: var(--warning);
            border: 1px solid var(--warning);
        }

        .status-completed {
            background: rgba(207, 102, 121, 0.2);
            color: var(--danger);
            border: 1px solid var(--danger);
        }

        .form-hint {
            font-size: 0.85rem;
            color: var(--text-light);
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
                align-items: flex-start;
            }
            
            .container {
                border-radius: 15px;
            }
            
            .header {
                padding: 25px 20px;
            }
            
            .header h1 {
                font-size: 2rem;
            }
            
            .form-container {
                padding: 30px 25px;
            }
            
            .button-group {
                flex-direction: column;
            }
        }

        @media (max-width: 480px) {
            .header h1 {
                font-size: 1.8rem;
            }
            
            .form-container {
                padding: 25px 20px;
            }
            
            input, textarea, select {
                padding: 14px 16px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="header-content">
                <h1><i class="fas fa-edit"></i> Edit Essay Competition</h1>
                <p>Update the details of your essay competition event</p>
                <div class="event-id">Event ID: #<?php echo $id; ?></div>
            </div>
        </div>
        
        <div class="form-container">
            <form method="POST">
                <div class="form-group">
                    <label for="name">
                        <i class="fas fa-heading"></i>
                        Competition Name
                    </label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required>
                    <div class="form-hint">
                        <i class="fas fa-info-circle"></i>
                        Enter a clear and engaging title for your competition
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">
                        <i class="fas fa-align-left"></i>
                        Competition Description
                    </label>
                    <textarea id="description" name="description" required><?php echo htmlspecialchars($row['description']); ?></textarea>
                    <div class="form-hint">
                        <i class="fas fa-info-circle"></i>
                        Provide detailed information about the competition rules and requirements
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="prize">
                        <i class="fas fa-trophy"></i>
                        Prize Information
                    </label>
                    <input type="text" id="prize" name="prize" value="<?php echo htmlspecialchars($row['prize']); ?>" required>
                    <div class="form-hint">
                        <i class="fas fa-info-circle"></i>
                        Describe the prizes winners will receive
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="duration">
                        <i class="fas fa-clock"></i>
                        Competition Duration
                    </label>
                    <input type="text" id="duration" name="duration" value="<?php echo htmlspecialchars($row['duration']); ?>" required>
                    <div class="form-hint">
                        <i class="fas fa-info-circle"></i>
                        Specify the timeline (e.g., "2 weeks", "30 days")
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="status">
                        <i class="fas fa-toggle-on"></i>
                        Competition Status
                        <span class="status-indicator status-<?php echo $row['status']; ?>">
                            <i class="fas fa-circle"></i>
                            Current: <?php echo ucfirst($row['status']); ?>
                        </span>
                    </label>
                    <select id="status" name="status">
                        <option value="resume" <?php if ($row['status']=="resume") echo "selected"; ?>>Active - Accepting Submissions</option>
                        <option value="paused" <?php if ($row['status']=="paused") echo "selected"; ?>>Paused - Not Accepting Submissions</option>
                        <option value="completed" <?php if ($row['status']=="completed") echo "selected"; ?>>Completed - Competition Ended</option>
                    </select>
                    <div class="form-hint">
                        <i class="fas fa-info-circle"></i>
                        Control whether the competition is active, paused, or completed
                    </div>
                </div>
                
                <div class="button-group">
                    <button type="submit" name="update" class="btn btn-primary">
                        <i class="fas fa-save"></i>
                        Update Event
                    </button>
                    <a href="essay_view.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i>
                        Back to Events
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Add real-time status indicator update
        document.getElementById('status').addEventListener('change', function() {
            const statusIndicator = document.querySelector('.status-indicator');
            const status = this.value;
            
            // Remove existing status classes
            statusIndicator.classList.remove('status-resume', 'status-paused', 'status-completed');
            
            // Add new status class
            statusIndicator.classList.add(`status-${status}`);
            
            // Update text
            statusIndicator.innerHTML = `<i class="fas fa-circle"></i> Selected: ${status.charAt(0).toUpperCase() + status.slice(1)}`;
        });

        // Add character counter for description
        const description = document.getElementById('description');
        const descriptionHint = description.parentElement.querySelector('.form-hint');
        
        // Create character counter element
        const charCounter = document.createElement('div');
        charCounter.className = 'form-hint';
        charCounter.innerHTML = `<i class="fas fa-font"></i> Character count: <span id="charCount">${description.value.length}</span>`;
        description.parentElement.appendChild(charCounter);
        
        description.addEventListener('input', function() {
            document.getElementById('charCount').textContent = this.value.length;
        });
    </script>
</body>
</html>