<?php
include '../config.php';
$id=$_GET['id'];
$query="DELETE FROM Launch_Story_Competition WHERE id=$id";

if(mysqli_query($conn,$query)){
    header("location:Story_view.php");
}else{
    echo "<script>alert('error occured')</script>";
}
?>