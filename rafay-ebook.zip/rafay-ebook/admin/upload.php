<?php
include '../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $des = mysqli_real_escape_string($conn, $_POST['des']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);

   
    $file = addslashes(file_get_contents($_FILES['ebook']['tmp_name']));
    $file_type = $_FILES['ebook']['type'];

    
    $coverFile = $_FILES['cover'];
    $coverName = time() . "_" . basename($coverFile['name']);
    $targetDir = "../uploads/covers/";
    $targetFile = $targetDir . $coverName;

   
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

  
    if (move_uploaded_file($coverFile['tmp_name'], $targetFile)) {
        $coverURL = "uploads/covers/" . $coverName;
    } else {
        $coverURL = "";
    }

    
    $query = "INSERT INTO fiction (title, cate, author, des, price, cv, file, file_type) 
              VALUES ('$title', '$category', '$author', '$des', '$price', '$coverURL', '$file', '$file_type')";

    if (mysqli_query($conn, $query)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Upload Ebook - Admin Panel</title>
  <style>
   
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    body {
      background-color: #121212;
      color: #e0e0e0;
      line-height: 1.6;
      padding: 20px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    
  
    h2 {
      color: #ffffff;
      text-align: center;
      margin-bottom: 30px;
      font-size: 2.2rem;
      font-weight: 300;
      letter-spacing: 1px;
      text-shadow: 0 0 10px rgba(0, 150, 255, 0.3);
    }
    
   
    .form-container {
      background-color: #1e1e1e;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
      width: 100%;
      max-width: 600px;
    }
    
  
    .form-group {
      margin-bottom: 25px;
    }
    
    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: #bb86fc;
    }
    
    input[type="text"],
    select {
      width: 100%;
      padding: 12px 15px;
      background-color: #2d2d2d;
      border: 1px solid #444;
      border-radius: 5px;
      color: #e0e0e0;
      font-size: 1rem;
      transition: all 0.3s;
    }
    input[type="number"],
    select {
      width: 100%;
      padding: 12px 15px;
      background-color: #2d2d2d;
      border: 1px solid #444;
      border-radius: 5px;
      color: #e0e0e0;
      font-size: 1rem;
      transition: all 0.3s;
    }
    textarea{
       width: 100%;
      padding: 12px 15px;
      background-color: #2d2d2d;
      border: 1px solid #444;
      border-radius: 5px;
      color: #e0e0e0;
      font-size: 1rem;
      resize:none;
      transition: all 0.3s;
    }
    
    input[type="text"]:focus,
    select:focus {
      outline: none;
      border-color: #bb86fc;
      box-shadow: 0 0 0 2px rgba(187, 134, 252, 0.2);
    }
    
    input[type="file"] {
      width: 100%;
      padding: 12px 15px;
      background-color: #2d2d2d;
      border: 1px dashed #444;
      border-radius: 5px;
      color: #e0e0e0;
      font-size: 1rem;
      transition: all 0.3s;
    }
    
    input[type="file"]:hover {
      border-color: #bb86fc;
      background-color: #2a2a2a;
    }
    
   
    .upload-btn {
      display: block;
      width: 100%;
      background: linear-gradient(135deg, #1e88e5, #0d47a1);
      color: white;
      text-decoration: none;
      padding: 14px;
      border-radius: 5px;
      font-weight: 600;
      font-size: 1.1rem;
      border: none;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 20px;
      text-align: center;
    }
    
    .upload-btn:hover {
      background: linear-gradient(135deg, #2196f3, #1565c0);
      transform: translateY(-2px);
      box-shadow: 0 4px 10px rgba(0, 100, 200, 0.3);
    }
    
  
    .back-link {
      display: inline-block;
      margin-top: 20px;
      color: #bb86fc;
      text-decoration: none;
      padding: 8px 15px;
      border-radius: 4px;
      transition: all 0.2s;
    }
    
    .back-link:hover {
      background-color: rgba(187, 134, 252, 0.1);
      text-decoration: underline;
    }
    
    
    .file-info {
      margin-top: 10px;
      padding: 10px;
      background-color: #2a2a2a;
      border-radius: 5px;
      font-size: 0.9rem;
      display: none;
    }
    
    
    @media (max-width: 768px) {
      body {
        padding: 15px;
      }
      
      .form-container {
        padding: 25px;
      }
      
      h2 {
        font-size: 1.8rem;
      }
    }
    
  
    .message {
      padding: 12px;
      border-radius: 5px;
      margin-bottom: 20px;
      text-align: center;
      font-weight: 600;
    }
    
    .success {
      background-color: rgba(76, 175, 80, 0.2);
      color: #4caf50;
      border: 1px solid #4caf50;
    }
    
    .error {
      background-color: rgba(244, 67, 54, 0.2);
      color: #f44336;
      border: 1px solid #f44336;
    }
  </style>
</head>
<body>
  <?php include 'sidebar.php';?>
  <div class="form-container">
    <h2>📤 Upload New Ebook</h2>
    
    <?php if(isset($error)): ?>
      <div class="message error"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data" id="uploadForm">
  <div class="form-group">
    <label for="title">Ebook Title</label>
    <input type="text" name="title" id="title" placeholder="Enter ebook title" required>
  </div>

  <div class="form-group">
    <label for="author">Author</label>
    <input type="text" name="author" id="author" placeholder="Enter author name" required>
  </div>

  <div class="form-group">
    <label for="des">Description</label>
    <textarea name="des" id="des" placeholder="Enter ebook description" rows="5" required></textarea>
  </div>

  <div class="form-group">
    <label for="price">Price ($)</label>
    <input type="number" name="price" id="price" placeholder="Enter price" step="0.01" required>
  </div>

  <div class="form-group">
    <label for="category">Category</label>
    <select name="category" id="category" required>
      <option value="">-- Choose Category --</option>
      <option value="tech">Tech</option>
      <option value="fiction">Fiction</option>
      <option value="non-fictional">Non-Fictional</option>
      <option value="sciencefiction">Science Fiction</option>
      <option value="mystery&thriller">Mystery & Thriller</option>
      <option value="business&finance">Business & Finance</option>
      <option value="self-help">Self-Help</option>
      <option value="solar system">Solar System</option>
    </select>
  </div>

  <div class="form-group">
    <label for="ebook">Ebook File</label>
    <input type="file" name="ebook" id="ebook" accept=".doc,.docx,.pdf" required>
  </div>

  <div class="form-group">
    <label for="cover">Cover Image</label>
    <input type="file" name="cover" id="cover" accept="image/*" required>
  </div>

  <button type="submit" class="upload-btn">Upload Ebook</button>
</form>

    <a href="index.php" class="back-link">← Back to Dashboard</a>
  </div>

  <script>
   
    document.getElementById('ebook').addEventListener('change', function(e) {
      const fileInfo = document.getElementById('fileInfo');
      if (this.files.length > 0) {
        const file = this.files[0];
        fileInfo.innerHTML = `
          <strong>Selected File:</strong> ${file.name}<br>
          <strong>Size:</strong> ${(file.size / 1024 / 1024).toFixed(2)} MB<br>
          <strong>Type:</strong> ${file.type || 'Unknown'}
        `;
        fileInfo.style.display = 'block';
      } else {
        fileInfo.style.display = 'none';
      }
    });
    
    
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
      const title = document.getElementById('title').value.trim();
      const category = document.getElementById('category').value;
      const file = document.getElementById('ebook').files[0];
      
      if (!title) {
        e.preventDefault();
        alert('Please enter a title for the ebook.');
        return false;
      }
      
      if (!category) {
        e.preventDefault();
        alert('Please select a category.');
        return false;
      }
      
      if (!file) {
        e.preventDefault();
        alert('Please select a file to upload.');
        return false;
      }
      
      
      const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (!allowedTypes.includes(file.type)) {
        e.preventDefault();
        alert('Please select a valid file type (PDF, DOC, or DOCX).');
        return false;
      }
      
     
      if (file.size > 10 * 1024 * 1024) {
        e.preventDefault();
        alert('File size must be less than 10MB.');
        return false;
      }
    });
  </script>
</body>
</html>