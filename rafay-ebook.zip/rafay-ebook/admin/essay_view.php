<?php 
include '../config.php';

// fetch only resume events
$query = "SELECT * FROM essay_competition";
$run = mysqli_query($conn, $query);

if (!$run) {
    die("Query failed: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Essay Competitions Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Dark Theme CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        :root {
            --primary: #bb86fc;
            --light: #ffffff;
            --text: #e0e0e0;
            --bg-dark: #121212;
            --bg-card: #1e1e1e;
            --bg-input: #2a2a2a;
            --border: #333;
            --accent: #1e88e5;
            --danger: #cf6679;
            --success: #03dac6;
            --warning: #ffb74d;
            --resume: #4caf50;
            --paused: #ff9800;
        }
        
        body {
            background-color: var(--bg-dark);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
            padding: 20px;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(156, 77, 255, 0.1) 0%, transparent 20%),
                radial-gradient(circle at 90% 80%, rgba(255, 77, 166, 0.1) 0%, transparent 20%);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            /* background: linear-gradient(135deg, #bb86fc, #7c4dff); */
            padding: 25px;
            border-radius: 15px 15px 0 0;
            text-align: center;
            margin-bottom: 0;
        }
        
        .header h1 {
            color: white;
            font-size: 2.2rem;
            margin-bottom: 10px;
        }
        
        .header p {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1.1rem;
        }
        
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .stat-card {
            background: var(--bg-card);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            border: 1px solid var(--border);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .stat-resume {
            color: var(--resume);
        }
        
        .stat-paused {
            color: var(--paused);
        }
        
        .stat-total {
            color: var(--primary);
        }
        
        .table-container {
            background: var(--bg-card);
            border-radius: 0 0 15px 15px;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
            border: 1px solid var(--border);
            margin-top: 0;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: linear-gradient(135deg, #1a1a1a, #2a2a2a);
        }
        
        th {
            padding: 16px 12px;
            text-align: left;
            font-weight: 600;
            color: var(--primary);
            border-bottom: 2px solid var(--border);
        }
        
        td {
            padding: 14px 12px;
            border-bottom: 1px solid var(--border);
        }
        
        tr:hover {
            background: rgba(187, 134, 252, 0.05);
        }
        
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-resume {
            background: rgba(76, 175, 80, 0.2);
            color: var(--resume);
            border: 1px solid var(--resume);
        }
        
        .status-paused {
            background: rgba(255, 152, 0, 0.2);
            color: var(--paused);
            border: 1px solid var(--paused);
        }
        
        .action-links {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            padding: 8px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .btn-edit {
            background: rgba(30, 136, 229, 0.2);
            color: var(--accent);
            border: 1px solid var(--accent);
        }
        
        .btn-edit:hover {
            background: var(--accent);
            color: white;
        }
        
        .btn-delete {
            background: rgba(207, 102, 121, 0.2);
            color: var(--danger);
            border: 1px solid var(--danger);
        }
        
        .btn-delete:hover {
            background: var(--danger);
            color: white;
        }
        
        .btn-pause {
            background: rgba(255, 152, 0, 0.2);
            color: var(--paused);
            border: 1px solid var(--paused);
        }
        
        .btn-pause:hover {
            background: var(--paused);
            color: white;
        }
        
        .btn-resume {
            background: rgba(76, 175, 80, 0.2);
            color: var(--resume);
            border: 1px solid var(--resume);
        }
        
        .btn-resume:hover {
            background: var(--resume);
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: var(--primary);
            opacity: 0.5;
        }
        
        @media (max-width: 768px) {
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 700px;
            }
            
            .action-links {
                flex-direction: column;
            }
            
            .header h1 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <?php include  'sidebar.php';?>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-trophy"></i> Essay Competitions Management</h1>
            <p>Manage all your essay writing competitions in one place</p>
        </div>
        
        <div class="dashboard-stats">
            <?php
            // Count competitions by status
            $totalQuery = "SELECT COUNT(*) as total FROM essay_competition";
            $resumeQuery = "SELECT COUNT(*) as resume FROM essay_competition WHERE status='resume'";
            $pausedQuery = "SELECT COUNT(*) as paused FROM essay_competition WHERE status='paused'";
            
            $totalResult = mysqli_query($conn, $totalQuery);
            $resumeResult = mysqli_query($conn, $resumeQuery);
            $pausedResult = mysqli_query($conn, $pausedQuery);
            
            $total = mysqli_fetch_assoc($totalResult)['total'];
            $resume = mysqli_fetch_assoc($resumeResult)['resume'];
            $paused = mysqli_fetch_assoc($pausedResult)['paused'];
            ?>
            
            <!-- <div class="stat-card">
                <div class="stat-number stat-total"><?php echo $total; ?></div>
                <div>Total Competitions</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-number stat-resume"><?php echo $resume; ?></div>
                <div>Active Competitions</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-number stat-paused"><?php echo $paused; ?></div>
                <div>Paused Competitions</div>
            </div> -->
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th><i class="fas fa-heading"></i> Competition Name</th>
                        <th><i class="fas fa-align-left"></i> Description</th>
                        <th><i class="fas fa-gift"></i> Prize</th>
                        <th><i class="fas fa-clock"></i> Duration</th>
                        <th><i class="fas fa-info-circle"></i> Status</th>
                        <th><i class="fas fa-cogs"></i> Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Reset pointer to beginning
                    mysqli_data_seek($run, 0);
                    
                    if (mysqli_num_rows($run) > 0) { 
                        while ($row = mysqli_fetch_assoc($run)) { 
                    ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($row['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['description']); ?></td>
                            <td><?php echo htmlspecialchars($row['prize']); ?></td>
                            <td><?php echo htmlspecialchars($row['duration']); ?></td>
                            <td>
                                <span class="status-badge <?php echo $row['status'] == 'resume' ? 'status-resume' : 'status-paused'; ?>">
                                    <i class="<?php echo $row['status'] == 'resume' ? 'play' : 'pause'; ?>"></i>
                                    <?php echo ucfirst($row['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-links">
                                    <a href="edit_essay.php?id=<?php echo $row['id']; ?>" class="action-btn btn-edit">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="delete_essay.php?id=<?php echo $row['id']; ?>" class="action-btn btn-delete" onclick="return confirm('Are you sure you want to delete this competition?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                    <?php if ($row['status'] == 'active') { ?>
                                        <a href="?pause=<?php echo $row['id']; ?>" class="action-btn btn-pause">
                                            Pause
                                        </a>
                                    <?php } elseif ($row['status'] == 'paused') { ?>
                                        <a href="?resume=<?php echo $row['id']; ?>" class="action-btn btn-resume">
                                             active
                                        </a>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php 
                        } 
                    } else { 
                    ?>
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <i class="fas fa-inbox"></i>
                                    <h3>No Competitions Found</h3>
                                    <p>Get started by creating your first essay competition</p>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php 
    // Handle pause
    if (isset($_GET['pause'])) {
        $id = (int)$_GET['pause'];
        mysqli_query($conn, "UPDATE essay_competition SET status='paused' WHERE id=$id");
        echo "<script>window.location.href='essay_view.php'</script>";
    }

    // Handle resume
    if (isset($_GET['resume'])) {
        $id = (int)$_GET['resume'];
        mysqli_query($conn, "UPDATE essay_competition SET status='active' WHERE id=$id");
        echo "<script>window.location.href='essay_view.php'</script>";
    }
    ?>
</body>
</html>