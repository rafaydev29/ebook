<?php
include '../config.php';

$id = intval($_GET['id']);
$query = "DELETE FROM fiction WHERE id=$id";

if (mysqli_query($conn, $query)) {
    header("Location: index.php");
    exit;
} else {
    echo "Error: " . mysqli_error($conn);
}
