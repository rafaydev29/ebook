<div class="sidebar">
  <h1>⚡ Admin Panel</h1>

  <div class="sidebar-section">
    <button class="section-toggle">👤 Users ▾</button>
    <div class="section-links">
      <a href="admin_users.php" class="sidebar-link">Manage Users</a>
    </div>
  </div>

  <div class="sidebar-section">
    <button class="section-toggle">📚 Ebooks ▾</button>
    <div class="section-links">
      <a href="index.php" class="sidebar-link">Manage Ebooks</a>
      <a href="upload.php" class="sidebar-link">Upload New Ebook</a>
    </div>
  </div>

  <div class="sidebar-section">
    <button class="section-toggle">✍️ Stories ▾</button>
    <div class="section-links">
      <a href="Story_view.php" class="sidebar-link">Stories</a>
      <a href="Story_Upload.php" class="sidebar-link">Launch Story Competition</a>
      <a href="Submitted_stories.php" class="sidebar-link">Submitted Stories</a>
    </div>
  </div>

  <div class="sidebar-section">
    <button class="section-toggle">🚀 Competitions ▾</button>
    <div class="section-links">
      <a href="essay_view.php" class="sidebar-link">Essay Competitions</a>
      <a href="essay_upload.php" class="sidebar-link">Upload Essay Competition</a>
    </div>
  </div>

  <div class="sidebar-section">
    <button class="section-toggle">🔔 Notifications & Events ▾</button>
    <div class="section-links">
      <a href="notifications.php" class="sidebar-link">Send Notification</a>
      <a href="events_view.php" class="sidebar-link">Upload Event</a>
    </div>
  </div>
</div>

<style>
  body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #1a1528;
    color: #f1f1f1;
    margin-left: 240px;
  }

  .sidebar {
    width: 240px;
    height: 100vh;
    background: linear-gradient(180deg, #2a1a40, #1a1528);
    padding: 20px 15px;
    position: fixed;
    top: 0;
    left: 0;
    display: flex;
    flex-direction: column;
    gap: 15px;
    box-shadow: 3px 0 15px rgba(0,0,0,0.4);
    overflow-y: auto;
  }

  .sidebar h1 {
    text-align: center;
    font-size: 1.4rem;
    margin-bottom: 20px;
    color: #d1b3ff;
    font-weight: 700;
  }

  .sidebar-section {
    display: flex;
    flex-direction: column;
  }

  .section-toggle {
    background: #3b235d;
    color: #d1b3ff;
    padding: 12px 18px;
    border-radius: 8px;
    font-weight: 600;
    border: none;
    cursor: pointer;
    text-align: left;
    transition: all 0.3s ease;
  }

  .section-toggle:hover {
    background: #532d82;
    transform: translateX(3px);
  }

  .section-links {
    display: none;
    flex-direction: column;
    padding-left: 10px;
    margin-top: 5px;
  }

  .sidebar-link {
    background: rgba(255, 255, 255, 0.05);
    color: #f1f1f1;
    text-decoration: none;
    padding: 10px 15px;
    border-radius: 6px;
    margin: 3px 0;
    font-size: 0.95rem;
    transition: all 0.3s ease;
  }

  .sidebar-link:hover {
    background: #7e57c2;
    transform: translateX(5px);
  }
 
  .sidebar-section.active .section-links {
    display: flex;
    animation: fadeIn 0.3s ease;
  }
  /* Scrollbar styling */
.sidebar::-webkit-scrollbar {
  width: 8px;
}

.sidebar::-webkit-scrollbar-track {
  background: #2a1a40;  /* track color */
  border-radius: 4px;
}

.sidebar::-webkit-scrollbar-thumb {
  background: #7e57c2;  /* scrollbar handle color */
  border-radius: 4px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
  background: #9f7aea; /* lighter purple on hover */
}

/* Firefox scrollbar */
.sidebar {
  scrollbar-width: thin;
  scrollbar-color: #7e57c2 #2a1a40;
}


  @keyframes fadeIn {
    from {opacity: 0; transform: translateY(-5px);}
    to {opacity: 1; transform: translateY(0);}
  }
</style>

<script>
  document.querySelectorAll('.section-toggle').forEach(btn => {
    btn.addEventListener('mouseover', () => {
      btn.parentElement.classList.toggle('active');
    });
  });
</script>

