<?php 
   include '../config.php';
   $query="SELECT * FROM events_view";
   $run=mysqli_query($conn,$query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Management</title>
    <style>
        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #121212;
            color: #e0e0e0;
            line-height: 1.6;
            padding: 20px;
        }
        
        /* Header Styles */
        h1 {
            color: #ffffff;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
            font-weight: 300;
            letter-spacing: 1px;
            text-shadow: 0 0 10px rgba(0, 150, 255, 0.3);
        }
        
        /* Button Styles */
        .upload-btn {
            display: inline-block;
            background: linear-gradient(135deg, #1e88e5, #0d47a1);
            color: white;
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 30px;
            font-weight: 600;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 100, 200, 0.3);
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
    
        
        .upload-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 100, 200, 0.4);
            background: linear-gradient(135deg, #2196f3, #1565c0);
        }
        
        /* Table Container */
        .table-container {
            overflow-x: auto;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            margin-bottom: 30px;
        }
        
        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #1e1e1e;
            border-radius: 10px;
            overflow: hidden;
        }
        
        th {
            background: linear-gradient(135deg, #2d2d2d, #1a1a1a);
            color: #bb86fc;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 0.9rem;
            border-bottom: 2px solid #333;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #333;
            transition: background-color 0.2s;
        }
        
        tr:hover td {
            background-color: #2a2a2a;
        }
        
        tr:last-child td {
            border-bottom: none;
        }
        
        /* Action Links */
        .action-links a {
            color: #bb86fc;
            text-decoration: none;
            margin: 0 5px;
            padding: 5px 10px;
            border-radius: 4px;
            transition: all 0.2s;
            display: inline-block;
        }
        
        .action-links a:nth-child(1) { 
            color: #03dac6;
        }
        
        .action-links a:nth-child(2) {
            color: #ffb74d;
        }
        
        .action-links a:nth-child(3) { 
            color: #cf6679;
        }
        
        .action-links a:hover {
            background-color: rgba(255, 255, 255, 0.1);
            transform: translateY(-1px);
        }
        
        /* Status Indicators */
        .status {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-active {
            background-color: rgba(76, 175, 80, 0.2);
            color: #4caf50;
        }
        
        .status-upcoming {
            background-color: rgba(255, 152, 0, 0.2);
            color: #ff9800;
        }
        
        .status-completed {
            background-color: rgba(158, 158, 158, 0.2);
            color: #9e9e9e;
        }
        
        /* Footer */
        footer {
            text-align: center;
            margin-top: 40px;
            color: #666;
            font-size: 0.9rem;
        }
        
        /* Navigation */
        .nav {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .nav a {
            border-radius: 30px;
            width: 300px;
            text-align: center;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #888;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            th, td {
                padding: 10px 8px;
                font-size: 0.9rem;
            }
            
            .action-links a {
                display: block;
                margin: 5px 0;
                text-align: center;
            }
            
            .nav {
                flex-direction: column;
                align-items: center;
            }
            
            .nav a {
                width: 100%;
                max-width: 300px;
            }
        }
    </style>
</head>
<body>
    <h1>🎯 Events Management Dashboard</h1>
    
    <?php include 'sidebar.php'; ?> 
    
    <div class="nav">
        <a href="events_upload.php" class="upload-btn">🚀 Launch New Event</a>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Event Name</th>
                    <th>Description</th>
                    <th>Prize</th>
                    <th>Duration</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $hasData = false;
                while($row=mysqli_fetch_assoc($run)){ 
                    $hasData = true;
                ?>
                    <tr>
                        <td><?php echo $row['id']?></td>
                        <td><?php echo $row['name']?></td>
                        <td><?php echo $row['desc']?></td>
                        <td><?php echo $row['number']?></td>
                        <td><?php echo $row['time']?></td>
                        <td class="action-links">
                            <a href="edit_event.php?id=<?php echo $row['id']; ?>">✏ Edit</a>
                            <a href="delete_event.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this event?')">❌ Delete</a>
                            <?php if ($row['status'] == 'active') { ?>
                                <a href="?pause=<?php echo $row['id']; ?>">⏸ Pause</a>
                            <?php } elseif ($row['status'] == 'paused') { ?>
                                <a href="?resume=<?php echo $row['id']; ?>">▶ Resume</a>
                            <?php } else { ?>
                                <a href="?pause=<?php echo $row['id']; ?>">⏸ Pause</a>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
                
                <?php if(!$hasData) { ?>
                    <tr>
                        <td colspan="6" class="empty-state">
                            No events found. <a href="events_upload.php" style="color: #bb86fc;">Create your first event</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <?php 
     if(isset($_GET['pause'])){
        $id = (int)$_GET['pause'];
        mysqli_query($conn,"UPDATE events_view SET status='paused' WHERE id=$id");
        echo "<script>window.location.href='events_view.php'</script>";
     }
     if(isset($_GET['resume'])){
        $id = (int)$_GET['resume'];
        mysqli_query($conn,"UPDATE events_view SET status='resume' WHERE id=$id");
         echo "<script>window.location.href='events_view.php'</script>";
     }
    ?>
    <footer>
        <p>Events Management System &copy; <?php echo date('Y'); ?></p>
    </footer>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let cells = document.querySelectorAll('td');
            cells.forEach(function(cell) {
                if (cell.textContent.trim() === "") {
                    cell.textContent = 'No data';
                    cell.style.color = '#888';
                    cell.style.fontStyle = 'italic';
                }
            });
        });
    </script>
</body>
</html>