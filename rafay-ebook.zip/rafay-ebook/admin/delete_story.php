<?php
include '../config.php';


if(isset($_POST['id'])) {
    $id = intval($_POST['id']);
    
    $query = "DELETE FROM submitted_stories WHERE id = $id";
    if(mysqli_query($conn, $query)) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
